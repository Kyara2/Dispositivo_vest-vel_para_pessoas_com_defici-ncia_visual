# Macro de SRAM para a GPDK045 (gerada com OpenRAM / FreePDK45)

## Por que existe isto

O Genus não gera SRAM. Quando o RTL tem `reg [31:0] mem [0:N]`, ele transforma cada bit em um flip-flop e acrescenta muxes de leitura e escrita. É o que o `femto_ram_ff.v` mostra. Para alguns KB isso já é enorme.

Memória de verdade em chip é uma **macro** pronta, gerada por um compilador de memória, e cada ferramenta só vê uma "view" dela:

| View | Quem usa | Para quê |
|---|---|---|
| `.lib` | Genus, STA | timing (setup/hold, clk→dout), área, potência; a macro é uma caixa-preta |
| `.lef` | Genus (modo PLE), Innovus | tamanho e posição dos pinos |
| `.v` | Xcelium | modelo comportamental, só para simulação |
| `.gds` | Virtuoso/Innovus (stream-out) | layout |

A GPDK045 da turma traz apenas células padrão (gsclib045) e IO, sem compilador de memória nem macros de SRAM. O projeto `neorv32_sram_soc` resolveu isso trocando de tecnologia para o sky130 com uma macro OpenRAM. Aqui ficamos na GPDK045 e importamos uma macro gerada pela OpenRAM para o **FreePDK45**, um PDK acadêmico de 45 nm.

## A macro: `sram_32x1024_freepdk45`

| | |
|---|---|
| Organização | 1024 palavras × 32 bits = 4 KB, 1 porta RW, máscara de escrita por byte |
| Área (layout OpenRAM) | 50.766 µm², LEF de 237,9 × 213,4 µm |
| Corner do `.lib` | TT, 1,0 V, 25 °C (modelo analítico) |
| clk→dout | 0,40 ns, a partir da borda de **descida** |
| Setup/hold das entradas | 0,009 / 0,001 ns |
| Período mínimo | 1,47 ns (~681 MHz) |
| Pinos | `clk0`, `csb0` (chip select, ativo baixo), `web0` (write enable, ativo baixo), `wmask0[3:0]`, `addr0[9:0]`, `din0[31:0]`, `dout0[31:0]`; alimentação `vdd`/`gnd` |

O protocolo registra as entradas na borda de **subida**, escreve ou lê na borda de **descida**, e o `dout0` fica válido do meio do ciclo até a subida seguinte. Isso dá a mesma latência de 1 ciclo que o FemtoRV32 espera.

O datasheet completo está em `doc/sram_32x1024_freepdk45.html` e a configuração usada na OpenRAM em `doc/openram_config.py`. Foi gerada com OpenRAM 1.2.48 e layout completo; DRC e LVS não foram rodados.

## O que foi preciso ajustar ("mexer na biblioteca")

1. **Nomes de camada no LEF.** A OpenRAM escreve `metal1..metal4` (FreePDK45), e o tech LEF da GPDK045 usa outro nome. O Genus aborta com `layer ... not found`, o mesmo erro do projeto sky130. O `run.sh syn` gera `lef/sram_32x1024_freepdk45_gpdk045.lef` automaticamente, lendo o prefixo certo do `gsclib045_tech.lef`.
2. **`avoid`/`dont_use`.** O `.lib` da OpenRAM vem com `dont_use : true`, e o Genus marca células suspeitas como `avoid`. Uma instância de célula `avoid` fica **não resolvida**: vira caixa-preta vazia, a síntese termina sem erro e a memória some do timing. O `tech.tcl` libera a macro, e o `synthesis.tcl` conta as instâncias resolvidas e grava `<design>_unresolved.rpt`.
3. **Modelo de simulação.** O `.v` original entrega o dado 3 ns após a descida. A própria OpenRAM marca esse valor como arbitrário ("FIXME"), e o `.lib` diz 0,4 ns. Com clock abaixo de ~6 ns, a simulação falharia sem haver problema real. Isso foi verificado: com o original a 4 ns, foram 3249 erros. Na cópia em `verilog/` o atraso passou para 0,4 ns e o modo verboso foi desligado. O original está ao lado, intocado.

O `.lib` **não** foi editado.

## Limitações (precisam aparecer no relatório)

- **Não é uma macro da GPDK045** e não é silício caracterizado. É FreePDK45 com modelo **analítico** da OpenRAM. Área e timing são plausíveis para 45 nm, mas são estimativas.
- **Um corner só.** A macro entra igual nos domínios `worst` (slow 0,9 V 125 °C) e `best` (fast) da gsclib045. Tentei gerar SS/FF, mas o modelo analítico não é confiável fora do TT: a 125 °C ele chega a dar atraso **negativo**. Se quiser margem no corner lento, aplique um derate na macro (por exemplo `set_timing_derate -late 1.5` nas instâncias `*u_sram*`) e declare isso.
- **`max_capacitance` minúsculo no `dout0`** (~0,8 fF, resultado do modelo analítico). Espere violações de max_cap nesses pinos no `report_design_rules`: são artefato do modelo, não do seu RTL.
- O GDS usa o mapa de camadas do FreePDK45. Para levar até o Innovus/Virtuoso na GPDK045 seria preciso remapear camadas ou tratar a macro como abstrato (LEF).

## Como regerar (fora do servidor)

```bash
pip install openram "numpy<2"        # a OpenRAM 1.2.48 quebra com numpy 2.x
python3 -c "import openram; openram.init_openram(config_file='doc/openram_config.py', is_unit_test=False); \
            from openram import sram; sram().save()"
```

Leva cerca de 15 minutos para 32×1024 com layout. Para outro tamanho, mude `num_words`/`word_size`.
