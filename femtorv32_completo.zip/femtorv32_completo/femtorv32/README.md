# FemtoRV32 Quark — síntese no Cadence Genus (GPDK045) e testes funcionais

Autora: Kyara Esteves de Sousa

Processador: [FemtoRV32 Quark](https://github.com/BrunoLevy/learn-fpga/tree/master/FemtoRV), de Bruno Levy e Matthias Koch (licença BSD-3). É o núcleo RV32I mínimo da coleção FemtoRV e o que a FemtoSoC usa por padrão. A estrutura de pastas e os scripts seguem o projeto `fusion_core`.

## Como rodar

Antes de tudo, ajuste `USER` e `PROJECT_DIR` no `backend/synthesis/scripts/run.sh`. O projeto espera ficar em `/prj/ci/workarea/<usuário>/projetos/femtorv32`.

```bash
./exe.sh pre                                  # simulação RTL do isa_test (Xcelium)
PROGRAM=c_suite WAITSTATES=1 ./exe.sh pre     # suíte em C com wait states aleatórios
./exe.sh pre gui                              # o mesmo, abrindo o SimVision
./exe.sh syn                                  # síntese no Genus (relatórios, netlist, SDF)
./exe.sh post                                 # netlist + SDF no Xcelium
SDF=no ./exe.sh post                          # netlist sem atrasos (só funcional)
CLK_PERIOD=5 ./exe.sh syn                     # outra frequência (o default é 10 ns)

MODULE=femto_sram ./exe.sh pre                # RAM com macros de SRAM (testbench de memória)
MODULE=femto_sram ./exe.sh syn                # síntese com a macro como caixa-preta
MODULE=femto_sram ./exe.sh post               # netlist + modelo da macro
MODULE=femto_ram_ff ./exe.sh syn              # a mesma RAM em flip-flops (comparação)
MODULE=femtorv32_sram ./exe.sh pre            # Quark rodando o c_suite a partir da SRAM
MODULE=femto_soc ./exe.sh pre                 # SoC completo rodando o firmware dos sensores
MODULE=femto_soc ./exe.sh syn                 # síntese do SoC inteiro (27 MHz, macros de SRAM)

./run_all_functional.sh                       # todos os testes funcionais (RTL)
./run_all_functional.sh post                  # o mesmo nas netlists que existirem
```

Cada simulação termina com `FUNCTIONAL_RESULT: PASS/FAIL`. Os logs ficam em `backend/synthesis/work/{pre,post}/femtorv32_quark/`. Os relatórios do Genus vão para `backend/synthesis/reports/femtorv32_quark/` e a netlist e o SDF para `backend/synthesis/deliverables/femtorv32_quark/`.

## Estrutura

```
exe.sh, run_all_functional.sh
frontend/
  src/femtorv32_quark.v           RTL adaptado para ASIC (é o que entra na síntese)
  upstream/femtorv32_quark.v      original do repositório, intocado
  upstream/asic_changes.diff      diff entre os dois
  testbench/femtorv32_quark_tb.sv testbench funcional (pre e post)
  src/femto_sram.v                RAM com N bancos da macro de SRAM (default 2 = 8 KB)
  src/femto_ram_ff.v              mesma RAM em flip-flops (default 1 KB)
  testbench/femto_sram_tb.sv      testbench da memória (femto_ram_ff_tb.sv reaproveita)
  testbench/femtorv32_sram_tb.sv  integração: Quark + femto_sram
  firmware/                       programas de teste (fontes + .hex prontos)
  src/soc/                        SoC: ponte AXI4-Lite, crossbar, periféricos, top femto_soc.v
  src/fusion/                     núcleo de fusão (fusion_gain/channel/variance/node), sem alteração
  testbench/femto_soc_tb.sv       teste de sistema do SoC (+ models/vl53l0x_model.v)
  firmware/soc/                   firmware do SoC (sensores, fusão SW x HW, driver VL53L0X)
tech/sram/                        macro de SRAM OpenRAM (lib, lef, v, gds, doc) -- ler o README de lá
fpga/                             Tang Primer 20K Dock: top, pinos, SDC, script Gowin, RAM em BSRAM
backend/synthesis/
  scripts/run.sh, synthesis.tcl, common/{path,tech}.tcl, pre_syn.tcl, post_syn.tcl
  constraints/design_constraints.sdc
```

## Por que o RTL foi modificado

O Quark foi escrito para FPGA. Nesse alvo, todo flip-flop começa em 0 quando o bitstream é carregado, e o Yosys é tolerante com algumas construções fora do padrão. Em ASIC as duas coisas deixam de valer. As quatro mudanças estão marcadas `[ASIC-n]` no código e não alteram a ISA nem a temporização de ciclos.

1. **Nome do módulo.** `FemtoRV32` virou `femtorv32_quark`, para bater com `HDL_NAME`/`DESIGN`. No repositório original todas as variantes usam o nome `FemtoRV32`.
2. **Declaração antes do uso.** O original usa `instr`, `state`, `PC`, `cycles`, `LOAD_data`, `writeBack` e outros antes de declará-los. Um parser estrito ao padrão (slang) acusa erro no original, e o Genus e o Xcelium podem rejeitar ou avisar. A versão adaptada passa limpa no slang e no Verilator.
3. **Reset em `instr`, `aluShamt`, `aluReg` e `cycles`.** Em ASIC esses registradores nascem X, e `aluShamt = X` deixa `aluBusy = X`. Com isso a FSM fica presa em `WAIT_ALU_OR_MEM` na simulação gate-level. O original só zerava esses registradores num `initial` dentro de `` `ifdef BENCH ``, que não é sintetizável.
4. **x0 lido sempre como zero.** No original, `registerFile[0]` nunca é escrito e dependia do valor inicial 0 da FPGA.

Para comprovar, sintetizei os dois RTLs com Yosys e simulei as netlists com este testbench. O original trava com X em `mem_rstrb` e `mem_wmask` logo após o reset. O adaptado passa em todos os testes.

## Testes funcionais

O testbench modela uma RAM de 64 KB com a mesma temporização da FemtoSoC (leitura registrada um ciclo após `mem_rstrb`, escrita com máscara de bytes). O espaço de IO fica no bit 22 do endereço:

| Endereço   | Função                                             |
|------------|----------------------------------------------------|
| `0x400000` | TOHOST: 1 = PASS, `(n<<1)\|1` = falha no teste n    |
| `0x400004` | CONSOLE: `putchar`, aparece no log como `[console]` |
| `0x400008` | SIGNATURE: o valor é impresso no log               |

O testbench verifica:
- o protocolo: nenhuma transação nova com `mem_rbusy` ou `mem_wbusy` altos;
- X/Z nas saídas do processador após o reset;
- acessos fora da RAM;
- timeout.

Com `WAITSTATES=1`, ele injeta de 0 a 3 ciclos aleatórios de `rbusy`/`wbusy` em cada acesso.

Há dois programas. Os `.hex` já vêm prontos, então o cluster não precisa de toolchain RISC-V.

- **`isa_test`**: cerca de 730 casos autoverificáveis cobrindo todas as instruções RV32I, x0, dependências, todos os 32 valores de shift, desvios nos dois sentidos, JAL/JALR, loads e stores em todos os offsets e `rdcycle`. É gerado por `gen_isa_test.py`, que calcula os valores esperados com um modelo de referência em Python, independente do RTL.
- **`c_suite`**: 10 kernels em C: recursão, bubble sort, CRC32, crivo, mul/div em software (libgcc), strings, switch com tabela de saltos, structs de 8/16 bits, matriz e shifts variáveis. Os valores esperados saem do mesmo arquivo compilado no host (`-DHOST`).

Para regerar os `.hex` (precisa de `gcc-riscv64-unknown-elf`): `cd frontend/firmware && make`.

### Validação feita antes da entrega

Sem acesso a Xcelium e Genus, validei com iverilog e Yosys:

- **RTL:** 4/4 PASS. CPI médio de ~3,6 a 3,8, e ~5,3 com wait states.
- **Netlist genérica do Yosys:** PASS, sem X.
- **Scripts:** `exe.sh pre/post` e `run_all_functional.sh` rodados de ponta a ponta, com um `xrun` substituto.
- **Teste de mutação:** 10 bugs injetados no RTL, 10 detectados. As mutações em `mem_rbusy` e `mem_wbusy` só são pegas com `WAITSTATES=1`, e o JALR que não zera o bit 0 só é pego pelo `isa_test`. Por isso o `run_all_functional.sh` roda todas as combinações.

## Memória (femto_sram)

O Genus não "sintetiza" SRAM. Memória em Verilog vira flip-flops, e a SRAM de verdade é uma macro pronta, vinda de um compilador de memória. A GPDK045 não tem compilador de memória, então importei uma macro de 4 KB gerada pela OpenRAM para o FreePDK45. Os detalhes, o que precisou ser ajustado e as limitações estão em `tech/sram/README.md`.

O `femto_sram` é a casca sintetizável em volta das macros: decodifica o banco, gera `csb0`/`web0` (ativos em baixo) e escolhe a saída do banco certo. Ele tem a mesma interface e a mesma latência de 1 ciclo da memória que o Quark espera, então `rbusy`/`wbusy` ficam sempre em 0. Por isso, para o STA, o caminho `dout0 → processador` tem **meio período**: o dado sai na borda de descida da macro e é capturado na subida.

O `femto_sram_tb` compara tudo com um modelo de referência, em quatro fases:
1. preenche e lê as 2048 palavras;
2. testa todas as máscaras de byte e meia-palavra;
3. confere que `sel=0` não escreve;
4. faz 20 mil acessos aleatórios, com leitura logo após escrita e acessos consecutivos.

O mesmo testbench roda com o `femto_ram_ff`.

O `femtorv32_sram_tb` coloca o Quark executando o `c_suite` direto das macros (programa `c_suite_8k`, linkado para 8 KB). O resultado é idêntico ao do testbench com memória ideal: 613.686 ciclos, todos os kernels ok, inclusive com clock de 5 ns.

Validação local (iverilog e Yosys), com os scripts rodados de ponta a ponta:
- `femto_sram` passa em RTL a 10 ns e a 4 ns;
- o pós-síntese (netlist Yosys com a macro como caixa-preta mais o modelo da macro) passa;
- o `femto_ram_ff` passa;
- o `femtorv32_sram` passa.

No Genus, confira primeiro:
- a mensagem `Instancias da macro sram_32x1024_freepdk45: 2` no log;
- o `reports/femto_sram/femto_sram_unresolved.rpt` vazio;
- a área da macro no `area_hier`;
- os relatórios `timing_from_sram`/`timing_to_sram`.

## SoC (femto_soc)

O Quark conversa com tudo por AXI4-Lite. A `femto_axil_master` converte a interface nativa dele em mestre AXI4-Lite, e a `axil_xbar` distribui as transações por endereço:

| Endereço | Bloco | Função |
|---|---|---|
| `0x000000` | `axil_sram` | 16 KB de RAM (`femto_sram` com 4 macros) |
| `0x400000` | `periph_sysinfo` | clock, flag de simulação, LEDs |
| `0x400100` | `periph_uart` | TX 115200 8N1 |
| `0x400200` | `periph_hcsr04` | ultrassom, distância em mm por MMIO |
| `0x400300` | `periph_i2c` | mestre I2C para o VL53L0X |
| `0x400400` | `periph_fusion` | coprocessador: 1 `fusion_node` (K, q̂, σ²) e latência do núcleo |

Os registradores de cada periférico estão no cabeçalho do respectivo `.v` e em `frontend/firmware/soc/soc.h`. O `periph_hcsr04` é o `controlador_ultrassonico.v` adaptado: mede em mm, calcula as constantes a partir de `CLK_HZ` em vez de fixar 12 MHz, tem reset síncrono, timeout e flag de dado novo.

O firmware (`soc_fw`, 9,2 KB) segue estes passos:
1. Faz um autoteste comparando hardware e software em 64 vetores, incluindo bordas.
2. Inicializa o VL53L0X, com um porte em C da biblioteca da Pololu (MIT).
3. Em laço: lê os dois sensores, funde em software (bit a bit igual ao hardware) e depois só no coprocessador.
4. Imprime na UART as medidas, os dois resultados, os ciclos de cada caminho e o speedup.

A correção e as variâncias de cada sensor vêm de `frontend/firmware/soc/calib.h`, gerado pela calibração (ver a seção "Calibração dos sensores e variâncias").

Na simulação (`MODULE=femto_soc ./exe.sh pre`), com modelos de HC-SR04 e VL53L0X, o resultado é `RESULT: PASS`: autoteste todo igual e 4 rodadas com hardware igual ao software. A fusão leva 2.239 ciclos em software contra 247 no coprocessador (~9x). Só 22 desses 247 ciclos são do núcleo; o resto é o custo dos 8 acessos MMIO pelo barramento. Com 8 nodes em paralelo, esse custo se dilui.

O SoC sintetiza por padrão a 27 MHz (`CLK_PERIOD=37.037`), o mesmo `CLK_HZ` do RTL e da FPGA, para que baud, tempos dos sensores e firmware valham igual nos dois. ### Simulação pós-síntese do SoC (sem e com DFT)

A netlist do SoC é simulada no Xcelium com o SDF do Genus. Primeiro gere as duas netlists, depois rode as simulações:

```bash
MODULE=femto_soc ./exe.sh syn                           # netlist sem DFT
SYNTHESIS_WITH_DFT=yes MODULE=femto_soc ./exe.sh syn    # netlist com scan

MODULE=femto_soc ./exe.sh post                          # pós-síntese sem DFT, com SDF
SYNTHESIS_WITH_DFT=yes MODULE=femto_soc ./exe.sh post   # pós-síntese com DFT (SE=0), com SDF
```

Os logs ficam em `backend/synthesis/work/post/femto_soc/` e `.../post/femto_soc_dft/`. Cada um termina com `RESULT: PASS` e `FUNCTIONAL_RESULT`.

O que muda em relação à simulação RTL:
- **Sem parâmetros:** a netlist não tem parâmetros, então a UART roda a 115200 (divisor 234, sintetizado) e o HC-SR04 dispara a cada 60 ms, como no chip. A simulação é mais longa: até `MAX_MS=1500` ms simulados.
- **Firmware de pós-síntese:** o `soc_fw_post` é o mesmo firmware compilado com `FORCE_SIM`. A netlist sai com `SIM=0`, e sem isso o firmware não terminaria.
- **Carga da RAM:** cada macro carrega o próprio banco (`+SRAM_PRELOAD=frontend/firmware/hex/soc_fw_post`, arquivos `_b0..b3.hex`). O preload por nome hierárquico não serve aqui, porque os nomes mudam na netlist.
- **Netlist com DFT:** as portas de scan ficam em modo funcional (`SE=0`, `dft_sdi_1=0`). A simulação mostra que a inserção de scan não mudou o comportamento.

Para regerar o firmware de pós-síntese: `make -C frontend/firmware hex/soc_fw_post.hex`.

Para levar à Tang Primer 20K, siga `fpga/README.md`. O mesmo RTL vai para a placa: com `FPGA=1`, a RAM vira BSRAM com o firmware embutido. Essa configuração também foi simulada (`+define+TB_FPGA_RAM`) e passa.

## Calibração dos sensores e variâncias

### Por que precisa

A fusão (filtro de Kalman estático do paper, eq. 7 a 11) combina as duas medidas usando a **variância** de cada sensor:

```
K = σ²_US / (σ²_US + σ²_ToF)        q = US + K · (ToF − US)        σ²_novo = σ²_US − K · σ²_US
```

Ela supõe duas coisas: que cada sensor tem **erro aleatório de média zero** e que as variâncias são **conhecidas**. As duas vêm da caracterização dos sensores, como o paper fez na Fig. 6 a 8 (curva de ajuste) e na Fig. 10 (pdfs).

- **Erro sistemático (viés).** É um erro que se repete sempre do mesmo jeito: offset, ou erro de escala que cresce com a distância. O filtro **não corrige** viés: ele só pondera erros aleatórios. Se os sensores estão enviesados, a estimativa fundida fica enviesada também. O viés tem que ser tirado **antes** da fusão, com uma correção linear (ganho e offset) obtida medindo distâncias conhecidas.
- **Variância.** É quanto a medida corrigida oscila em torno do valor certo. Ela decide o peso de cada sensor (K). Quem oscila menos ganha mais peso.

### O que foi medido na placa (obstáculo a 100 mm)

| Sessão | Sensor | Média | Viés | Variância (std) |
|---|---|---|---|---|
| 1 | HC-SR04 | 88,4 mm | −11,6 mm | 0,25 mm² (0,5 mm) |
| 1 | VL53L0X | 138,2 mm | +38,2 mm | 2,2 mm² (1,5 mm) |
| 2 | HC-SR04 | 95,0 mm | −5,0 mm | ~0 mm² (constante) |
| 2 | VL53L0X | 128,6 mm | +28,6 mm | 3,0 mm² (1,7 mm) |

Duas conclusões:
- Quase todo o erro é **viés**, não ruído. O VL53L0X lê uns 30 mm a mais a curta distância, que é o *offset* que a própria ST manda calibrar a 100 mm. O HC-SR04 lê 5 a 12 mm a menos. Por isso os dois discordavam em ~5 cm em vez de no máximo 1,5 cm.
- As variâncias que estavam no firmware (100 e 36 mm²) **não vinham de medição**. Eram valores de partida que eu escolhi e deixei marcados como provisórios. O ruído real é bem menor: ~0,3 mm² no ultrassom e ~3 mm² no laser. Com os valores reais, o ultrassom passa a ter mais peso, porque a 10 cm ele é o mais estável.

A diferença entre as sessões 1 e 2 (7 a 10 mm) mostra outra coisa: a montagem ou o obstáculo mudou entre elas. A calibração precisa ser feita **na montagem final**, com os sensores fixos.

### Onde ficam os valores

Em `frontend/firmware/soc/calib.h`, por sensor:
- `GAIN_Q12` e `OFFSET_MM`: correção linear, `corrigida = bruta × ganho + offset` (ganho em Q12, 4096 = 1,0);
- `VAR_MM2`: variância da medida corrigida, que vai para a fusão (com piso de 1 mm²).

O `calib.h` que veio no zip já tem uma correção **de 1 ponto** tirada da sessão 2 (US +5 mm, ToF −29 mm, variâncias 1 e 3 mm²). Ela tira o offset a 100 mm, mas não o erro de escala, então em outras distâncias ainda sobra erro. Para o resultado definitivo, faça a calibração abaixo.

### Sessão de calibração (recomendado)

Com o firmware de calibração gravado (`./fpga/tang_primer_20k/build.sh calib`) e o `tio` fechado:

```bash
./tools/calib_session.sh            # mede: digite a distância REAL (ex.: 150 [Enter]); "fim" calcula
./tools/calib_session.sh fit        # só calcula, com tudo que já foi medido
./tools/calib_session.sh lista      # mostra as medidas salvas
./tools/calib_session.sh desfaz     # apaga a última medida
./tools/calib_session.sh nova       # arquiva as medidas atuais e começa do zero
```

Para usar outra porta: `PORT=/dev/ttyUSB0 ./tools/calib_session.sh`.

Como funciona:
1. Você posiciona o obstáculo, mede com a trena e **digita a distância real** (por exemplo `150` e Enter).
2. O script descarta o que estava no buffer da porta e grava até juntar 5 blocos `CAL` completos, sem contar o primeiro. Cada bloco tem 80 amostras de cada sensor, então são **400 medidas por sensor** por medida. Um limite de 240 s descarta a medida se ela não juntar os blocos.
3. Ele mostra o número de medidas e de falhas, salva e pede a próxima distância.
4. Ao digitar `fim`, ele roda o ajuste com **todas** as medidas salvas.

As medidas ficam **acumuladas** em `calib_logs/dados/`, uma por arquivo (`cal_<mm>mm_<data_hora>.txt`). Dá para medir 150 mm, desligar tudo, voltar outro dia, medir 200 mm e repetir 150 mm: o `fit` usa todas, e repetir uma distância deixa a média mais confiável. Cada ajuste salva, na mesma pasta:
- `resultado_<data_hora>.txt`: tabela, ajuste, erros antes e depois, variâncias;
- `blocos_<data_hora>.csv`: média, variância e falhas de cada bloco de 80 amostras;
- `calib_<data_hora>.h`: cópia do `calib.h` gerado.

O ajuste **recusa escrever o `calib.h`** se o resultado não fizer sentido. Isso acontece quando:
- o ganho fica fora de 0,8 a 1,25;
- o offset passa de 200 mm;
- o desvio padrão passa de 50 mm;
- a média não cresce com a distância;
- sobra um erro residual acima de 15 mm.

Nesse caso, use `lista` e `desfaz` para tirar a medida ruim e rode `fit` de novo.

**Limpeza dos dados.** Em cada distância, o `calib_fit.py` descarta sozinho os blocos em que o obstáculo provavelmente se mexeu: média longe da mediana dos blocos, ou variância mais de 10 vezes acima da típica. Ele informa quantos descartou. Se uma distância inteira estiver ruim só para um sensor, exclua-a só daquele sensor:

```bash
python3 tools/calib_fit.py --skip-tof 400 --skip-us 150 100:cal_100.txt 150:cal_150.txt ...
```

Um exemplo é o laser a 400 mm com obstáculo pequeno: o feixe do VL53L0X abre ~25°, então a 400 mm o ponto iluminado tem ~18 cm de diâmetro, e parte dele cai na parede de trás.

A **variância** gravada no `calib.h` é a incerteza da medida já corrigida, somando duas parcelas:
- o **ruído**: a oscilação com o obstáculo parado, dividida pelo ganho ao quadrado;
- o **erro que sobra depois da reta**: a média dos resíduos ao quadrado, já que o sensor não é perfeitamente linear.

É essa incerteza total que o filtro de Kalman deve usar.

**Quantas distâncias?** Três pontos (por exemplo, 150, 200 e 250 mm) bastam para a **variância**, que é medida em cada ponto. Também bastam para ajustar **ganho e offset**: são duas incógnitas, e o terceiro ponto confere o resultado. Mas a correção só é garantida **dentro da faixa calibrada**. Fora dela, um pequeno erro de ganho cresce com a distância. Por exemplo, 1 mm de erro na trena entre 150 e 250 mm vira cerca de 1% de erro de ganho, o que dá uns 10 mm a 1 m. Se o dispositivo for usado mais longe, inclua pelo menos um ponto na distância máxima de uso.

### Como calibrar, passo a passo manual

1. **Grave o firmware de calibração.** Ele não funde nada: junta 80 amostras brutas de cada sensor e imprime uma linha `CAL` com média, variância e falhas, a cada ~4 s.
   ```bash
   ./fpga/tang_primer_20k/build.sh calib
   ```
2. **Meça pelo menos 3 distâncias conhecidas** dentro da faixa de uso, por exemplo 100, 300 e 600 mm. Use um obstáculo plano, liso e perpendicular, maior que os dois feixes, e meça com trena a partir da frente dos sensores. Para cada distância, grave um log com pelo menos 4 linhas `CAL` (a primeira é descartada):
   ```bash
   tio -b 9600 /dev/ttyUSB1 -l cal_100.txt     # obstáculo a 100 mm; Ctrl-t q para sair
   tio -b 9600 /dev/ttyUSB1 -l cal_300.txt
   tio -b 9600 /dev/ttyUSB1 -l cal_600.txt
   ```
3. **Gere o `calib.h`:**
   ```bash
   python3 tools/calib_fit.py 100:cal_100.txt 300:cal_300.txt 600:cal_600.txt
   ```
   A ferramenta mostra, por distância, as médias, as variâncias, o erro antes e depois da correção, e escreve `frontend/firmware/soc/calib.h`. Com 1 distância só corrige o offset; com 2 ou mais faz mínimos quadrados (ganho e offset).
4. **Grave o firmware normal**, que recompila com a nova calibração:
   ```bash
   ./fpga/tang_primer_20k/build.sh all
   ```

Na saída normal, `dif` é a diferença entre os dois sensores **já corrigidos**. Com a calibração bem feita, ela deve ficar dentro do que a montagem permite (≤ 15 mm). Se a coluna `falhas` da calibração não for zero, algum sensor está perdendo leituras: confira fiação, divisor do ECHO e alinhamento.

### Saída do firmware normal

Uma linha por segundo:

```
#n US bruta>corr ToF bruta>corr dif | q var K | SW HW (n=nucleo) speedup
#  12 US  95> 100 ToF 129> 100 dif   0 | q  100 var  1 K .250 | SW 2239c 82.9us HW 247c 9.1us n22 9.1x ok
```

`K` é o peso dado ao laser. A saída é pequena de propósito: o conversor USB da Dock (BL702) perde blocos de texto quando recebe muito dado seguido. Se ainda faltarem linhas, ver `fpga/README.md`.

## Limitações conhecidas do Quark (do original)

- **Cálculo de endereços em 24 bits.** PC+imm (AUIPC, JAL, desvios) usa `ADDR_WIDTH` bits, 24 por padrão, então os 8 bits altos do resultado do AUIPC saem zerados. Isso é invisível para software que cabe em 16 MB, e o `isa_test` compara o AUIPC só nos 24 bits baixos.
- **FENCE não é suportado.** O decode trata `instr[3]` como JAL, e o FENCE tem esse bit em 1. Não use FENCE no firmware.
- **Sem CSRs nem interrupções.** Qualquer instrução SYSTEM lê o contador de ciclos (`rdcycle`).
- **Shifts lentos.** O shift anda 1 bit por ciclo (o `NRV_TWOLEVEL_SHIFTER` acelera).

## Próximos passos

- 8 `fusion_node` (fusion_core) no `periph_fusion`, com um banco de registradores por canal.
- UVM.
- DFT (`SYNTHESIS_WITH_DFT=yes`).
- Varredura de `CLK_PERIOD` olhando o slack que o `run.sh syn` imprime no final.
