# femtorv32: pacote completo do projeto

Dispositivo vestível para pessoas com necessidades especiais: SoC RISC-V (FemtoRV32 Quark) com coprocessador de fusão sensorial por AXI4-Lite. O pacote reúne RTL, firmware, verificação (testes dirigidos e UVM), síntese no Cadence Genus (com e sem DFT), FPGA (Tang Primer 20K), calibração e documentação.

Autora: Kyara Esteves de Sousa · Programa CI-Digital

## Onde está cada coisa

| Pasta | Conteúdo |
|---|---|
| `frontend/src/` | RTL do SoC: `femtorv32_quark.v` (adaptado para ASIC, marcas [ASIC-1..4]), `femto_sram.v`, `femto_ram_ff.v`, `soc/` (ponte, crossbar AXI4-Lite, periféricos, `femto_soc.v`), `fusion/` (`fusion_gain`, `channel`, `variance` e `node`) |
| `frontend/upstream/` | FemtoRV32 Quark **original**, sem alteração (Bruno Levy e Matthias Koch, learn-fpga, BSD-3), mais `asic_changes.diff` |
| `frontend/testbench/` | testbenches do processador, das memórias e do SoC (RTL e pós-síntese, com e sem DFT), mais o modelo I2C do VL53L0X |
| `frontend/firmware/` | firmware RV32I: `isa_test`, `c_suite`, `soc/` (firmware do SoC, `calib.h` com a calibração da placa) e `hex/` (imagens, incluindo `soc_fw_post_b*.hex` para a pós-síntese) |
| `tech/sram/` | macro de SRAM gerada pelo OpenRAM 1.2.48 (FreePDK45): `.lib`, `.lef`, `.v`, `.gds`, datasheet e `openram_config.py` |
| `backend/synthesis/scripts/` | fluxo Cadence: `run.sh` (pre, syn, post), `synthesis.tcl` (com e sem DFT), `tech.tcl`, `path.tcl` |
| `backend/synthesis/reports/` | relatórios do Genus: `femtorv32_quark`, `femto_sram`, `femto_ram_ff`, `femto_soc` (sem DFT) e `femto_soc_dft` (com scan: cadeias, regras de DFT, área, timing, potência) |
| `backend/synthesis/deliverables/` | netlists, SDF e SDC de cada síntese; `femto_soc_dft/atpg/` tem os arquivos para o Modus |
| `backend/synthesis/work/` | `genus.log` e esquemáticos (`.png`) de cada síntese; `work/pre/` tem os logs das simulações RTL no Xcelium (`isa_test`, `c_suite`, memórias, Quark com macros, SoC) |
| `fusion_core/` | **projeto do núcleo de fusão com UVM completa**: RTL do `fusion_core` (8 nós), `frontend/uvm/` (os 5 ambientes UVM: agente, sequências, scoreboard, cobertura), `backend/uvm/<bloco>/reports/` (logs, scoreboards e resultados dos 22 testes), `work/cov_work/` (banco de cobertura) e a síntese do `fusion_core` a 200 MHz (relatórios, netlist, esquemático) |
| `fpga/tang_primer_20k/` | top da FPGA, pinos (`.cst`), clock (`.sdc`), `build.tcl` e `build.sh` (linha de comando de ponta a ponta), `uart_baud_scan.sh` |
| `fpga/tang_primer_20k/femto_soc_tp20k/impl/` | resultados do Gowin: síntese, P&R, recursos, timing (Fmax 74,8 MHz), potência e bitstream (`.fs`) |
| `fpga/printscreens/`, `fpga/fotos/` | telas do terminal da placa e foto do circuito montado |
| `tools/` | calibração: `calib_session.sh` (coleta, com a distância real digitada), `calib_fit.py` (ajuste e `calib.h`) e `dados/` (resultado da calibração da placa) |
| `docs/REQUISITOS.md` | os 5 requisitos do projeto e onde cada um é atendido |
| `docs/artigo/` | artigo IEEE (conferência): `main.tex`, `figs/`, `fotos/` e o PDF compilado; sobe direto no Overleaf |
| `docs/slides_imagens/` | imagens usadas na apresentação: diagramas, esquema elétrico, fotos e as provas (`provas/`, trechos dos relatórios e logs) |

## Comandos principais

```bash
./exe.sh pre                                            # simulação RTL do processador
MODULE=femto_soc ./exe.sh pre                           # simulação RTL do SoC
MODULE=femto_soc ./exe.sh syn                           # síntese do SoC (Genus)
SYNTHESIS_WITH_DFT=yes MODULE=femto_soc ./exe.sh syn    # síntese com scan
MODULE=femto_sram ./exe.sh post                         # pós-síntese da memória (SDF)
MODULE=femto_soc ./exe.sh post                          # pós-síntese do SoC
SYNTHESIS_WITH_DFT=yes MODULE=femto_soc ./exe.sh post   # pós-síntese do SoC com DFT
./run_all_functional.sh                                 # regressão
./fpga/tang_primer_20k/build.sh all                     # FPGA: firmware, síntese, P&R, bitstream, gravação
./fpga/tang_primer_20k/build.sh calib ; ./tools/calib_session.sh   # calibração
cd fusion_core && ./run_all_modules.sh                  # UVM dos 5 blocos do núcleo
```

## Observações

- **Arquivos removidos:** as pastas `xcelium.d` (bibliotecas compiladas, de centenas de MB) foram tiradas. O Xcelium recria todas na primeira execução.
- **Firmware da placa:** os `soc_fw_b*.hex` em `fpga/tang_primer_20k/` são os do bitstream gravado. Os de `frontend/firmware/hex/` foram gerados a partir do código atual com a calibração da placa. O `build.sh` recompila e copia os novos.
- **Pós-síntese do SoC:** o fluxo com e sem DFT está pronto, mas os logs ainda não estão no pacote, porque precisam ser rodados no Xcelium.
