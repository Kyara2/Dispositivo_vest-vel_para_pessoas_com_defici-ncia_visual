#!/usr/bin/env python3
"""calib_fit.py -- calcula a calibracao dos sensores do femto_soc e gera
frontend/firmware/soc/calib.h

Fluxo:
 1. Grave o firmware de calibracao:  ./fpga/tang_primer_20k/build.sh calib
 2. Para CADA distancia de referencia (obstaculo plano, perpendicular, medido
    com trena a partir da frente dos sensores), deixe o tio gravando um log
    ate' aparecerem pelo menos 3 linhas "CAL ...", por exemplo:
        tio -b 9600 /dev/ttyUSB1 -l cal_100.txt     (obstaculo a 100 mm)
        tio -b 9600 /dev/ttyUSB1 -l cal_300.txt     (obstaculo a 300 mm)
        tio -b 9600 /dev/ttyUSB1 -l cal_600.txt     (obstaculo a 600 mm)
 3. Rode:
        python3 tools/calib_fit.py 100:cal_100.txt 300:cal_300.txt 600:cal_600.txt
    Ele mostra a tabela, os erros antes/depois e escreve o calib.h.
 4. Grave o firmware normal: ./fpga/tang_primer_20k/build.sh all

Com 1 distancia so' o offset e' corrigido (ganho = 1). Com 2 ou mais faz
minimos quadrados: bruta = a * real + b  ->  real = (bruta - b) / a.
A variancia vem do ruido medido (linhas CAL), dividida por a^2 (variancia
da medida ja' corrigida), e nunca fica abaixo de --var-min.
"""
import argparse, os, re, sys, datetime

CAL_RE = re.compile(r"CAL\s+n_us=(\d+)\s+us_mean=([\d.]+)\s+us_var=([\d.]+)\s+us_fail=(\d+)\s*\|\s*"
                    r"n_tof=(\d+)\s+tof_mean=([\d.]+)\s+tof_var=([\d.]+)\s+tof_fail=(\d+)")

def read_log(path):
    blocks = []
    with open(path, errors="ignore") as f:
        for line in f:
            m = CAL_RE.search(line)
            if m:
                v = m.groups()
                blocks.append(dict(n_us=int(v[0]), us_mean=float(v[1]), us_var=float(v[2]), us_fail=int(v[3]),
                                   n_tof=int(v[4]), tof_mean=float(v[5]), tof_var=float(v[6]), tof_fail=int(v[7])))
    return blocks

def reject_outliers(blocks, key, enabled=True):
    """Descarta blocos em que o obstaculo provavelmente se mexeu: media longe
    da mediana das medias (> 3 desvios robustos, minimo 3 mm) ou variancia
    muito acima da tipica (> 10x a mediana e > 25 mm^2)."""
    nk = "n_" + key
    good = [b for b in blocks if b[nk] > 0]
    if not enabled or len(good) < 3:
        return good, 0
    means = sorted(b[key + "_mean"] for b in good)
    vars_ = sorted(b[key + "_var"] for b in good)
    med = means[len(means) // 2]
    mad = sorted(abs(m - med) for m in means)[len(means) // 2] * 1.4826
    vmed = vars_[len(vars_) // 2]
    lim = max(3.0, 3 * mad)
    keep = [b for b in good if abs(b[key + "_mean"] - med) <= lim
            and not (b[key + "_var"] > 10 * max(vmed, 1.0) and b[key + "_var"] > 25)]
    return keep, len(good) - len(keep)

def pooled(blocks, key):
    nk = "n_" + key
    n = sum(b[nk] for b in blocks)
    if n == 0:
        return None, None, 0
    mean = sum(b[key + "_mean"] * b[nk] for b in blocks) / n
    # variancia combinada: media das variancias + espalhamento entre blocos
    var = sum(b[nk] * (b[key + "_var"] + (b[key + "_mean"] - mean) ** 2) for b in blocks) / n
    return mean, var, n

def fit(refs, means):
    if len(set(refs)) == 1:              # uma distancia so' (ou repetida): corrige so' o offset
        return 1.0, sum(means) / len(means) - refs[0]
    n = len(refs); sx = sum(refs); sy = sum(means)
    sxx = sum(x * x for x in refs); sxy = sum(x * y for x, y in zip(refs, means))
    a = (n * sxy - sx * sy) / (n * sxx - sx * sx)
    b = (sy - a * sx) / n
    return a, b

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pairs", nargs="+", help="DIST_MM:arquivo_de_log (uma por distancia)")
    ap.add_argument("--skip", type=int, default=1, help="descarta as N primeiras linhas CAL de cada log (sensor estabilizando)")
    ap.add_argument("--var-min", type=float, default=1.0, help="variancia minima (mm^2)")
    ap.add_argument("--skip-us", default="", help="distancias (mm) a ignorar SO' no ultrassom, ex.: 150 ou 150,400")
    ap.add_argument("--skip-tof", default="", help="distancias (mm) a ignorar SO' no laser, ex.: 400")
    ap.add_argument("--no-reject", action="store_true", help="nao descarta blocos discrepantes dentro de cada distancia")
    ap.add_argument("--csv", help="grava todas as linhas CAL usadas (por distancia e bloco) neste CSV")
    ap.add_argument("--force", action="store_true", help="escreve o calib.h mesmo se a checagem de sanidade falhar")
    ap.add_argument("-o", "--out", default=os.path.join(os.path.dirname(__file__), "..", "frontend", "firmware", "soc", "calib.h"))
    a = ap.parse_args()

    skip_us = {x.strip() for x in a.skip_us.split(",") if x.strip()}
    skip_tof = {x.strip() for x in a.skip_tof.split(",") if x.strip()}
    rows = []
    csv_rows = []
    for p in a.pairs:
        ref, path = p.split(":", 1)
        blocks = read_log(path)[a.skip:]
        for i, b in enumerate(blocks, 1):
            csv_rows.append((ref, i, b["n_us"], b["us_mean"], b["us_var"], b["us_fail"],
                             b["n_tof"], b["tof_mean"], b["tof_var"], b["tof_fail"]))
        if not blocks:
            sys.exit(f"ERRO: nenhuma linha CAL utilizavel em {path} (rodou o firmware de calibracao? esperou >= {a.skip+1} linhas?)")
        bu, du = reject_outliers(blocks, "us", not a.no_reject)
        bt, dt = reject_outliers(blocks, "tof", not a.no_reject)
        if du or dt:
            print(f"{float(ref):6.0f} mm: descartados {du} bloco(s) do US e {dt} do ToF (obstaculo mexendo?)")
        us = pooled(bu, "us") if str(int(float(ref))) not in skip_us else (None, None, 0)
        tof = pooled(bt, "tof") if str(int(float(ref))) not in skip_tof else (None, None, 0)
        fails = (sum(b["us_fail"] for b in blocks), sum(b["tof_fail"] for b in blocks))
        rows.append((float(ref), us, tof, fails, len(blocks)))

    if a.csv:
        with open(a.csv, "w") as f:
            f.write("dist_mm,bloco,n_us,us_media,us_var,us_falhas,n_tof,tof_media,tof_var,tof_falhas\n")
            for r in csv_rows:
                f.write(",".join(str(x) for x in r) + "\n")
        print(f"amostras por bloco gravadas em {a.csv}")

    print(f"{'ref':>6} | {'US media':>9} {'var':>6} {'n':>5} {'falhas':>6} | {'ToF media':>9} {'var':>6} {'n':>5} {'falhas':>6}")
    for ref, us, tof, fails, nb in rows:
        print(f"{ref:6.0f} | {us[0] or 0:9.2f} {us[1] or 0:6.2f} {us[2]:5d} {fails[0]:6d} | {tof[0] or 0:9.2f} {tof[1] or 0:6.2f} {tof[2]:5d} {fails[1]:6d}")

    out = {}
    for key, idx in (("US", 1), ("TOF", 2)):
        pts = [(r[0], r[idx][0], r[idx][1]) for r in rows if r[idx][0] is not None]
        if not pts:
            sys.exit(f"ERRO: sem medidas validas do sensor {key}")
        refs = [p[0] for p in pts]; means = [p[1] for p in pts]
        ga, gb = fit(refs, means)
        gain = 1.0 / ga; offset = -gb / ga
        gain_q12 = int(round(gain * 4096)); off_i = int(round(offset))
        resid = [(m * gain_q12 / 4096 + off_i) - r for r, m in zip(refs, means)]
        # variancia da medida CORRIGIDA = ruido (oscilacao com o obstaculo parado)
        # + erro que sobra depois da reta (o sensor nao e' perfeitamente linear).
        # E' a incerteza real que a fusao deve usar.
        noise = sum(p[2] for p in pts) / len(pts) / (ga * ga)
        model = sum(e * e for e in resid) / len(resid)
        var = max(a.var_min, noise + model)
        out[key] = (gain_q12, off_i, int(round(var)) if var >= 1 else 1, ga, gb, resid, means, refs)
        print(f"\n{key}: bruta = {ga:.4f} * real {gb:+.2f}  ->  real = bruta * {gain:.4f} {offset:+.1f}")
        for r, m, e in zip(refs, means, resid):
            print(f"   {r:6.0f} mm: bruta {m:8.2f} (erro {m - r:+6.1f})  ->  corrigida erro {e:+5.1f} mm")
        print(f"   variancia da medida corrigida: {var:.2f} mm^2 (std {var ** 0.5:.2f} mm)"
              f"  = ruido {noise:.2f} + residuo da reta {model:.2f}")
        if key == "US" and skip_us:  print(f"   (ignorado no US: {', '.join(sorted(skip_us))} mm)")
        if key == "TOF" and skip_tof: print(f"   (ignorado no ToF: {', '.join(sorted(skip_tof))} mm)")

    # ---- sanidade: protege contra obstaculo nao movido, distancia digitada
    #      errada ou sensor sem leitura. Um sensor de distancia real tem ganho
    #      perto de 1 e offset de poucos centimetros.
    problems = []
    for key in ("US", "TOF"):
        g_q12, off_i, var_i, ga, gb, resid, means, refs = out[key]
        gain = g_q12 / 4096
        if not (0.8 <= gain <= 1.25):
            problems.append(f"{key}: ganho {gain:.3f} fora de 0,8..1,25 (as medias quase nao mudaram entre as distancias?)")
        if abs(off_i) > 200:
            problems.append(f"{key}: offset {off_i} mm grande demais")
        if var_i > 2500:
            problems.append(f"{key}: variancia {var_i} mm^2 (std > 50 mm): leitura instavel ou obstaculo mexendo")
        if len(refs) >= 2:
            order = sorted(zip(refs, means))
            if any(b[0] > a[0] and b[1] <= a[1] for a, b in zip(order, order[1:])):
                problems.append(f"{key}: a media nao cresce com a distancia ({', '.join(f'{r:.0f}->{m:.1f}' for r, m in order)})")
        if max(abs(e) for e in resid) > 15:
            problems.append(f"{key}: erro residual de {max(abs(e) for e in resid):.1f} mm depois da correcao")
    if problems:
        print("\nATENCAO -- a calibracao nao parece valida:")
        for pr in problems:
            print("  -", pr)
        if not a.force:
            print("calib.h NAO foi alterado. Refaca as medidas (ou use --force se tiver certeza).")
            sys.exit(2)

    us, tof = out["US"], out["TOF"]
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    src = ", ".join(f"{r[0]:.0f} mm" for r in rows)
    h = f"""/* calib.h -- calibracao dos sensores do femto_soc
 * GERADO por tools/calib_fit.py em {now} (distancias: {src}). Nao editar
 * a mao sem necessidade -- rode a calibracao de novo.
 *   dist_corrigida = (bruta * GANHO_Q12 + 2048) / 4096 + OFFSET
 *   variancia      = sigma^2 (mm^2) da medida corrigida (usada pela fusao)
 *   US : bruta = {us[3]:.4f} * real {us[4]:+.2f}
 *   ToF: bruta = {tof[3]:.4f} * real {tof[4]:+.2f}
 */
#ifndef CALIB_H
#define CALIB_H

#define CAL_US_GAIN_Q12   {us[0]:6d}
#define CAL_US_OFFSET_MM  {us[1]:6d}
#define CAL_US_VAR_MM2    {us[2]:6d}

#define CAL_TOF_GAIN_Q12  {tof[0]:6d}
#define CAL_TOF_OFFSET_MM {tof[1]:6d}
#define CAL_TOF_VAR_MM2   {tof[2]:6d}

#define CAL_VAR_MIN_MM2   {max(1, int(a.var_min)):6d}

#endif
"""
    with open(a.out, "w") as f:
        f.write(h)
    print(f"\nescrito: {os.path.normpath(a.out)}")
    print("agora: ./fpga/tang_primer_20k/build.sh all   (recompila o firmware com a calibracao e grava)")

if __name__ == "__main__":
    main()
