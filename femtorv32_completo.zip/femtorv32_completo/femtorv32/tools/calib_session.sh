#!/bin/bash
# calib_session.sh -- calibracao dos sensores do femto_soc, uma distancia por vez
# Author: Kyara Esteves de Sousa
#
# Pre-requisito: firmware de CALIBRACAO gravado (./fpga/tang_primer_20k/build.sh calib)
# e o tio/screen FECHADO (so' um programa abre a porta por vez).
#
# Uso (da raiz do projeto):
#   ./tools/calib_session.sh            mede: voce digita a distancia REAL (ex.: 150 [Enter]),
#                                       ele grava, salva e pede a proxima; "fim" calcula
#   ./tools/calib_session.sh fit        so' calcula, com tudo que ja' foi medido
#   ./tools/calib_session.sh lista      mostra as medidas salvas
#   ./tools/calib_session.sh desfaz     apaga a ultima medida salva
#   ./tools/calib_session.sh nova       arquiva as medidas atuais e comeca do zero
#
# As medidas ficam ACUMULADAS em calib_logs/dados/ (uma por arquivo,
# cal_<mm>mm_<data_hora>.txt). Da' para medir 150 hoje, desligar tudo, medir
# 200 amanha e repetir 150 depois: o "fit" usa todas. Repetir a mesma
# distancia e' bom -- a media fica mais confiavel.
#
# Cada medida grava ate' juntar MIN_BLOCKS linhas "CAL" (padrao 5, alem da
# primeira, descartada). Cada linha = 80 amostras de CADA sensor -> 400
# medidas por sensor por distancia.
#
# Variaveis: PORT (/dev/ttyUSB1)  BAUD (9600)  MIN_BLOCKS (5)  MAX_SECONDS (240)
#            CALIB_H (para escrever o calib.h em outro lugar, ex.: teste)

set -e
PORT=${PORT:-/dev/ttyUSB1}
BAUD=${BAUD:-9600}
MIN_BLOCKS=${MIN_BLOCKS:-5}
MAX_SECONDS=${MAX_SECONDS:-240}

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DATA="$ROOT/calib_logs/dados"
mkdir -p "$DATA"

CAL_RE="CAL +n_us=[0-9]+ +us_mean=[0-9.]+ +us_var=[0-9.]+ +us_fail=[0-9]+ +\| +n_tof=[0-9]+ +tof_mean=[0-9.]+ +tof_var=[0-9.]+ +tof_fail=[0-9]+"
count_cal () { tr -d '\r' < "$1" | grep -cE "$CAL_RE" || true; }
files () { ls "$DATA"/cal_*mm_*.txt 2>/dev/null | sort; }
dist_of () { basename "$1" | sed -E 's/cal_([0-9]+)mm_.*/\1/'; }

# ---------------------------------------------------------------- lista
do_list () {
    local F N=0
    echo "Medidas salvas em $DATA:"
    for F in $(files); do
        N=$((N+1))
        printf "  %3d) %5s mm  %3d blocos CAL  %s\n" "$N" "$(dist_of "$F")" "$(count_cal "$F")" "$(basename "$F")"
    done
    [ $N -eq 0 ] && echo "  (nenhuma)"
    return 0
}

# ---------------------------------------------------------------- ajuste
do_fit () {
    local PAIRS=() F TS
    for F in $(files); do PAIRS+=("$(dist_of "$F"):$F"); done
    [ ${#PAIRS[@]} -eq 0 ] && { echo "Nenhuma medida salva -- rode ./tools/calib_session.sh e meça."; exit 1; }
    TS=$(date '+%Y%m%d_%H%M%S')
    echo "=============================================================="
    echo " Ajuste com ${#PAIRS[@]} medida(s) salva(s)"
    echo "=============================================================="
    local OUT_ARGS=(); [ -n "$CALIB_H" ] && OUT_ARGS=(-o "$CALIB_H")
    set +e
    python3 "$ROOT/tools/calib_fit.py" --csv "$DATA/blocos_$TS.csv" "${OUT_ARGS[@]}" "${PAIRS[@]}" 2>&1 | tee "$DATA/resultado_$TS.txt"
    local RC=${PIPESTATUS[0]}
    set -e
    if [ "$RC" -eq 0 ]; then
        cp "${CALIB_H:-$ROOT/frontend/firmware/soc/calib.h}" "$DATA/calib_$TS.h"
        echo
        echo "Salvo: resultado_$TS.txt, blocos_$TS.csv e calib_$TS.h em $DATA"
        echo "Proximo passo: ./fpga/tang_primer_20k/build.sh all   (firmware normal com a calibracao)"
    else
        echo
        echo "Ajuste recusado: calib.h nao foi alterado. Veja $DATA/resultado_$TS.txt"
        echo "(use '$0 lista' e '$0 desfaz' para tirar uma medida ruim e tente de novo)"
    fi
    return 0
}

# ---------------------------------------------------------------- uma medida
measure () {
    local D=$1 TS LOG CPID T0 N EL USED NUS FUS NTOF FTOF NEED
    TS=$(date '+%Y%m%d_%H%M%S')
    LOG="$DATA/cal_${D}mm_${TS}.txt"
    timeout 1.5 cat "$PORT" > /dev/null 2>&1 || true      # descarta texto antigo do buffer
    : > "$LOG"
    cat "$PORT" >> "$LOG" &
    CPID=$!
    T0=$(date +%s); NEED=$((MIN_BLOCKS + 1)); N=0
    while :; do
        sleep 2
        N=$(count_cal "$LOG")
        EL=$(( $(date +%s) - T0 ))
        printf "\r   gravando %s mm... %3d s   blocos CAL: %d/%d " "$D" "$EL" "$N" "$NEED"
        [ "$N" -ge "$NEED" ] && break
        [ "$EL" -ge "$MAX_SECONDS" ] && break
    done
    kill "$CPID" 2>/dev/null || true; wait "$CPID" 2>/dev/null || true
    echo
    USED=$(( N > 0 ? N - 1 : 0 ))
    read -r NUS FUS NTOF FTOF < <(tr -d '\r' < "$LOG" | grep -oE "$CAL_RE" | tail -n +2 | \
        sed -E 's/.*n_us=([0-9]+).*us_fail=([0-9]+).*n_tof=([0-9]+).*tof_fail=([0-9]+).*/\1 \2 \3 \4/' | \
        awk '{a+=$1;b+=$2;c+=$3;d+=$4} END{print a+0, b+0, c+0, d+0}')
    tr -d '\r' < "$LOG" | grep -E "^CAL" | tail -1 | sed 's/^/   ultima: /'
    echo "   US: $NUS medidas ($FUS falhas)  |  ToF: $NTOF medidas ($FTOF falhas)"
    if [ "$USED" -lt "$MIN_BLOCKS" ]; then
        rm -f "$LOG"
        echo "   so' $USED blocos em ${MAX_SECONDS} s -- medida DESCARTADA."
        echo "   O firmware de calibracao esta' gravado? (apertando S0 aparece 'MODO CALIBRACAO')"
        return 0
    fi
    if [ "$FUS" -gt 0 ] || [ "$FTOF" -gt 0 ]; then
        echo "   aviso: houve falhas de leitura (fiacao? divisor do ECHO? obstaculo inclinado?)"
    fi
    echo "   salvo: $(basename "$LOG")"
}

do_undo () {
    local L; L=$(files | tail -1)
    [ -z "$L" ] && { echo "   nada para desfazer."; return 0; }
    rm -f "$L"; echo "   apagada: $(basename "$L")"
}

do_measure () {
    [ -e "$PORT" ] || { echo "ERRO: $PORT nao existe (placa conectada? use PORT=/dev/ttyUSB0)."; exit 1; }
    stty -F "$PORT" "$BAUD" raw -echo cs8 -cstopb -parenb -crtscts || {
        echo "ERRO: nao consegui configurar $PORT (permissao? veja fpga/README.md, regra udev)."; exit 1; }
    echo "=============================================================="
    echo " Calibracao -- porta $PORT, $BAUD baud, $((MIN_BLOCKS*80)) medidas por sensor"
    echo " Obstaculo PLANO, perpendicular, maior que os dois feixes. Meça com"
    echo " trena da FRENTE dos sensores. Nao fique na frente enquanto grava."
    echo "=============================================================="
    do_list
    echo
    while true; do
        read -r -p ">> Distancia REAL do obstaculo em mm (ex.: 150), 'lista', 'desfaz' ou 'fim': " ans \
            || { echo; break; }
        case "$ans" in
            fim|f|q)    break ;;
            lista|l)    do_list ;;
            desfaz|d)   do_undo ;;
            *)
                if [[ "$ans" =~ ^[0-9]+$ ]] && [ "$ans" -ge 20 ] && [ "$ans" -le 4000 ]; then
                    measure "$ans"
                else
                    echo "   digite so' o numero em mm (20 a 4000), 'lista', 'desfaz' ou 'fim'."
                fi ;;
        esac
        echo
    done
    echo
    do_fit
}

do_new () {
    if [ -n "$(files)" ]; then
        local A="$ROOT/calib_logs/arquivo_$(date '+%Y%m%d_%H%M%S')"
        mv "$DATA" "$A"; mkdir -p "$DATA"
        echo "Medidas anteriores arquivadas em $A. Pode comecar de novo."
    else
        echo "Nao havia medidas -- ja' esta' vazio."
    fi
}

case "${1:-medir}" in
    medir)    do_measure ;;
    fit)      do_fit ;;
    lista)    do_list ;;
    desfaz)   do_undo ;;
    nova)     do_new ;;
    -h|--help|help) sed -n '2,27p' "$0" | sed 's/^# \{0,1\}//' ;;
    *) echo "comando desconhecido: $1"; sed -n '8,14p' "$0" | sed 's/^# \{0,1\}//'; exit 1 ;;
esac
