#!/bin/bash

clear && clear;

echo "Calling run.sh with arguments: $@"

./backend/synthesis/scripts/run.sh "$@"
