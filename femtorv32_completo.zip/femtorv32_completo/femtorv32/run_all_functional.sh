#!/bin/bash
# run_all_functional.sh -- roda TODOS os testes funcionais em lote e imprime
# um resumo. Chame a partir da raiz do projeto:
#
#   ./run_all_functional.sh          # RTL (pre-synthesis)
#   ./run_all_functional.sh post     # netlists do Genus (rode os ./exe.sh syn antes;
#                                    # designs sem netlist sao pulados)
#
# Testes:
#   femtorv32_quark x {isa_test, c_suite} x {sem, com wait states}
#   femto_sram       RAM com macros OpenRAM (testbench de memoria)
#   femto_ram_ff     RAM em flip-flops (mesmo testbench)
#   femtorv32_sram   Quark executando o c_suite a partir da femto_sram (so' pre)
#   femto_soc        SoC completo rodando o soc_fw (sensores simulados, fusao SW x HW) (so' pre)

set -u
STAGE=${1:-pre}
if [ "$STAGE" != "pre" ] && [ "$STAGE" != "post" ]; then
    echo "uso: $0 [pre|post]"; exit 1
fi

# "MODULE PROGRAM WAITSTATES" (PROGRAM/WAITSTATES '-' para testbench de memoria)
JOBS=(
  "femtorv32_quark isa_test 0"
  "femtorv32_quark isa_test 1"
  "femtorv32_quark c_suite 0"
  "femtorv32_quark c_suite 1"
  "femto_sram - -"
  "femto_ram_ff - -"
  "femtorv32_sram c_suite_8k 0"
  "femto_soc soc_fw -"
)

declare -a RESULTS_SUMMARY
TOTAL=0; FAILED=0; SKIPPED=0
DELIV=backend/synthesis/deliverables

for J in "${JOBS[@]}"; do
    read MOD PROG WS <<< "$J"
    if [ "$STAGE" == "post" ]; then
        if [ "$MOD" == "femtorv32_sram" ] || [ "$MOD" == "femto_soc" ]; then continue; fi
        if [ ! -f "$DELIV/$MOD/${MOD}_netlist.v" ]; then
            RESULTS_SUMMARY+=("----  $MOD   (sem netlist -- rode MODULE=$MOD ./exe.sh syn)")
            SKIPPED=$((SKIPPED+1)); continue
        fi
    fi
    TOTAL=$((TOTAL+1))
    ENVS="MODULE=$MOD SEED=$((TOTAL*17))"
    [ "$PROG" != "-" ] && ENVS="$ENVS PROGRAM=$PROG"
    [ "$WS" != "-" ] && ENVS="$ENVS WAITSTATES=$WS"
    TMPLOG=/tmp/${MOD}_${STAGE}_${PROG}_ws${WS}_$$.log
    echo "=============================================================="
    echo ">> $STAGE  $ENVS"
    echo "=============================================================="
    env $ENVS ./exe.sh $STAGE > $TMPLOG 2>&1
    grep -E "FUNCTIONAL_RESULT|RESULT: FAIL|\[tb\] ciclos|\[tb\] fase" $TMPLOG
    LABEL="$MOD"; [ "$PROG" != "-" ] && LABEL="$MOD  $PROG"; [ "$WS" != "-" ] && LABEL="$LABEL  ws=$WS"
    if grep -q "FUNCTIONAL_RESULT: PASS" $TMPLOG; then
        RESULTS_SUMMARY+=("PASS  $LABEL")
    else
        RESULTS_SUMMARY+=("FAIL  $LABEL   (ver $TMPLOG)")
        FAILED=$((FAILED+1))
    fi
done

echo
echo "=============================================================="
echo "RESUMO / $STAGE ($((TOTAL-FAILED))/${TOTAL} PASS, $SKIPPED pulados)"
echo "=============================================================="
for line in "${RESULTS_SUMMARY[@]}"; do echo "$line"; done

if [ $FAILED -eq 0 ]; then
    echo; echo "TUDO PASSOU."; exit 0
else
    echo; echo "$FAILED teste(s) falharam -- confere os logs apontados acima."; exit 1
fi
