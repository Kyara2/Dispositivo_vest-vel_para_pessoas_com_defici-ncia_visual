#!/usr/bin/env python3
"""
gen_isa_test.py -- gera isa_test.S, um teste autoverificavel de TODAS as
instrucoes RV32I suportadas pelo FemtoRV32 Quark.

Os valores esperados sao calculados aqui por um modelo de referencia em
Python (independente do RTL). Cada caso tem um numero (gp = x3); se o
resultado do processador divergir, o programa escreve (gp<<1)|1 no TOHOST
e o testbench reporta "RESULT: FAIL ... teste <gp>". Se todos passarem,
escreve 1 (PASS).

Uso:  python3 gen_isa_test.py [--seed N] [--random N] > isa_test.S
"""
import argparse
import random

M32 = 0xFFFFFFFF
ADDR_WIDTH = 24   # parametro ADDR_WIDTH do femtorv32_quark


def s32(x):
    x &= M32
    return x - (1 << 32) if x & 0x80000000 else x


def u32(x):
    return x & M32


# ---------------------------------------------------------------- modelo
def alu(op, a, b):
    a, b = u32(a), u32(b)
    sh = b & 31
    if op in ("add", "addi"):   return u32(a + b)
    if op == "sub":             return u32(a - b)
    if op in ("xor", "xori"):   return a ^ b
    if op in ("or", "ori"):     return a | b
    if op in ("and", "andi"):   return a & b
    if op in ("slt", "slti"):   return 1 if s32(a) < s32(b) else 0
    if op in ("sltu", "sltiu"): return 1 if a < b else 0
    if op in ("sll", "slli"):   return u32(a << sh)
    if op in ("srl", "srli"):   return a >> sh
    if op in ("sra", "srai"):   return u32(s32(a) >> sh)
    raise ValueError(op)


def branch(op, a, b):
    a, b = u32(a), u32(b)
    return {
        "beq":  a == b,
        "bne":  a != b,
        "blt":  s32(a) < s32(b),
        "bge":  s32(a) >= s32(b),
        "bltu": a < b,
        "bgeu": a >= b,
    }[op]


# ---------------------------------------------------------------- emissao
class Gen:
    def __init__(self):
        self.lines = []
        self.n = 0

    def emit(self, s=""):
        self.lines.append(s)

    def new_test(self, comment):
        self.n += 1
        self.emit(f"    # --- teste {self.n}: {comment}")
        self.emit(f"    li   gp, {self.n}")
        return self.n

    def check(self, reg, expected):
        self.emit(f"    li   t6, 0x{u32(expected):08x}")
        self.emit(f"    bne  {reg}, t6, fail")

    # rd = rs1 op rs2
    def rr(self, op, a, b, rd="a4", r1="a1", r2="a2"):
        exp = alu(op, a, b)
        self.new_test(f"{op} 0x{u32(a):08x}, 0x{u32(b):08x} -> 0x{exp:08x}")
        self.emit(f"    li   {r1}, 0x{u32(a):08x}")
        if r2 != r1:
            self.emit(f"    li   {r2}, 0x{u32(b):08x}")
        self.emit(f"    {op:<6}{rd}, {r1}, {r2}")
        self.check(rd, exp)

    # rd = rs1 op imm
    def ri(self, op, a, imm, rd="a4", r1="a1"):
        exp = alu(op, a, imm)
        self.new_test(f"{op} 0x{u32(a):08x}, {imm} -> 0x{exp:08x}")
        self.emit(f"    li   {r1}, 0x{u32(a):08x}")
        self.emit(f"    {op:<6}{rd}, {r1}, {imm}")
        self.check(rd, exp)

    def br(self, op, a, b):
        taken = branch(op, a, b)
        t = self.new_test(f"{op} 0x{u32(a):08x}, 0x{u32(b):08x} -> {'taken' if taken else 'not taken'}")
        self.emit(f"    li   a1, 0x{u32(a):08x}")
        self.emit(f"    li   a2, 0x{u32(b):08x}")
        self.emit("    li   a4, 0")
        if taken:
            # desvio para frente deve ser tomado; o "li a4,1" e' pulado
            self.emit(f"    {op:<6}a1, a2, 1f")
            self.emit("    j    fail")
            self.emit("1:  li   a4, 1")
            self.check("a4", 1)
        else:
            self.emit(f"    {op:<6}a1, a2, fail")
            self.emit("    li   a4, 1")
            self.check("a4", 1)


IMM12_EDGES = [0, 1, -1, 2047, -2048, 0x7FF, 0x555, -0x556, 15, -16]
VAL_EDGES = [0, 1, 2, 0x7FFFFFFF, 0x80000000, 0xFFFFFFFF, 0xFFFFFFFE,
             0x55555555, 0xAAAAAAAA, 0x0000FFFF, 0xFFFF0000, 0x12345678,
             0x80000001, 0x00000800, 0xFFFFF800]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--random", type=int, default=12,
                    help="casos aleatorios por instrucao (alem das bordas)")
    args = ap.parse_args()
    rnd = random.Random(args.seed)

    g = Gen()
    g.emit("/* isa_test.S -- GERADO por gen_isa_test.py, nao editar a mao.")
    g.emit(f" * seed={args.seed} random={args.random}")
    g.emit(" * Teste autoverificavel RV32I para o FemtoRV32 Quark. */")
    g.emit('#include "femto_io.h"')
    g.emit("")
    g.emit("    .section .text.init")
    g.emit("    .globl _start")
    g.emit("_start:")
    for r in range(1, 32):
        g.emit(f"    li   x{r}, 0")
    g.emit("    la   sp, __stack_top")
    g.emit("")

    # ---------------- x0 sempre zero
    g.new_test("escrita em x0 e' ignorada")
    g.emit("    li   x0, 0x123")
    g.emit("    addi x0, x0, 77")
    g.emit("    add  a4, x0, x0")
    g.check("a4", 0)
    g.new_test("lui em x0 e' ignorado")
    g.emit("    lui  x0, 0xABCDE")
    g.emit("    mv   a4, x0")
    g.check("a4", 0)

    # ---------------- LUI
    for imm in [0, 1, 0x80000, 0xFFFFF, 0x12345, 0x7FFFF]:
        g.new_test(f"lui 0x{imm:05x}")
        g.emit(f"    lui  a4, 0x{imm:05x}")
        g.check("a4", imm << 12)

    # ---------------- AUIPC (compara com o endereco obtido por jal)
    # ATENCAO: no Quark, PC+imm (AUIPC/JAL/branch) e' calculado com
    # ADDR_WIDTH bits (24 por default) -- os 8 bits altos do resultado do
    # AUIPC saem zerados. E' uma limitacao documentada do FemtoRV (economia
    # de area), invisivel para software cujo espaco de enderecamento cabe em
    # 16 MB. Por isso a comparacao e' feita so' nos ADDR_WIDTH bits baixos.
    addr_mask = (1 << ADDR_WIDTH) - 1
    for imm in [0, 1, 0x10, 0x7FF, 0xFFF, 0x7FFFF, 0x80000, 0xFFFFF]:
        g.new_test(f"auipc 0x{imm:05x} (comparado em {ADDR_WIDTH} bits)")
        g.emit("    jal  a5, 1f")            # a5 = endereco do auipc
        g.emit(f"1:  auipc a4, 0x{imm:05x}")
        g.emit(f"    li   t5, 0x{(imm << 12) & M32:08x}")
        g.emit("    add  a5, a5, t5")
        g.emit(f"    li   t5, 0x{addr_mask:08x}")
        g.emit("    and  a4, a4, t5")
        g.emit("    and  a5, a5, t5")
        g.emit("    bne  a4, a5, fail")
    g.new_test("auipc + addi (uso real: endereco PC-relativo de um simbolo)")
    g.emit("    la   a4, tdat")           # o assembler gera auipc+addi
    g.emit("    lw   a4, 0(a4)")
    g.check("a4", 0x83828180)

    # ---------------- ALU registrador-registrador
    rr_ops = ["add", "sub", "xor", "or", "and", "slt", "sltu", "sll", "srl", "sra"]
    for op in rr_ops:
        pairs = [(a, b) for a in VAL_EDGES[:8] for b in VAL_EDGES[:8]]
        rnd.shuffle(pairs)
        pairs = pairs[:10]
        if op in ("sll", "srl", "sra"):
            # todas as quantidades 0..31, e bits altos de rs2 que devem ser ignorados
            pairs = [(0x80000001 ^ (sh * 0x01010101), sh) for sh in range(32)]
            pairs += [(0xDEADBEEF, 0xFFFFFFE0 | 7), (0x80000000, 0x00000020), (0xF0F0F0F0, 0x1F)]
        for a, b in pairs:
            g.rr(op, a, b)
        for _ in range(args.random):
            g.rr(op, rnd.getrandbits(32), rnd.getrandbits(32))

    # ---------------- ALU com imediato
    ri_ops = ["addi", "xori", "ori", "andi", "slti", "sltiu"]
    for op in ri_ops:
        for imm in IMM12_EDGES:
            g.ri(op, rnd.choice(VAL_EDGES), imm)
        for _ in range(args.random):
            g.ri(op, rnd.getrandbits(32), rnd.randint(-2048, 2047))
    for op in ["slli", "srli", "srai"]:
        for sh in range(32):
            g.ri(op, 0x80000001 ^ (sh * 0x01234567), sh)
        for _ in range(args.random // 2):
            g.ri(op, rnd.getrandbits(32), rnd.randint(0, 31))

    # ---------------- casos com rd == rs1 == rs2 (dependencia no mesmo reg)
    for op in ["add", "sub", "xor", "sll", "sra"]:
        a = 0x00000013 if op in ("sll", "sra") else 0x87654321
        exp = alu(op, a, a)
        g.new_test(f"{op} rd=rs1=rs2")
        g.emit(f"    li   a1, 0x{a:08x}")
        g.emit(f"    {op:<6}a1, a1, a1")
        g.check("a1", exp)
    g.new_test("cadeia de dependencias (addi encadeado)")
    g.emit("    li   a1, 0")
    for _ in range(10):
        g.emit("    addi a1, a1, 3")
    g.emit("    slli a1, a1, 2")
    g.emit("    srai a1, a1, 1")
    g.check("a1", 60)

    # ---------------- desvios condicionais
    br_ops = ["beq", "bne", "blt", "bge", "bltu", "bgeu"]
    cmp_pairs = [(0, 0), (1, 0), (0, 1), (0xFFFFFFFF, 0), (0, 0xFFFFFFFF),
                 (0x80000000, 0x7FFFFFFF), (0x7FFFFFFF, 0x80000000),
                 (0xFFFFFFFF, 0xFFFFFFFF), (0x80000000, 0x80000000), (5, -5)]
    for op in br_ops:
        for a, b in cmp_pairs:
            g.br(op, a, b)
        for _ in range(args.random // 2):
            a = rnd.getrandbits(32)
            b = a if rnd.random() < 0.3 else rnd.getrandbits(32)
            g.br(op, a, b)

    # desvio para tras (laco)
    g.new_test("bne para tras: laco de 20 iteracoes")
    g.emit("    li   a1, 20")
    g.emit("    li   a4, 0")
    g.emit("2:  addi a4, a4, 7")
    g.emit("    addi a1, a1, -1")
    g.emit("    bne  a1, zero, 2b")
    g.check("a4", 140)

    # ---------------- JAL / JALR
    g.new_test("jal: link = pc+4, alvo correto")
    g.emit("    jal  a4, 1f")
    g.emit("2:  j    fail")
    g.emit("1:  la   a5, 2b")
    g.emit("    bne  a4, a5, fail")

    g.new_test("jalr com offset positivo e link")
    g.emit("    la   a1, 1f - 8")
    g.emit("    jalr a4, 8(a1)")
    g.emit("2:  j    fail")
    g.emit("1:  la   a5, 2b")
    g.emit("    bne  a4, a5, fail")

    g.new_test("jalr com offset negativo")
    g.emit("    la   a1, 1f + 12")
    g.emit("    jalr a4, -12(a1)")
    g.emit("    j    fail")
    g.emit("1:  nop")

    g.new_test("jalr zera o bit 0 do alvo")
    g.emit("    la   a1, 1f")
    g.emit("    addi a1, a1, 1")
    g.emit("    jalr x0, 0(a1)")
    g.emit("    j    fail")
    g.emit("1:  nop")

    g.new_test("jalr rd == rs1")
    g.emit("    la   a1, 1f")
    g.emit("    jalr a1, 0(a1)")
    g.emit("2:  j    fail")
    g.emit("1:  la   a5, 2b")
    g.emit("    bne  a1, a5, fail")

    g.new_test("call/ret (sub-rotina)")
    g.emit("    li   a0, 5")
    g.emit("    call sub_times3")
    g.check("a0", 15)

    # ---------------- LOAD
    data = [0x8382_8180, 0x7F7E_FF01, 0x1234_5678, 0xDEAD_BEEF]
    mem = b"".join(d.to_bytes(4, "little") for d in data)

    def ld(kind, off):
        if kind == "lb":  v = mem[off];  return u32(v - 256 if v & 0x80 else v)
        if kind == "lbu": return mem[off]
        if kind == "lh":
            v = int.from_bytes(mem[off:off + 2], "little"); return u32(v - 65536 if v & 0x8000 else v)
        if kind == "lhu": return int.from_bytes(mem[off:off + 2], "little")
        if kind == "lw":  return int.from_bytes(mem[off:off + 4], "little")

    for kind, step in [("lb", 1), ("lbu", 1), ("lh", 2), ("lhu", 2), ("lw", 4)]:
        for off in range(0, 16, step):
            exp = ld(kind, off)
            g.new_test(f"{kind} tdat+{off} -> 0x{exp:08x}")
            g.emit("    la   a1, tdat")
            g.emit(f"    {kind:<6}a4, {off}(a1)")
            g.check("a4", exp)
    # offset negativo
    g.new_test("lw com offset negativo")
    g.emit("    la   a1, tdat + 16")
    g.emit("    lw   a4, -4(a1)")
    g.check("a4", data[3])
    g.new_test("lw rd == rs1")
    g.emit("    la   a1, tdat + 8")
    g.emit("    lw   a1, 0(a1)")
    g.check("a1", data[2])

    # ---------------- STORE (+ leitura de volta)
    for off in range(4):
        word = [0xFF] * 4
        word[off] = 0x5A
        exp = int.from_bytes(bytes(word), "little")
        g.new_test(f"sb offset {off}")
        g.emit("    la   a1, sbuf")
        g.emit("    li   t5, -1")
        g.emit("    sw   t5, 0(a1)")
        g.emit("    li   a2, 0x1234565A")
        g.emit(f"    sb   a2, {off}(a1)")
        g.emit("    lw   a4, 0(a1)")
        g.check("a4", exp)
    for off in (0, 2):
        word = [0xFF] * 4
        word[off:off + 2] = [0xCD, 0xAB]
        exp = int.from_bytes(bytes(word), "little")
        g.new_test(f"sh offset {off}")
        g.emit("    la   a1, sbuf")
        g.emit("    li   t5, -1")
        g.emit("    sw   t5, 0(a1)")
        g.emit("    li   a2, 0x9876ABCD")
        g.emit(f"    sh   a2, {off}(a1)")
        g.emit("    lw   a4, 0(a1)")
        g.check("a4", exp)
    g.new_test("sw/lw com offset negativo e varias palavras")
    g.emit("    la   a1, sbuf + 16")
    for i in range(4):
        g.emit(f"    li   a2, 0x{(0x11111111 * (i + 1)) & M32:08x}")
        g.emit(f"    sw   a2, {-16 + 4 * i}(a1)")
    g.emit("    lw   a4, -16(a1)")
    g.emit("    lw   a5, -4(a1)")
    g.emit("    add  a4, a4, a5")
    g.check("a4", 0x11111111 + 0x44444444)
    g.new_test("sb e lb do mesmo byte (sinal)")
    g.emit("    la   a1, sbuf")
    g.emit("    li   a2, 0x80")
    g.emit("    sb   a2, 3(a1)")
    g.emit("    lb   a4, 3(a1)")
    g.check("a4", 0xFFFFFF80)

    # ---------------- RDCYCLE (unica instrucao SYSTEM do Quark)
    g.new_test("rdcycle e' monotonicamente crescente")
    g.emit("    rdcycle a1")
    g.emit("    nop")
    g.emit("    nop")
    g.emit("    rdcycle a2")
    g.emit("    bgeu a1, a2, fail")
    g.emit("    sub  a4, a2, a1")
    g.emit("    li   t5, 64")
    g.emit("    bgeu a4, t5, fail       # diferenca razoavel (<64 ciclos)")

    # ---------------- fim
    g.emit("")
    g.emit("pass:")
    g.emit("    li   t0, IO_TOHOST")
    g.emit("    li   t1, 1")
    g.emit("    sw   t1, 0(t0)")
    g.emit("1:  j    1b")
    g.emit("")
    g.emit("fail:")
    g.emit("    li   t0, IO_TOHOST")
    g.emit("    slli t1, gp, 1")
    g.emit("    ori  t1, t1, 1")
    g.emit("    sw   t1, 0(t0)")
    g.emit("1:  j    1b")
    g.emit("")
    g.emit("sub_times3:")
    g.emit("    slli t5, a0, 1")
    g.emit("    add  a0, a0, t5")
    g.emit("    ret")
    g.emit("")
    g.emit("    .section .data")
    g.emit("    .align 4")
    g.emit("tdat:")
    for d in data:
        g.emit(f"    .word 0x{d:08x}")
    g.emit("sbuf:")
    g.emit("    .word 0, 0, 0, 0, 0, 0, 0, 0")
    g.emit("")
    g.emit(f"/* total de testes: {g.n} */")
    print("\n".join(g.lines))


if __name__ == "__main__":
    main()
