/* calib.h -- calibracao dos sensores do femto_soc
 * Valores da calibracao feita na placa (Tang Primer 20K), com o obstaculo em
 * 6 distancias de 100 a 350 mm (tools/dados/resultado_calibracao_6pontos.txt):
 *   US : bruta = 0.9867 * real -0.69  ->  real = bruta * 1.0134 + 0.7
 *   ToF: bruta = 0.9927 * real +27.74 ->  real = bruta * 1.0074 - 27.9
 *   dist_corrigida = (bruta * GANHO_Q12 + 2048) / 4096 + OFFSET
 *   variancia      = sigma^2 (mm^2) da medida corrigida (usada pela fusao)
 * Na placa o firmware imprime: "cal US: x1.01 ofs 1 var 29 | ToF: x1.00 ofs -28 var 6".
 * Obs.: a variancia do US (29) ficou inflada por blocos com o obstaculo em
 * movimento a 150 mm; a versao atual do tools/calib_fit.py descarta esses
 * blocos e soma o residuo da reta -- rode-a de novo para os valores finais.
 */
#ifndef CALIB_H
#define CALIB_H

#define CAL_US_GAIN_Q12     4151
#define CAL_US_OFFSET_MM       1
#define CAL_US_VAR_MM2        29

#define CAL_TOF_GAIN_Q12    4126
#define CAL_TOF_OFFSET_MM    -28
#define CAL_TOF_VAR_MM2        6

#define CAL_VAR_MIN_MM2        1

#endif
