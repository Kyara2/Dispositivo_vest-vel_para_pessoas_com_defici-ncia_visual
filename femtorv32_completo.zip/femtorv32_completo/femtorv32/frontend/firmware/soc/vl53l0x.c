/* vl53l0x.c -- driver minimo do sensor laser ToF VL53L0X para o femto_soc
 *
 * Porte em C da biblioteca VL53L0X da Pololu (licenca MIT,
 * https://github.com/pololu/vl53l0x-arduino), que por sua vez segue a API
 * da ST (sequencia de inicializacao, ajustes "tuning" padrao, calibracao de
 * referencia). Mantidas so' as funcoes necessarias para medicao continua.
 * Adaptacao: Kyara Esteves de Sousa (I2C via MMIO do femto_soc, sem float).
 */
#include "soc.h"
#include "vl53l0x.h"

#define ADDR 0x29

/* registradores usados */
#define SYSRANGE_START                              0x00
#define SYSTEM_SEQUENCE_CONFIG                      0x01
#define SYSTEM_INTERRUPT_CONFIG_GPIO                0x0A
#define SYSTEM_INTERRUPT_CLEAR                      0x0B
#define RESULT_INTERRUPT_STATUS                     0x13
#define RESULT_RANGE_STATUS                         0x14
#define MSRC_CONFIG_CONTROL                         0x60
#define FINAL_RANGE_CONFIG_MIN_COUNT_RATE_RTN_LIMIT 0x44
#define PRE_RANGE_CONFIG_VCSEL_PERIOD               0x50
#define PRE_RANGE_CONFIG_TIMEOUT_MACROP_HI          0x51
#define FINAL_RANGE_CONFIG_VCSEL_PERIOD             0x70
#define FINAL_RANGE_CONFIG_TIMEOUT_MACROP_HI        0x71
#define MSRC_CONFIG_TIMEOUT_MACROP                  0x46
#define GLOBAL_CONFIG_SPAD_ENABLES_REF_0            0xB0
#define GLOBAL_CONFIG_REF_EN_START_SELECT           0xB6
#define DYNAMIC_SPAD_NUM_REQUESTED_REF_SPAD         0x4E
#define DYNAMIC_SPAD_REF_EN_START_OFFSET            0x4F
#define GPIO_HV_MUX_ACTIVE_HIGH                     0x84
#define VHV_CONFIG_PAD_SCL_SDA__EXTSUP_HV           0x89
#define IDENTIFICATION_MODEL_ID                     0xC0

static uint8_t  stop_variable;
static uint32_t timing_budget_us;
static int      did_timeout;

static void    wr(uint8_t r, uint8_t v)     { i2c_write_reg(ADDR, r, v); }
static void    wr16(uint8_t r, uint16_t v)  { i2c_write_reg16(ADDR, r, v); }
static uint8_t rd(uint8_t r)                { return i2c_read_reg(ADDR, r); }
static uint16_t rd16(uint8_t r)             { return i2c_read_reg16(ADDR, r); }

static uint32_t timeout_cycles(void) {         /* 500 ms (5 ms na simulacao) */
    return g_sim ? g_clk_hz / 200u : g_clk_hz / 2u;
}

/* ---- tempos (mesmas formulas da API da ST / Pololu) */
#define decodeVcselPeriod(reg_val) (((reg_val) + 1) << 1)
#define calcMacroPeriod(vcsel)     ((((uint32_t)2304 * (vcsel) * 1655) + 500) / 1000)

static uint16_t decodeTimeout(uint16_t v) {
    return (uint16_t)((uint16_t)((v & 0x00FF) << (uint16_t)((v & 0xFF00) >> 8)) + 1);
}
static uint16_t encodeTimeout(uint32_t mclks) {
    uint32_t ls; uint16_t ms = 0;
    if (mclks > 0) {
        ls = mclks - 1;
        while ((ls & 0xFFFFFF00u) > 0) { ls >>= 1; ms++; }
        return (uint16_t)((ms << 8) | (ls & 0xFF));
    }
    return 0;
}
static uint32_t timeoutMclksToMicroseconds(uint16_t mclks, uint8_t vcsel) {
    uint32_t mp = calcMacroPeriod(vcsel);
    return ((mclks * mp) + 500) / 1000;
}
static uint32_t timeoutMicrosecondsToMclks(uint32_t us, uint8_t vcsel) {
    uint32_t mp = calcMacroPeriod(vcsel);
    return (((us * 1000) + (mp / 2)) / mp);
}

typedef struct { uint8_t tcc, msrc, dss, pre_range, final_range; } SeqEnables;
typedef struct {
    uint16_t pre_range_vcsel_pclks, final_range_vcsel_pclks;
    uint16_t msrc_dss_tcc_mclks, pre_range_mclks, final_range_mclks;
    uint32_t msrc_dss_tcc_us, pre_range_us, final_range_us;
} SeqTimeouts;

static void getSequenceStepEnables(SeqEnables *e) {
    uint8_t s = rd(SYSTEM_SEQUENCE_CONFIG);
    e->tcc = (s >> 4) & 1; e->dss = (s >> 3) & 1; e->msrc = (s >> 2) & 1;
    e->pre_range = (s >> 6) & 1; e->final_range = (s >> 7) & 1;
}
static void getSequenceStepTimeouts(const SeqEnables *e, SeqTimeouts *t) {
    t->pre_range_vcsel_pclks = decodeVcselPeriod(rd(PRE_RANGE_CONFIG_VCSEL_PERIOD));
    t->msrc_dss_tcc_mclks    = rd(MSRC_CONFIG_TIMEOUT_MACROP) + 1;
    t->msrc_dss_tcc_us       = timeoutMclksToMicroseconds(t->msrc_dss_tcc_mclks, (uint8_t)t->pre_range_vcsel_pclks);
    t->pre_range_mclks       = decodeTimeout(rd16(PRE_RANGE_CONFIG_TIMEOUT_MACROP_HI));
    t->pre_range_us          = timeoutMclksToMicroseconds(t->pre_range_mclks, (uint8_t)t->pre_range_vcsel_pclks);
    t->final_range_vcsel_pclks = decodeVcselPeriod(rd(FINAL_RANGE_CONFIG_VCSEL_PERIOD));
    t->final_range_mclks     = decodeTimeout(rd16(FINAL_RANGE_CONFIG_TIMEOUT_MACROP_HI));
    if (e->pre_range) t->final_range_mclks -= t->pre_range_mclks;
    t->final_range_us        = timeoutMclksToMicroseconds(t->final_range_mclks, (uint8_t)t->final_range_vcsel_pclks);
}

static uint32_t getMeasurementTimingBudget(void) {
    SeqEnables e; SeqTimeouts t;
    uint32_t budget = 1910 + 960;                       /* StartOverhead + EndOverhead */
    getSequenceStepEnables(&e);
    getSequenceStepTimeouts(&e, &t);
    if (e.tcc)  budget += t.msrc_dss_tcc_us + 590;
    if (e.dss)  budget += 2 * (t.msrc_dss_tcc_us + 690);
    else if (e.msrc) budget += t.msrc_dss_tcc_us + 660;
    if (e.pre_range)   budget += t.pre_range_us + 660;
    if (e.final_range) budget += t.final_range_us + 550;
    timing_budget_us = budget;
    return budget;
}

static int setMeasurementTimingBudget(uint32_t budget_us) {
    SeqEnables e; SeqTimeouts t;
    uint32_t used = 1320 + 960;                         /* (diferente do "get", como na ST) */
    if (budget_us < 20000) return 0;
    getSequenceStepEnables(&e);
    getSequenceStepTimeouts(&e, &t);
    if (e.tcc)  used += t.msrc_dss_tcc_us + 590;
    if (e.dss)  used += 2 * (t.msrc_dss_tcc_us + 690);
    else if (e.msrc) used += t.msrc_dss_tcc_us + 660;
    if (e.pre_range) used += t.pre_range_us + 660;
    if (e.final_range) {
        used += 550;
        if (used > budget_us) return 0;
        uint32_t mclks = timeoutMicrosecondsToMclks(budget_us - used, (uint8_t)t.final_range_vcsel_pclks);
        if (e.pre_range) mclks += t.pre_range_mclks;
        wr16(FINAL_RANGE_CONFIG_TIMEOUT_MACROP_HI, encodeTimeout(mclks));
        timing_budget_us = budget_us;
    }
    return 1;
}

static int getSpadInfo(uint8_t *count, uint8_t *is_aperture) {
    uint8_t tmp; uint32_t t0;
    wr(0x80, 0x01); wr(0xFF, 0x01); wr(0x00, 0x00);
    wr(0xFF, 0x06); wr(0x83, rd(0x83) | 0x04);
    wr(0xFF, 0x07); wr(0x81, 0x01);
    wr(0x80, 0x01);
    wr(0x94, 0x6b); wr(0x83, 0x00);
    t0 = rdcycle();
    while (rd(0x83) == 0x00) { if (rdcycle() - t0 > timeout_cycles()) return 0; }
    wr(0x83, 0x01);
    tmp = rd(0x92);
    *count = tmp & 0x7f;
    *is_aperture = (tmp >> 7) & 0x01;
    wr(0x81, 0x00); wr(0xFF, 0x06); wr(0x83, rd(0x83) & ~0x04);
    wr(0xFF, 0x01); wr(0x00, 0x01);
    wr(0xFF, 0x00); wr(0x80, 0x00);
    return 1;
}

static int performSingleRefCalibration(uint8_t vhv_init_byte) {
    uint32_t t0;
    wr(SYSRANGE_START, 0x01 | vhv_init_byte);
    t0 = rdcycle();
    while ((rd(RESULT_INTERRUPT_STATUS) & 0x07) == 0) { if (rdcycle() - t0 > timeout_cycles()) return 0; }
    wr(SYSTEM_INTERRUPT_CLEAR, 0x01);
    wr(SYSRANGE_START, 0x00);
    return 1;
}

/* tabela de ajustes padrao da ST (DefaultTuningSettings), pares reg,valor */
static const uint8_t tuning[] = {
    0xFF,0x01, 0x00,0x00, 0xFF,0x00, 0x09,0x00, 0x10,0x00, 0x11,0x00,
    0x24,0x01, 0x25,0xFF, 0x75,0x00, 0xFF,0x01, 0x4E,0x2C, 0x48,0x00,
    0x30,0x20, 0xFF,0x00, 0x30,0x09, 0x54,0x00, 0x31,0x04, 0x32,0x03,
    0x40,0x83, 0x46,0x25, 0x60,0x00, 0x27,0x00, 0x50,0x06, 0x51,0x00,
    0x52,0x96, 0x56,0x08, 0x57,0x30, 0x61,0x00, 0x62,0x00, 0x64,0x00,
    0x65,0x00, 0x66,0xA0, 0xFF,0x01, 0x22,0x32, 0x47,0x14, 0x49,0xFF,
    0x4A,0x00, 0xFF,0x00, 0x7A,0x0A, 0x7B,0x00, 0x78,0x21, 0xFF,0x01,
    0x23,0x34, 0x42,0x00, 0x44,0xFF, 0x45,0x26, 0x46,0x05, 0x40,0x40,
    0x0E,0x06, 0x20,0x1A, 0x43,0x40, 0xFF,0x00, 0x34,0x03, 0x35,0x44,
    0xFF,0x01, 0x31,0x04, 0x4B,0x09, 0x4C,0x05, 0x4D,0x04, 0xFF,0x00,
    0x44,0x00, 0x45,0x20, 0x47,0x08, 0x48,0x28, 0x67,0x00, 0x70,0x04,
    0x71,0x01, 0x72,0xFE, 0x76,0x00, 0x77,0x00, 0xFF,0x01, 0x0D,0x01,
    0xFF,0x00, 0x80,0x01, 0x01,0xF8, 0xFF,0x01, 0x8E,0x01, 0x00,0x01,
    0xFF,0x00, 0x80,0x00
};

int vl53l0x_init(void) {
    uint8_t spad_count = 0, aperture = 0, ref_spad_map[6];
    i2c_bus_recover();                    /* sensor pode ter ficado travado num reset da FPGA */

    if (rd(IDENTIFICATION_MODEL_ID) != 0xEE) return VL_ERR_ID;

    /* "DataInit": I/O em 2V8 (padrao dos modulos), modo I2C padrao */
    wr(VHV_CONFIG_PAD_SCL_SDA__EXTSUP_HV, rd(VHV_CONFIG_PAD_SCL_SDA__EXTSUP_HV) | 0x01);
    wr(0x88, 0x00);
    wr(0x80, 0x01); wr(0xFF, 0x01); wr(0x00, 0x00);
    stop_variable = rd(0x91);
    wr(0x00, 0x01); wr(0xFF, 0x00); wr(0x80, 0x00);
    wr(MSRC_CONFIG_CONTROL, rd(MSRC_CONFIG_CONTROL) | 0x12);   /* desliga limites MSRC/PRE_RANGE */
    wr16(FINAL_RANGE_CONFIG_MIN_COUNT_RATE_RTN_LIMIT, 32);      /* 0.25 MCPS em Q9.7 */
    wr(SYSTEM_SEQUENCE_CONFIG, 0xFF);

    /* "StaticInit": SPADs de referencia */
    if (!getSpadInfo(&spad_count, &aperture)) return VL_ERR_SPAD;
    i2c_read_multi(ADDR, GLOBAL_CONFIG_SPAD_ENABLES_REF_0, ref_spad_map, 6);
    wr(0xFF, 0x01);
    wr(DYNAMIC_SPAD_REF_EN_START_OFFSET, 0x00);
    wr(DYNAMIC_SPAD_NUM_REQUESTED_REF_SPAD, 0x2C);
    wr(0xFF, 0x00);
    wr(GLOBAL_CONFIG_REF_EN_START_SELECT, 0xB4);
    {
        uint8_t first = aperture ? 12 : 0, enabled = 0;
        for (uint8_t i = 0; i < 48; i++) {
            if (i < first || enabled == spad_count)
                ref_spad_map[i / 8] &= (uint8_t)~(1u << (i % 8));
            else if ((ref_spad_map[i / 8] >> (i % 8)) & 0x1)
                enabled++;
        }
    }
    i2c_write_multi(ADDR, GLOBAL_CONFIG_SPAD_ENABLES_REF_0, ref_spad_map, 6);

    for (unsigned i = 0; i < sizeof(tuning); i += 2) wr(tuning[i], tuning[i + 1]);

    /* interrupcao: "nova amostra pronta", ativa baixa */
    wr(SYSTEM_INTERRUPT_CONFIG_GPIO, 0x04);
    wr(GPIO_HV_MUX_ACTIVE_HIGH, rd(GPIO_HV_MUX_ACTIVE_HIGH) & ~0x10);
    wr(SYSTEM_INTERRUPT_CLEAR, 0x01);

    timing_budget_us = getMeasurementTimingBudget();
    wr(SYSTEM_SEQUENCE_CONFIG, 0xE8);                   /* sem MSRC e TCC */
    setMeasurementTimingBudget(timing_budget_us);

    /* "PerformRefCalibration" */
    wr(SYSTEM_SEQUENCE_CONFIG, 0x01);
    if (!performSingleRefCalibration(0x40)) return VL_ERR_CAL;
    wr(SYSTEM_SEQUENCE_CONFIG, 0x02);
    if (!performSingleRefCalibration(0x00)) return VL_ERR_CAL;
    wr(SYSTEM_SEQUENCE_CONFIG, 0xE8);

    return g_i2c_err ? VL_ERR_I2C : VL_OK;
}

void vl53l0x_start_continuous(void) {
    wr(0x80, 0x01); wr(0xFF, 0x01); wr(0x00, 0x00);
    wr(0x91, stop_variable);
    wr(0x00, 0x01); wr(0xFF, 0x00); wr(0x80, 0x00);
    wr(SYSRANGE_START, 0x02);                           /* back-to-back */
}

/* devolve a distancia em mm, ou 0xFFFF se estourou o tempo / erro de I2C */
uint16_t vl53l0x_read_mm(void) {
    uint32_t t0 = rdcycle();
    uint16_t range;
    did_timeout = 0;
    while ((rd(RESULT_INTERRUPT_STATUS) & 0x07) == 0) {
        if (rdcycle() - t0 > timeout_cycles()) { did_timeout = 1; return 0xFFFF; }
    }
    range = rd16(RESULT_RANGE_STATUS + 10);
    wr(SYSTEM_INTERRUPT_CLEAR, 0x01);
    return range;
}

uint32_t vl53l0x_budget_us(void) { return timing_budget_us; }
