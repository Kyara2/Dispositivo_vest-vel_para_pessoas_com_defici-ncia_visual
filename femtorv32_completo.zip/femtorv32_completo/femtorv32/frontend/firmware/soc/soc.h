/* soc.h -- mapa de memoria do femto_soc (FemtoRV32 Quark + AXI4-Lite)
 * Author: Kyara Esteves de Sousa
 *
 *   0x000000  RAM (16 KB, macros OpenRAM / BSRAM na FPGA)
 *   0x400000  SYSINFO   0x400100 UART   0x400200 HCSR04
 *   0x400300  I2C       0x400400 FUSION (coprocessador, 1 fusion_node)
 */
#ifndef SOC_H
#define SOC_H
#include <stdint.h>

#define MMIO32(a) (*(volatile uint32_t *)(a))

#define SYS_BASE     0x00400000u
#define SYS_ID       MMIO32(SYS_BASE + 0x00)
#define SYS_CLK_HZ   MMIO32(SYS_BASE + 0x04)
#define SYS_FLAGS    MMIO32(SYS_BASE + 0x08)   /* bit0 SIM */
#define SYS_LEDS     MMIO32(SYS_BASE + 0x0C)
#define SYS_TOHOST   MMIO32(SYS_BASE + 0x10)
#define SYS_BUSERR   MMIO32(SYS_BASE + 0x14)

#define UART_BASE    0x00400100u
#define UART_TX      MMIO32(UART_BASE + 0x00)
#define UART_STATUS  MMIO32(UART_BASE + 0x04)  /* bit0 busy */

#define US_BASE      0x00400200u
#define US_DIST_MM   MMIO32(US_BASE + 0x00)    /* ler limpa "new" */
#define US_STATUS    MMIO32(US_BASE + 0x04)    /* bit0 valid, bit1 new, bit2 timeout */
#define US_COUNT     MMIO32(US_BASE + 0x08)
#define US_ECHO_CYC  MMIO32(US_BASE + 0x0C)

#define I2C_BASE     0x00400300u
#define I2C_PRESCALE MMIO32(I2C_BASE + 0x00)
#define I2C_CMD      MMIO32(I2C_BASE + 0x04)
#define I2C_TXDATA   MMIO32(I2C_BASE + 0x08)
#define I2C_RXDATA   MMIO32(I2C_BASE + 0x0C)
#define I2C_STATUS   MMIO32(I2C_BASE + 0x10)   /* bit0 busy, bit1 nack */
#define I2C_START 0x01u
#define I2C_STOP  0x02u
#define I2C_WRITE 0x04u
#define I2C_READ  0x08u
#define I2C_NACK  0x10u

#define FU_BASE      0x00400400u
#define FU_Q1        MMIO32(FU_BASE + 0x00)
#define FU_Q2        MMIO32(FU_BASE + 0x04)
#define FU_S1        MMIO32(FU_BASE + 0x08)
#define FU_S2        MMIO32(FU_BASE + 0x0C)
#define FU_CTRL      MMIO32(FU_BASE + 0x10)
#define FU_STATUS    MMIO32(FU_BASE + 0x14)    /* bit0 busy, bit1 done */
#define FU_K         MMIO32(FU_BASE + 0x18)
#define FU_QHAT      MMIO32(FU_BASE + 0x1C)
#define FU_SNEW      MMIO32(FU_BASE + 0x20)
#define FU_LAT       MMIO32(FU_BASE + 0x24)
#define FU_ID        MMIO32(FU_BASE + 0x28)

/* ---- soc_lib.c ---- */
static inline uint32_t rdcycle(void) {
    uint32_t c; __asm__ volatile ("rdcycle %0" : "=r"(c)); return c;
}
extern uint32_t g_clk_hz;
extern int      g_sim;

void     soc_init(void);
void     uart_putc(char c);
void     uart_puts(const char *s);
void     uart_putu(uint32_t v);                 /* decimal sem sinal */
void     uart_putu_w(uint32_t v, int width);    /* alinhado a direita */
void     uart_puthex(uint32_t v);
void     uart_putfix(uint32_t num, uint32_t den, int decimals); /* num/den com casas */
uint32_t cycles_to_ns(uint32_t cyc);
void     delay_ms(uint32_t ms);

void     i2c_bus_recover(void);
int      i2c_write_reg(uint8_t dev, uint8_t reg, uint8_t val);
int      i2c_write_reg16(uint8_t dev, uint8_t reg, uint16_t val);
int      i2c_write_multi(uint8_t dev, uint8_t reg, const uint8_t *buf, int n);
uint8_t  i2c_read_reg(uint8_t dev, uint8_t reg);
uint16_t i2c_read_reg16(uint8_t dev, uint8_t reg);
int      i2c_read_multi(uint8_t dev, uint8_t reg, uint8_t *buf, int n);
extern int g_i2c_err;

#endif
