/* soc_lib.c -- UART, tempo e I2C para o femto_soc
 * Author: Kyara Esteves de Sousa */
#include "soc.h"

uint32_t g_clk_hz = 27000000u;
int      g_sim    = 0;
int      g_i2c_err = 0;

void soc_init(void) {
    g_clk_hz = SYS_CLK_HZ;
#ifdef FORCE_SIM
    g_sim    = 1;            /* soc_fw_post: a netlist tem SIM=0, mas a pos-sintese precisa do modo curto */
#else
    g_sim    = (int)(SYS_FLAGS & 1u);
#endif
    if (g_sim) I2C_PRESCALE = 4;               /* simulacao: I2C rapido */
}

/* ------------------------------------------------------------ UART */
void uart_putc(char c) {
    if (c == '\n') uart_putc('\r');
    while (UART_STATUS & 1u) ;
    UART_TX = (uint8_t)c;
}
void uart_puts(const char *s) { while (*s) uart_putc(*s++); }

void uart_putu_w(uint32_t v, int width) {
    char buf[11]; int n = 0;
    do { buf[n++] = (char)('0' + v % 10u); v /= 10u; } while (v);
    while (width-- > n) uart_putc(' ');
    while (n) uart_putc(buf[--n]);
}
void uart_putu(uint32_t v) { uart_putu_w(v, 0); }

void uart_puthex(uint32_t v) {
    for (int i = 28; i >= 0; i -= 4) {
        uint32_t d = (v >> i) & 0xFu;
        uart_putc((char)(d < 10 ? '0' + d : 'a' + d - 10));
    }
}

/* imprime num/den com 'decimals' casas, arredondado (so' 32 bits: num*10^dec
   precisa caber -- e' o caso aqui: K <= 32768 com 4 casas, ciclos com 1 casa) */
void uart_putfix(uint32_t num, uint32_t den, int decimals) {
    uint32_t scale = 1;
    for (int i = 0; i < decimals; i++) scale *= 10u;
    uint32_t v = (num * scale + den / 2u) / den;
    uart_putu(v / scale);
    if (decimals) {
        uart_putc('.');
        uint32_t frac = v % scale;
        for (uint32_t d = scale / 10u; d; d /= 10u) { uart_putc((char)('0' + frac / d)); frac %= d; }
    }
}

/* ciclos -> ns sem aritmetica de 64 bits (a libgcc de 64 bits custa ~5 KB) */
uint32_t cycles_to_ns(uint32_t cyc) {
    uint32_t khz = g_clk_hz / 1000u;
    if (cyc < 4000000u) return (cyc * 1000u / khz) * 1000u + ((cyc * 1000u % khz) * 1000u) / khz;
    return (cyc / khz) * 1000000u;
}

void delay_ms(uint32_t ms) {
    uint32_t per_ms = g_clk_hz / 1000u;
    while (ms--) { uint32_t t0 = rdcycle(); while (rdcycle() - t0 < per_ms) ; }
}

/* ------------------------------------------------------------ I2C */
static int i2c_cmd(uint32_t cmd) {
    uint32_t t0 = rdcycle(), lim = g_clk_hz / 100u;   /* 10 ms por byte, folgado */
    I2C_CMD = cmd;
    while (I2C_STATUS & 1u) {
        if (rdcycle() - t0 > lim) { g_i2c_err = 1; return -1; }
    }
    if ((cmd & I2C_WRITE) && (I2C_STATUS & 2u)) { g_i2c_err = 1; return -1; }
    return 0;
}
static int i2c_tx(uint8_t b, uint32_t flags) { I2C_TXDATA = b; return i2c_cmd(I2C_WRITE | flags); }
static int i2c_rx(uint32_t flags, uint8_t *b) {
    int r = i2c_cmd(I2C_READ | flags); *b = (uint8_t)I2C_RXDATA; return r;
}

/* Destrava o barramento: se a FPGA foi resetada no meio de uma leitura, o
   VL53L0X (que NAO e' resetado junto) pode ficar segurando SDA em 0, e toda
   transacao seguinte falha (o ID volta errado -> codigo 1). Uma "leitura" com
   NACK gera 9 pulsos de SCL com SDA solto, o que faz o escravo terminar o
   byte e soltar a linha; o STOP final recoloca o barramento em repouso. */
void i2c_bus_recover(void) {
    for (int i = 0; i < 2; i++) i2c_cmd(I2C_READ | I2C_NACK | I2C_STOP);
    i2c_cmd(I2C_START | I2C_STOP);
    g_i2c_err = 0;
}

/* escrita: S addr+W reg dados... P */
int i2c_write_multi(uint8_t dev, uint8_t reg, const uint8_t *buf, int n) {
    int r = i2c_tx((uint8_t)(dev << 1), I2C_START);
    r |= i2c_tx(reg, n == 0 ? I2C_STOP : 0);
    for (int i = 0; i < n; i++) r |= i2c_tx(buf[i], i == n - 1 ? I2C_STOP : 0);
    if (r) i2c_cmd(I2C_STOP);
    return r;
}
int i2c_write_reg(uint8_t dev, uint8_t reg, uint8_t val) { return i2c_write_multi(dev, reg, &val, 1); }
int i2c_write_reg16(uint8_t dev, uint8_t reg, uint16_t val) {
    uint8_t b[2] = { (uint8_t)(val >> 8), (uint8_t)val };
    return i2c_write_multi(dev, reg, b, 2);
}

/* leitura: S addr+W reg P  S addr+R dados... (NACK no ultimo) P
   -- mesmo padrao da biblioteca da Pololu (endTransmission com STOP) */
int i2c_read_multi(uint8_t dev, uint8_t reg, uint8_t *buf, int n) {
    int r = i2c_tx((uint8_t)(dev << 1), I2C_START);
    r |= i2c_tx(reg, I2C_STOP);
    r |= i2c_tx((uint8_t)((dev << 1) | 1u), I2C_START);
    for (int i = 0; i < n; i++)
        r |= i2c_rx(i == n - 1 ? (I2C_NACK | I2C_STOP) : 0, &buf[i]);
    if (r) i2c_cmd(I2C_STOP);
    return r;
}
uint8_t i2c_read_reg(uint8_t dev, uint8_t reg) { uint8_t v = 0; i2c_read_multi(dev, reg, &v, 1); return v; }
uint16_t i2c_read_reg16(uint8_t dev, uint8_t reg) {
    uint8_t b[2] = {0, 0}; i2c_read_multi(dev, reg, b, 2); return (uint16_t)((b[0] << 8) | b[1]);
}
