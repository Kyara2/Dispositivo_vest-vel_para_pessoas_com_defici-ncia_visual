/* vl53l0x.h -- driver minimo do VL53L0X (porte da biblioteca Pololu, MIT) */
#ifndef VL53L0X_H
#define VL53L0X_H
#include <stdint.h>
enum { VL_OK = 0, VL_ERR_ID = 1, VL_ERR_SPAD = 2, VL_ERR_CAL = 3, VL_ERR_I2C = 4 };
int      vl53l0x_init(void);
void     vl53l0x_start_continuous(void);
uint16_t vl53l0x_read_mm(void);          /* 0xFFFF = timeout/erro */
uint32_t vl53l0x_budget_us(void);
#endif
