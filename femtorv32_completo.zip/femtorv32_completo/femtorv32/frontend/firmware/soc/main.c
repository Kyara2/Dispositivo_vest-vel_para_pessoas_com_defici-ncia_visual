/* main.c -- femto_soc: le o ultrassom (HC-SR04) e o laser ToF (VL53L0X),
 * corrige cada medida com a calibracao (calib.h), funde as duas em
 * SOFTWARE e no COPROCESSADOR (fusion_node via AXI4-Lite), compara
 * resultado e tempo e mostra tudo na UART.
 * Author: Kyara Esteves de Sousa
 *
 * Dois modos (escolhidos na compilacao):
 *
 *  normal (padrao)  -- uma linha compacta por relatorio (a cada REPORT_MS):
 *    #12 US  95>100 ToF 129>100 dif   0 | q 100 var  1 K .250 | SW 2239c  82.9us HW 247c 9.1us n22 9.1x ok
 *      US/ToF  bruta>corrigida (mm), dif = US - ToF corrigidos (mm)
 *      q/var   estimativa fundida (mm) e variancia apos a fusao (mm^2)
 *      K       ganho (peso dado ao ToF), SW/HW ciclos e tempo, n = so' o nucleo
 *
 *  calibracao (make CALIB=1, ou ./fpga/tang_primer_20k/build.sh calib) --
 *    nao funde nada; junta CAL_N (80) amostras BRUTAS de cada sensor e imprime
 *    uma linha "CAL ..." com media, variancia e falhas. O tools/calib_fit.py
 *    le essas linhas (uma ou mais distancias conhecidas) e gera o calib.h.
 *
 * Saida pequena de proposito: o conversor USB da Dock (BL702) perde blocos
 * de texto quando chega muito dado seguido.
 */
#include "soc.h"
#include "vl53l0x.h"
#include "fusion.h"
#include "calib.h"

#ifndef REPORT_MS
#define REPORT_MS     1000     /* intervalo entre linhas no modo normal */
#endif
#ifndef CAL_N
#define CAL_N           80     /* amostras por linha CAL (por sensor) */
#endif
#define SIM_ROUNDS       4     /* rodadas com sensores na simulacao */
#define SELFTEST_N      64     /* vetores do autoteste HW x SW */
#define NO_READ     0xFFFFu

/* ------------------------------------------------------------ sensores */

/* espera uma medida NOVA do HC-SR04 (bruta, mm); NO_READ = sem eco */
static uint16_t read_ultrasonic(void) {
    uint32_t t0 = rdcycle(), lim = g_clk_hz / 5u;    /* 200 ms (> periodo de 60 ms) */
    while (!(US_STATUS & 2u)) {
        if (rdcycle() - t0 > lim) return NO_READ;
    }
    if (US_STATUS & 4u) { (void)US_DIST_MM; return NO_READ; }
    return (uint16_t)US_DIST_MM;
}

static uint16_t read_tof(int vl_ok) {
    if (!vl_ok) return NO_READ;
    uint16_t d = vl53l0x_read_mm();
    return (d >= 8190u) ? NO_READ : d;                /* 8190/8191 = fora de alcance */
}

/* correcao linear: (bruta * ganho_q12 + 2048) / 4096 + offset, saturada em 0..65535 */
static uint16_t apply_cal(uint16_t raw, uint32_t gain_q12, int32_t offset) {
    if (raw == NO_READ) return NO_READ;
    int32_t v = (int32_t)((raw * gain_q12 + 2048u) >> 12) + offset;
    if (v < 0) v = 0;
    if (v > 65534) v = 65534;
    return (uint16_t)v;
}

static uint16_t var_floor(uint32_t v) {
    if (v < CAL_VAR_MIN_MM2) v = CAL_VAR_MIN_MM2;
    return (uint16_t)(v > 65535u ? 65535u : v);
}

/* ------------------------------------------------------------ impressao */

static void put_int(int32_t v, int w) {
    if (v < 0) { uart_putc('-'); uart_putu_w((uint32_t)(-v), w > 0 ? w - 1 : 0); }
    else uart_putu_w((uint32_t)v, w);
}

static void put_dist(uint16_t v) {
    if (v == NO_READ) uart_puts(" ---"); else uart_putu_w(v, 4);
}

/* num/den com 2 casas, sem estourar 32 bits */
static void put_2dec(uint32_t num, uint32_t den) {
    uint32_t ip = num / den, rem = num % den;
    uint32_t fr = (rem * 100u + den / 2u) / den;
    if (fr >= 100u) { ip++; fr -= 100u; }
    uart_putu(ip); uart_putc('.');
    uart_putc((char)('0' + fr / 10u)); uart_putc((char)('0' + fr % 10u));
}

static void put_us(uint32_t cyc) {          /* ciclos -> "82.9us" */
    uint32_t ns = cycles_to_ns(cyc);
    uart_putu(ns / 1000u); uart_putc('.'); uart_putu((ns % 1000u) / 100u); uart_puts("us");
}

/* ------------------------------------------------------------ autoteste */

static int same(const fusion_out_t *a, const fusion_out_t *b) {
    return a->k == b->k && a->q_hat == b->q_hat && a->sigma_new_sq == b->sigma_new_sq;
}

static uint32_t selftest(void) {
    static const uint16_t edge[][4] = {
        {0, 0, 0, 0}, {1000, 2000, 0, 0}, {500, 400, 100, 0}, {500, 400, 0, 100},
        {65535, 0, 65535, 65535}, {0, 65535, 1, 65535}, {300, 300, 50, 50}, {4000, 30, 900, 4},
    };
    uint32_t lfsr = 0xACE1u, bad = 0;
    for (int i = 0; i < SELFTEST_N; i++) {
        uint16_t q1, q2, s1, s2;
        if (i < (int)(sizeof(edge) / sizeof(edge[0]))) {
            q1 = edge[i][0]; q2 = edge[i][1]; s1 = edge[i][2]; s2 = edge[i][3];
        } else {
            lfsr = lfsr * 1664525u + 1013904223u; q1 = (uint16_t)(lfsr >> 16) % 4000u;
            lfsr = lfsr * 1664525u + 1013904223u; q2 = (uint16_t)(lfsr >> 16) % 4000u;
            lfsr = lfsr * 1664525u + 1013904223u; s1 = (uint16_t)(lfsr >> 20);
            lfsr = lfsr * 1664525u + 1013904223u; s2 = (uint16_t)(lfsr >> 20);
        }
        fusion_out_t a, b;
        fusion_sw(q1, q2, s1, s2, &a);
        fusion_hw(q1, q2, s1, s2, &b);
        if (!same(&a, &b)) bad++;
    }
    return bad;
}

static int init_tof(void) {
    for (int tries = 0; tries < 3; tries++) {
        int r = vl53l0x_init();
        if (r == VL_OK) { vl53l0x_start_continuous(); return 1; }
        uart_puts("VL53L0X: falha na inicializacao (codigo "); uart_putu((uint32_t)r);
        if (r == VL_ERR_ID) { uart_puts(", ID lido 0x"); uart_puthex(i2c_read_reg(0x29, 0xC0)); uart_puts(", esperado 0x000000ee"); }
        uart_puts(")\n");
        delay_ms(g_sim ? 1 : 200);
    }
    return 0;
}

/* ============================================================ modo calibracao */
#ifdef CALIB_MODE
static uint16_t s_us[CAL_N], s_tof[CAL_N];

/* imprime "media" e "variancia" de n amostras: media em Q2 (0,25 mm), soma
   dos quadrados em Q4 -- cabe em 32 bits para desvios de ate' ~4000 mm */
static void put_stats(const char *tag, const uint16_t *s, uint32_t n, uint32_t fails) {
    uart_puts(" n_"); uart_puts(tag); uart_putc('='); uart_putu(n);
    uart_putc(' '); uart_puts(tag); uart_puts("_mean=");
    if (n == 0) { uart_puts("0.00 "); uart_puts(tag); uart_puts("_var=0.00"); }
    else {
        uint32_t sum = 0;
        for (uint32_t i = 0; i < n; i++) sum += s[i];
        uint32_t mean_q2 = (sum * 4u + n / 2u) / n;
        put_2dec(mean_q2, 4u);
        uint32_t ss = 0;
        for (uint32_t i = 0; i < n; i++) {
            int32_t d = (int32_t)(s[i] * 4u) - (int32_t)mean_q2;
            uint32_t d2 = (uint32_t)(d * d);
            ss = (ss > 0xFFFFFFFFu - d2) ? 0xFFFFFFFFu : ss + d2;
        }
        uart_putc(' '); uart_puts(tag); uart_puts("_var=");
        put_2dec(ss, 16u * (n > 1 ? n - 1 : 1));
    }
    uart_putc(' '); uart_puts(tag); uart_puts("_fail="); uart_putu(fails);
}

static void calib_loop(int vl_ok) {
    uart_puts("MODO CALIBRACAO: coloque o obstaculo numa distancia conhecida e grave o log\n");
    uart_puts("(tio -l cal_<mm>.txt); depois: python3 tools/calib_fit.py <mm>:cal_<mm>.txt ...\n");
    for (uint32_t blk = 1; ; blk++) {
        uint32_t nu = 0, nt = 0, fu = 0, ft = 0;
        for (int i = 0; i < CAL_N; i++) {
            uint16_t u = read_ultrasonic(), t = read_tof(vl_ok);
            if (u == NO_READ) fu++; else s_us[nu++] = u;
            if (t == NO_READ) ft++; else s_tof[nt++] = t;
        }
        uart_puts("CAL");
        put_stats("us", s_us, nu, fu);
        uart_puts(" |");
        put_stats("tof", s_tof, nt, ft);
        uart_puts("  #"); uart_putu(blk); uart_putc('\n');
        SYS_LEDS = (fu == 0 && ft == 0) ? 0x2 : 0x4;
    }
}
#endif

/* ============================================================ main */
int main(void) {
    soc_init();
    SYS_LEDS = 0x1;

    uart_puts("\n==== femto_soc: FemtoRV32 + AXI4-Lite + fusao ("); uart_putu(g_clk_hz / 1000000u); uart_puts(" MHz)");
    if (g_sim) uart_puts(" [SIM]");
    uart_puts(" ====\n");

    uint32_t bad = selftest();
    uart_puts("autoteste HW x SW: ");
    if (bad == 0) uart_puts("64/64 iguais\n");
    else { uart_putu(bad); uart_puts(" DIFERENTES\n"); }

    int vl_ok = init_tof();
    if (vl_ok) uart_puts("VL53L0X ok\n");

#ifdef CALIB_MODE
    calib_loop(vl_ok);
#endif

    uart_puts("cal US: x"); put_2dec(CAL_US_GAIN_Q12 * 100u / 4096u, 100u); uart_puts(" ofs "); put_int(CAL_US_OFFSET_MM, 0);
    uart_puts(" var "); uart_putu(CAL_US_VAR_MM2);
    uart_puts(" | ToF: x"); put_2dec(CAL_TOF_GAIN_Q12 * 100u / 4096u, 100u); uart_puts(" ofs "); put_int(CAL_TOF_OFFSET_MM, 0);
    uart_puts(" var "); uart_putu(CAL_TOF_VAR_MM2); uart_putc('\n');
    uart_puts("#n US bruta>corr ToF bruta>corr dif | q var K | SW HW (n=nucleo) speedup\n");

    const uint16_t s_us  = var_floor(CAL_US_VAR_MM2);
    const uint16_t s_tof = var_floor(CAL_TOF_VAR_MM2);
    uint32_t n_fused = 0, n_mismatch = bad, total_sw = 0, total_hw = 0;
    uint32_t last_report = rdcycle();
    const uint32_t report_cyc = g_clk_hz / 1000u * REPORT_MS;

    for (uint32_t n = 1; ; n++) {
        uint16_t us_raw  = read_ultrasonic();
        uint16_t tof_raw = read_tof(vl_ok);
        uint16_t us  = apply_cal(us_raw,  CAL_US_GAIN_Q12,  CAL_US_OFFSET_MM);
        uint16_t tof = apply_cal(tof_raw, CAL_TOF_GAIN_Q12, CAL_TOF_OFFSET_MM);

        fusion_out_t sw, hw;
        uint32_t c_sw = 0, c_hw = 0, lat = 0;
        int fused = (us != NO_READ && tof != NO_READ);
        if (fused) {
            uint32_t t0;
            t0 = rdcycle(); fusion_sw(us, tof, s_us, s_tof, &sw); c_sw = rdcycle() - t0;
            t0 = rdcycle(); fusion_hw(us, tof, s_us, s_tof, &hw); c_hw = rdcycle() - t0;
            lat = FU_LAT;
            n_fused++; total_sw += c_sw; total_hw += c_hw;
            if (!same(&sw, &hw)) n_mismatch++;
            SYS_LEDS = same(&sw, &hw) ? 0x2 : 0x8;
        } else {
            SYS_LEDS = 0x4;
        }

        if (g_sim || rdcycle() - last_report >= report_cyc) {
            last_report = rdcycle();
            uart_putc('#'); uart_putu_w(n, 4);
            uart_puts(" US"); put_dist(us_raw); uart_putc('>'); put_dist(us);
            uart_puts(" ToF"); put_dist(tof_raw); uart_putc('>'); put_dist(tof);
            if (fused) {
                uart_puts(" dif"); put_int((int32_t)us - (int32_t)tof, 4);
                uart_puts(" | q"); uart_putu_w(hw.q_hat, 5);
                uart_puts(" var"); uart_putu_w(hw.sigma_new_sq, 3);
                uart_puts(" K ."); { uint32_t k3 = (hw.k * 1000u + 16384u) >> 15; if (k3 >= 1000u) uart_puts("999"); else { uart_putc((char)('0' + k3 / 100u)); uart_putc((char)('0' + k3 / 10u % 10u)); uart_putc((char)('0' + k3 % 10u)); } }
                uart_puts(" | SW "); uart_putu(c_sw); uart_puts("c "); put_us(c_sw);
                uart_puts(" HW "); uart_putu(c_hw); uart_puts("c "); put_us(c_hw);
                uart_puts(" n"); uart_putu(lat);
                uart_putc(' '); uart_putfix(c_sw, c_hw ? c_hw : 1u, 1); uart_putc('x');
                uart_puts(same(&sw, &hw) ? " ok" : " DIFERENTE!");
            } else {
                uart_puts(" | sem as duas medidas");
            }
            uart_putc('\n');
        }

        if (g_sim && n >= SIM_ROUNDS) break;
    }

    /* so' chega aqui na simulacao */
    uart_puts("fusoes "); uart_putu(n_fused);
    uart_puts(" media SW "); uart_putu(n_fused ? total_sw / n_fused : 0);
    uart_puts("c HW "); uart_putu(n_fused ? total_hw / n_fused : 0);
    uart_puts("c divergencias "); uart_putu(n_mismatch); uart_putc('\n');
    if (n_mismatch == 0 && n_fused == SIM_ROUNDS) { uart_puts("RESULT: PASS\n"); SYS_TOHOST = 1; }
    else                                          { uart_puts("RESULT: FAIL\n"); SYS_TOHOST = 3; }
    for (;;) ;
}
