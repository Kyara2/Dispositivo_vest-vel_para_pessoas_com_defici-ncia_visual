/* fusion.h -- fusao de 2 sensores (Kalman estatico, eq. 7/10/11 do paper
 * Conde et al., 2013): versao em SOFTWARE (bit-exata com o hardware) e
 * versao no COPROCESSADOR (fusion_node via AXI4-Lite). */
#ifndef FUSION_H
#define FUSION_H
#include <stdint.h>
typedef struct { uint16_t k, q_hat, sigma_new_sq; } fusion_out_t;
void fusion_sw(uint16_t q1, uint16_t q2, uint16_t s1, uint16_t s2, fusion_out_t *o);
void fusion_hw(uint16_t q1, uint16_t q2, uint16_t s1, uint16_t s2, fusion_out_t *o);
#endif
