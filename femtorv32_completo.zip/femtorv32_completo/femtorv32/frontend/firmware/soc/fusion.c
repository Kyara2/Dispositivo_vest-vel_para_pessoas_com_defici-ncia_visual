/* fusion.c -- fusao em software x no coprocessador
 * Author: Kyara Esteves de Sousa
 *
 * fusion_sw() reproduz BIT A BIT o que o fusion_node calcula em hardware
 * (mesmo formato UQ1.15 para K, mesmo arredondamento "meio para cima",
 * mesma saturacao), para que a comparacao HW x SW seja de igual para igual
 * e os resultados possam ser checados como identicos.
 *   K     = round(s1 * 2^15 / (s1 + s2))         (fusion_gain)
 *   q_hat = q1 + round((q2 - q1) * K / 2^15)     (fusion_channel), 0..65535
 *   s_new = s1 - round(s1 * K / 2^15)            (fusion_variance), >= 0
 * O Quark e' RV32I (sem multiplicador/divisor): mul e div saem da libgcc,
 * que e' exatamente o custo que o coprocessador elimina.
 */
#include "soc.h"
#include "fusion.h"

void fusion_sw(uint16_t q1, uint16_t q2, uint16_t s1, uint16_t s2, fusion_out_t *o) {
    uint32_t k = 0;
    uint32_t den = (uint32_t)s1 + s2;
    if (den != 0) k = (((uint32_t)s1 << 15) + den / 2u) / den;   /* == divisor restaurador + arredondamento */

    int32_t innov = (int32_t)q2 - (int32_t)q1;
    int32_t prod  = innov * (int32_t)k;                          /* cabe em 32 bits: |innov|<2^16, k<=2^15 */
    int32_t sum   = (int32_t)q1 + ((prod + 16384) >> 15);
    if (sum < 0) sum = 0;
    if (sum > 65535) sum = 65535;

    uint32_t rnd  = ((uint32_t)s1 * k + 16384u) >> 15;
    int32_t  snew = (int32_t)s1 - (int32_t)rnd;
    if (snew < 0) snew = 0;

    o->k = (uint16_t)k;
    o->q_hat = (uint16_t)sum;
    o->sigma_new_sq = (uint16_t)snew;
}

void fusion_hw(uint16_t q1, uint16_t q2, uint16_t s1, uint16_t s2, fusion_out_t *o) {
    FU_Q1 = q1;
    FU_Q2 = q2;
    FU_S1 = s1;
    FU_S2 = s2;
    FU_CTRL = 1;                              /* START */
    while (!(FU_STATUS & 2u)) ;               /* espera "done" */
    o->k = (uint16_t)FU_K;
    o->q_hat = (uint16_t)FU_QHAT;
    o->sigma_new_sq = (uint16_t)FU_SNEW;
}
