#!/usr/bin/env python3
"""bin2hex.py <in.bin> <out.hex> [nwords]
Converte um binario raw em palavras de 32 bits little-endian, uma por linha,
no formato do $readmemh (o testbench carrega isso na RAM a partir do
endereco 0). Completa com zeros ate nwords (default 16384 = 64 KB)."""
import sys
data = open(sys.argv[1], "rb").read()
nwords = int(sys.argv[3]) if len(sys.argv) > 3 else 16384
data += b"\0" * ((-len(data)) % 4)
words = [int.from_bytes(data[i:i+4], "little") for i in range(0, len(data), 4)]
if len(words) > nwords:
    sys.exit(f"ERRO: programa com {len(words)} palavras nao cabe em {nwords}")
nprog = len(words)
words += [0] * (nwords - len(words))   # preenche a RAM inteira (evita warning do $readmemh)
with open(sys.argv[2], "w") as f:
    for w in words:
        f.write(f"{w:08x}\n")
print(f"{sys.argv[2]}: programa de {nprog} palavras ({len(data)} bytes), RAM de {nwords} palavras")
