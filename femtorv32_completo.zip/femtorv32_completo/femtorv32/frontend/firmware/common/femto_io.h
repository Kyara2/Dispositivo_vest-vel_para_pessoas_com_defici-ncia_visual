/* femto_io.h -- mapa de memoria do testbench do FemtoRV32 Quark
 *
 *   0x000000 - 0x00FFFF   RAM (64 KB, instrucoes + dados + pilha)
 *   0x400000              TOHOST    : escrever 1 = PASS, (n<<1)|1 = FAIL no teste n
 *   0x400004              CONSOLE   : putchar (byte menos significativo)
 *   0x400008              SIGNATURE : o testbench imprime o valor em hexa
 *
 * O bit 22 marca o espaco de IO (mesma convencao da FemtoSoC original).
 */
#ifndef FEMTO_IO_H
#define FEMTO_IO_H

#define IO_BASE        0x00400000
#define IO_TOHOST      (IO_BASE + 0x0)
#define IO_CONSOLE     (IO_BASE + 0x4)
#define IO_SIGNATURE   (IO_BASE + 0x8)

#ifndef __ASSEMBLER__
#include <stdint.h>

#define MMIO32(a) (*(volatile uint32_t *)(a))

static inline void femto_putc(char c)        { MMIO32(IO_CONSOLE) = (uint32_t)(unsigned char)c; }
static inline void femto_puts(const char *s) { while (*s) femto_putc(*s++); }
static inline void femto_signature(uint32_t v) { MMIO32(IO_SIGNATURE) = v; }

static inline void femto_puthex(uint32_t v) {
    for (int i = 28; i >= 0; i -= 4) {
        uint32_t d = (v >> i) & 0xF;
        femto_putc((char)(d < 10 ? '0' + d : 'a' + d - 10));
    }
}

static inline uint32_t femto_rdcycle(void) {
    uint32_t c;
    __asm__ volatile ("rdcycle %0" : "=r"(c));
    return c;
}
#endif
#endif
