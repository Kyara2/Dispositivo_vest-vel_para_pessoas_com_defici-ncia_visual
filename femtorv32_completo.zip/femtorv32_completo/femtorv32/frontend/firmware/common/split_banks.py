#!/usr/bin/env python3
"""split_banks.py <in.hex> <prefixo> <n_bancos>
Divide um .hex de palavras (1 por linha, a partir do endereco 0) em
n_bancos arquivos de 1024 palavras: <prefixo>_b0.hex, _b1.hex, ...
(um por macro/BSRAM da femto_sram, usados para inicializar a FPGA)."""
import sys
words = [l.strip() for l in open(sys.argv[1]) if l.strip()]
pre, nb = sys.argv[2], int(sys.argv[3])
words += ["00000000"] * (nb * 1024 - len(words))
for b in range(nb):
    with open(f"{pre}_b{b}.hex", "w") as f:
        f.write("\n".join(words[b*1024:(b+1)*1024]) + "\n")
print(f"{nb} bancos: {pre}_b0..{nb-1}.hex")
