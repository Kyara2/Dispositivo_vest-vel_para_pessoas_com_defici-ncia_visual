/* GERADO por c_suite.c -DHOST (gcc nativo) -- nao editar */
#define C_SUITE_NK 10
static const uint32_t expected[C_SUITE_NK] = {
    0x00000262u, /* fib */
    0xba0d459fu, /* sort */
    0x0ff16903u, /* crc32 */
    0x0c41a0edu, /* sieve */
    0xe1f3c00fu, /* muldiv */
    0x532558a4u, /* string */
    0xbcee7014u, /* switch */
    0xb1e3c8d1u, /* struct */
    0x9c6a3f1cu, /* matmul */
    0xe98f32b1u, /* shifts */
};
