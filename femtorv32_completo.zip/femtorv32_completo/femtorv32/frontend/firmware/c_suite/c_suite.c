/* c_suite.c -- testes funcionais "de programa real" para o FemtoRV32 Quark.
 *
 * O MESMO arquivo e' compilado de dois jeitos:
 *   - no host (gcc nativo, -DHOST): roda os kernels e gera
 *     c_suite_expected.h com os resultados de referencia;
 *   - para RV32I: roda os kernels no processador e compara com
 *     c_suite_expected.h. main() retorna 0 (PASS) ou o numero do
 *     primeiro kernel que divergiu (o start.S manda isso pro TOHOST).
 *
 * Cada kernel exercita uma parte diferente do nucleo: chamadas e pilha
 * (recursao), loads/stores de byte/half/word com e sem sinal, shifts
 * variaveis (o Quark faz 1 bit/ciclo), multiplicacao/divisao em software
 * (libgcc __mulsi3/__divsi3/__modsi3, ja' que o Quark e' so' RV32I),
 * tabelas de salto (switch denso -> jalr), comparacoes com/sem sinal.
 */
#include <stdint.h>

#ifdef HOST
#include <stdio.h>
#else
#include "femto_io.h"
#include "c_suite_expected.h"
#endif

/* ------------------------------------------------------------------ */
/* gcc pode gerar chamadas implicitas a memset/memcpy mesmo com         */
/* -fno-builtin (zerar/copiar arrays); como nao ha libc, definimos aqui */
/* ------------------------------------------------------------------ */
#ifndef HOST
void *memset(void *d, int c, unsigned n) {
    unsigned char *p = d;
    while (n--) *p++ = (unsigned char)c;
    return d;
}
void *memcpy(void *d, const void *s, unsigned n) {
    unsigned char *p = d; const unsigned char *q = s;
    while (n--) *p++ = *q++;
    return d;
}
#endif

static uint32_t lcg_state;
static uint32_t lcg(void) {
    lcg_state = lcg_state * 1664525u + 1013904223u;
    return lcg_state;
}

/* 1 -- recursao (pilha, jal/jalr, sw/lw de ra) */
static uint32_t fib(uint32_t n) { return n < 2 ? n : fib(n - 1) + fib(n - 2); }
static uint32_t k_fib(void) { return fib(15); }

/* 2 -- bubble sort com inteiros com sinal (blt, slt) */
static uint32_t k_sort(void) {
    int32_t v[48];
    lcg_state = 12345;
    for (int i = 0; i < 48; i++) v[i] = (int32_t)lcg() >> 7;
    for (int i = 0; i < 47; i++)
        for (int j = 0; j < 47 - i; j++)
            if (v[j] > v[j + 1]) { int32_t t = v[j]; v[j] = v[j + 1]; v[j + 1] = t; }
    uint32_t h = 0;
    for (int i = 0; i < 48; i++) {
        if (i && v[i - 1] > v[i]) return 0xBAD0BAD0u;   /* nao ordenou */
        h = (h << 5) ^ (h >> 27) ^ (uint32_t)v[i];
    }
    return h;
}

/* 3 -- CRC32 bit a bit (shifts, xor, lbu) */
static uint32_t k_crc32(void) {
    uint8_t buf[200];
    for (int i = 0; i < 200; i++) buf[i] = (uint8_t)(i * 7 + 3);
    uint32_t crc = 0xFFFFFFFFu;
    for (int i = 0; i < 200; i++) {
        crc ^= buf[i];
        for (int b = 0; b < 8; b++)
            crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1u)));
    }
    return ~crc;
}

/* 4 -- crivo de Eratostenes (sb/lbu, lacos aninhados) */
static uint32_t k_sieve(void) {
    static uint8_t comp[1200];
    uint32_t count = 0, sum = 0;
    for (int i = 0; i < 1200; i++) comp[i] = 0;
    for (int i = 2; i < 1200; i++) {
        if (!comp[i]) {
            count++; sum += (uint32_t)i;
            for (int j = i + i; j < 1200; j += i) comp[j] = 1;
        }
    }
    return (count << 20) ^ sum;
}

/* 5 -- mul/div/mod em software (libgcc), com e sem sinal */
static uint32_t k_muldiv(void) {
    uint32_t acc = 0;
    lcg_state = 777;
    for (int i = 0; i < 24; i++) {
        int32_t a = (int32_t)lcg();
        int32_t b = (int32_t)(lcg() >> 16) - 30000;
        if (b == 0) b = 7;
        uint32_t ua = lcg(), ub = (lcg() >> 20) | 1u;
        acc += (uint32_t)a * (uint32_t)b;
        acc ^= (uint32_t)(a / b);
        acc += (uint32_t)(a % b);
        acc ^= ua / ub;
        acc += ua % ub;
        acc = (acc << 3) | (acc >> 29);
    }
    return acc;
}

/* 6 -- strings: strlen, copia, reverso, comparacao (lb com sinal) */
static int my_strlen(const char *s) { int n = 0; while (s[n]) n++; return n; }
static int my_strcmp(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return (int)(signed char)*a - (int)(signed char)*b;
}
static uint32_t k_string(void) {
    const char *src = "FemtoRV32 Quark no Cadence Genus - GPDK045 \x81\xfe";
    char buf[64];
    int n = my_strlen(src);
    for (int i = 0; i <= n; i++) buf[i] = src[i];
    for (int i = 0; i < n / 2; i++) { char t = buf[i]; buf[i] = buf[n - 1 - i]; buf[n - 1 - i] = t; }
    uint32_t h = (uint32_t)n;
    for (int i = 0; i < n; i++) h = h * 31u + (uint32_t)(int32_t)(signed char)buf[i];
    int c1 = my_strcmp(src, buf);
    int c2 = my_strcmp(src, src);
    return h ^ ((uint32_t)c1 << 8) ^ (uint32_t)c2;
}

/* 7 -- switch denso (tabela de saltos -> lw + jalr) */
static uint32_t op_switch(uint32_t op, uint32_t a, uint32_t b) {
    switch (op & 15u) {
        case 0:  return a + b;
        case 1:  return a - b;
        case 2:  return a ^ b;
        case 3:  return a | b;
        case 4:  return a & b;
        case 5:  return a << (b & 31u);
        case 6:  return a >> (b & 31u);
        case 7:  return (uint32_t)((int32_t)a >> (b & 31u));
        case 8:  return (int32_t)a < (int32_t)b;
        case 9:  return a < b;
        case 10: return ~a;
        case 11: return a + 0x1234u;
        case 12: return (a >> 16) | (a << 16);
        case 13: return a == b;
        case 14: return a ? a - 1u : 0xFFFFFFFFu;
        default: return 42u;
    }
}
static uint32_t k_switch(void) {
    uint32_t acc = 1;
    lcg_state = 4242;
    for (int i = 0; i < 64; i++) {
        uint32_t a = acc ^ lcg();      /* chamadas sequenciadas: a ordem de */
        uint32_t b = lcg();            /* avaliacao de argumentos em C nao e' */
        acc = op_switch((uint32_t)i, a, b) + acc * 3u;   /* definida */
    }
    return acc;
}

/* 8 -- structs com campos de 8/16 bits com sinal (lb/lh/lhu/sh/sb) */
struct pkt { uint8_t id; int8_t delta; int16_t temp; uint16_t raw; int32_t acc; };
static uint32_t k_struct(void) {
    struct pkt p[16];
    lcg_state = 99;
    for (int i = 0; i < 16; i++) {
        uint32_t r = lcg();
        p[i].id = (uint8_t)r; p[i].delta = (int8_t)(r >> 8);
        p[i].temp = (int16_t)(r >> 12); p[i].raw = (uint16_t)(r >> 3);
        p[i].acc = 0;
    }
    for (int i = 0; i < 16; i++)
        p[i].acc = p[i].delta * 3 + p[i].temp - (int32_t)p[i].raw + p[i].id;
    uint32_t h = 0;
    for (int i = 0; i < 16; i++) h = (h ^ (uint32_t)p[i].acc) * 0x01000193u;
    return h;
}

/* 9 -- matriz 6x6 inteira (muitas mults em software + indexacao) */
static uint32_t k_matmul(void) {
    int32_t A[6][6], B[6][6], C[6][6];
    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 6; j++) { A[i][j] = i * 7 - j * 3 - 5; B[i][j] = (i ^ j) - 2 * j + 1; }
    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 6; j++) {
            int32_t s = 0;
            for (int k = 0; k < 6; k++) s += A[i][k] * B[k][j];
            C[i][j] = s;
        }
    uint32_t h = 0;
    for (int i = 0; i < 6; i++) for (int j = 0; j < 6; j++) h = h * 33u + (uint32_t)C[i][j];
    return h;
}

/* 10 -- shifts variaveis com e sem sinal, todos os 32 valores */
static uint32_t k_shifts(void) {
    volatile uint32_t x = 0x9ABCDEF1u;   /* volatile: impede const-folding */
    uint32_t acc = 0;
    for (uint32_t s = 0; s < 32; s++) {
        acc += x << s;
        acc ^= x >> s;
        acc += (uint32_t)((int32_t)x >> s);
    }
    return acc;
}

typedef uint32_t (*kernel_t)(void);
static const kernel_t kernels[] = {
    k_fib, k_sort, k_crc32, k_sieve, k_muldiv,
    k_string, k_switch, k_struct, k_matmul, k_shifts
};
static const char *const names[] = {
    "fib", "sort", "crc32", "sieve", "muldiv",
    "string", "switch", "struct", "matmul", "shifts"
};
#define NK ((int)(sizeof(kernels) / sizeof(kernels[0])))

#ifdef HOST
int main(void) {
    printf("/* GERADO por c_suite.c -DHOST (gcc nativo) -- nao editar */\n");
    printf("#define C_SUITE_NK %d\n", NK);
    printf("static const uint32_t expected[C_SUITE_NK] = {\n");
    for (int i = 0; i < NK; i++) printf("    0x%08xu, /* %s */\n", kernels[i](), names[i]);
    printf("};\n");
    return 0;
}
#else
int main(void) {
    int first_fail = 0;
    femto_puts("c_suite: FemtoRV32 Quark\n");
    for (int i = 0; i < NK; i++) {
        uint32_t t0 = femto_rdcycle();
        uint32_t r  = kernels[i]();
        uint32_t dt = femto_rdcycle() - t0;
        femto_signature(r);
        femto_puts(r == expected[i] ? "  ok   " : "  FAIL ");
        femto_puts(names[i]);
        femto_puts("  res=0x"); femto_puthex(r);
        femto_puts(" exp=0x");  femto_puthex(expected[i]);
        femto_puts(" ciclos=0x"); femto_puthex(dt);
        femto_putc('\n');
        if (r != expected[i] && !first_fail) first_fail = i + 1;
    }
    return first_fail;
}
#endif
