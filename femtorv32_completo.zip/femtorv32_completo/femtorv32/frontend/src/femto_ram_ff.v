//=============================================================================
// femto_ram_ff.v -- RAM do FemtoRV32 sintetizada em FLIP-FLOPS (sem macro)
// Author: Kyara Esteves de Sousa
//
// Mesma interface e mesma latencia (1 ciclo) do femto_sram.v, mas o array
// e' RTL puro: o Genus transforma cada bit em um flip-flop + a logica de
// escrita/leitura (mux de WORDS:1 por bit). E' isso que o Genus "faz" quando
// se escreve uma memoria em Verilog -- ele NAO gera SRAM.
//
// Serve para (1) comparar area/timing com a macro no relatorio e (2) ter
// um plano B para memorias pequenas. Para 4 KB ja' sao 32768 flip-flops;
// por isso o default aqui e' 256 palavras (1 KB).
//=============================================================================

`timescale 1ns / 1ps

module femto_ram_ff #(
    parameter WORDS = 256                    // potencia de 2
)(
    input  wire        clk,
    input  wire        sel,
    input  wire [31:0] mem_addr,
    input  wire [31:0] mem_wdata,
    input  wire [3:0]  mem_wmask,
    input  wire        mem_rstrb,
    output reg  [31:0] mem_rdata,
    output wire        mem_rbusy,
    output wire        mem_wbusy
);

    localparam AW = $clog2(WORDS);

    reg  [31:0] mem [0:WORDS-1];
    wire [AW-1:0] word = mem_addr[AW+1:2];

    always @(posedge clk) begin
        if (sel & mem_wmask[0]) mem[word][ 7: 0] <= mem_wdata[ 7: 0];
        if (sel & mem_wmask[1]) mem[word][15: 8] <= mem_wdata[15: 8];
        if (sel & mem_wmask[2]) mem[word][23:16] <= mem_wdata[23:16];
        if (sel & mem_wmask[3]) mem[word][31:24] <= mem_wdata[31:24];
        if (sel & mem_rstrb)    mem_rdata        <= mem[word];
    end

    assign mem_rbusy = 1'b0;
    assign mem_wbusy = 1'b0;

endmodule
