//=============================================================================
// femto_axil_master.v -- ponte: barramento nativo do FemtoRV32 Quark ->
// mestre AXI4-Lite (32 bits de dados e endereco).
// Author: Kyara Esteves de Sousa
//
// O Quark tem no maximo UMA transacao pendente (ele espera mem_rbusy/
// mem_wbusy antes de pedir outra), entao a ponte e' uma FSM simples:
//
//   leitura : mem_rstrb -> ARVALID ... (AR aceito) ... RVALID -> dado
//             registrado em rdata_q e mem_rbusy cai NO MESMO ciclo em que
//             rdata_q fica valido (o Quark le mem_rdata no ciclo em que ve
//             mem_rbusy=0).
//   escrita : mem_wmask!=0 -> AWVALID+WVALID juntos (WSTRB = mem_wmask; o
//             Quark ja' posiciona os bytes nas faixas certas) ... BVALID.
//
// mem_rbusy/mem_wbusy sobem na borda que aceita o pedido, ou seja, ja' estao
// altos no ciclo seguinte -- que e' quando a FSM do Quark testa esses sinais.
// RRESP/BRESP de erro sao contados em err_count (debug), mas nao travam a CPU.
//=============================================================================
`timescale 1ns / 1ps

module femto_axil_master (
    input  wire        clk,
    input  wire        rst_n,

    // lado FemtoRV32 (interface nativa)
    input  wire [31:0] mem_addr,
    input  wire [31:0] mem_wdata,
    input  wire [3:0]  mem_wmask,
    input  wire        mem_rstrb,
    output wire [31:0] mem_rdata,
    output reg         mem_rbusy,
    output reg         mem_wbusy,

    // lado AXI4-Lite (mestre)
    output reg  [31:0] m_awaddr,
    output wire [2:0]  m_awprot,
    output reg         m_awvalid,
    input  wire        m_awready,
    output reg  [31:0] m_wdata,
    output reg  [3:0]  m_wstrb,
    output reg         m_wvalid,
    input  wire        m_wready,
    input  wire [1:0]  m_bresp,
    input  wire        m_bvalid,
    output wire        m_bready,
    output reg  [31:0] m_araddr,
    output wire [2:0]  m_arprot,
    output reg         m_arvalid,
    input  wire        m_arready,
    input  wire [31:0] m_rdata,
    input  wire [1:0]  m_rresp,
    input  wire        m_rvalid,
    output wire        m_rready,

    output reg  [7:0]  err_count
);
    localparam S_IDLE = 2'd0, S_RD = 2'd1, S_WR = 2'd2;
    reg [1:0]  state;
    reg [31:0] rdata_q;

    assign mem_rdata = rdata_q;
    assign m_awprot  = 3'b000;
    assign m_arprot  = 3'b000;
    assign m_rready  = (state == S_RD);
    assign m_bready  = (state == S_WR);

    always @(posedge clk) begin
        if (!rst_n) begin
            state     <= S_IDLE;
            mem_rbusy <= 1'b0;
            mem_wbusy <= 1'b0;
            m_awvalid <= 1'b0;
            m_wvalid  <= 1'b0;
            m_arvalid <= 1'b0;
            m_awaddr  <= 32'b0;
            m_araddr  <= 32'b0;
            m_wdata   <= 32'b0;
            m_wstrb   <= 4'b0;
            rdata_q   <= 32'b0;
            err_count <= 8'b0;
        end else begin
            case (state)
                S_IDLE: begin
                    if (mem_rstrb) begin
                        m_araddr  <= mem_addr;
                        m_arvalid <= 1'b1;
                        mem_rbusy <= 1'b1;
                        state     <= S_RD;
                    end else if (|mem_wmask) begin
                        m_awaddr  <= mem_addr;
                        m_wdata   <= mem_wdata;
                        m_wstrb   <= mem_wmask;
                        m_awvalid <= 1'b1;
                        m_wvalid  <= 1'b1;
                        mem_wbusy <= 1'b1;
                        state     <= S_WR;
                    end
                end
                S_RD: begin
                    if (m_arvalid && m_arready) m_arvalid <= 1'b0;
                    if (m_rvalid) begin                       // m_rready = 1 neste estado
                        rdata_q   <= m_rdata;
                        mem_rbusy <= 1'b0;
                        if (m_rresp != 2'b00 && err_count != 8'hFF) err_count <= err_count + 8'd1;
                        state     <= S_IDLE;
                    end
                end
                S_WR: begin
                    if (m_awvalid && m_awready) m_awvalid <= 1'b0;
                    if (m_wvalid  && m_wready)  m_wvalid  <= 1'b0;
                    if (m_bvalid) begin                       // m_bready = 1 neste estado
                        mem_wbusy <= 1'b0;
                        if (m_bresp != 2'b00 && err_count != 8'hFF) err_count <= err_count + 8'd1;
                        state     <= S_IDLE;
                    end
                end
                default: state <= S_IDLE;
            endcase
        end
    end
endmodule
