//=============================================================================
// axil_xbar.v -- interconexao AXI4-Lite 1 mestre x NS escravos
// Author: Kyara Esteves de Sousa
//
// Mapa de enderecos (decodificado aqui):
//   escravo 0            : RAM,  0x000000 .. RAM_BYTES-1        (bit 22 = 0)
//   escravo 1 .. NS-1    : IO,   0x400000 + (i-1)*0x100         (bit 22 = 1)
//   qualquer outro       : responde DECERR (rdata = 0) -- a CPU nao trava
//
// Como o mestre (femto_axil_master) tem no maximo uma transacao pendente
// por vez, o roteamento e' simples: AR/AW+W vao para o escravo decodificado
// e o escravo escolhido e' memorizado ate' a resposta (R/B) voltar.
// Os canais dos escravos sao vetores "achatados" (escravo i nos bits
// [i*32 +: 32], etc.) para manter Verilog-2001.
//=============================================================================
`timescale 1ns / 1ps

module axil_xbar #(
    parameter NS        = 6,            // numero de escravos (1 RAM + NS-1 IO)
    parameter RAM_BYTES = 16384
)(
    input  wire                 clk,
    input  wire                 rst_n,

    // escravo (lado do mestre)
    input  wire [31:0]          s_awaddr,
    input  wire                 s_awvalid,
    output wire                 s_awready,
    input  wire [31:0]          s_wdata,
    input  wire [3:0]           s_wstrb,
    input  wire                 s_wvalid,
    output wire                 s_wready,
    output wire [1:0]           s_bresp,
    output wire                 s_bvalid,
    input  wire                 s_bready,
    input  wire [31:0]          s_araddr,
    input  wire                 s_arvalid,
    output wire                 s_arready,
    output wire [31:0]          s_rdata,
    output wire [1:0]           s_rresp,
    output wire                 s_rvalid,
    input  wire                 s_rready,

    // mestres (lado dos escravos), achatados
    output wire [NS*32-1:0]     m_awaddr,
    output wire [NS-1:0]        m_awvalid,
    input  wire [NS-1:0]        m_awready,
    output wire [NS*32-1:0]     m_wdata,
    output wire [NS*4-1:0]      m_wstrb,
    output wire [NS-1:0]        m_wvalid,
    input  wire [NS-1:0]        m_wready,
    input  wire [NS*2-1:0]      m_bresp,
    input  wire [NS-1:0]        m_bvalid,
    output wire [NS-1:0]        m_bready,
    output wire [NS*32-1:0]     m_araddr,
    output wire [NS-1:0]        m_arvalid,
    input  wire [NS-1:0]        m_arready,
    input  wire [NS*32-1:0]     m_rdata,
    input  wire [NS*2-1:0]      m_rresp,
    input  wire [NS-1:0]        m_rvalid,
    output wire [NS-1:0]        m_rready
);
    localparam SW = (NS > 1) ? $clog2(NS + 1) : 1;   // largura do indice (+1 p/ "nenhum")
    localparam [SW-1:0] NONE = NS;                   // indice do respondedor de erro

    function [SW-1:0] decode;
        input [31:0] a;
        begin
            if (!a[22])
                decode = (a < RAM_BYTES) ? {SW{1'b0}} : NONE;
            else if (a[21:12] == 10'd0 && a[11:8] < (NS - 1))
                decode = a[11:8] + 1'b1;
            else
                decode = NONE;
        end
    endfunction

    wire [SW-1:0] rd_dec = decode(s_araddr);
    wire [SW-1:0] wr_dec = decode(s_awaddr);

    // escravo "travado" para a resposta
    reg  [SW-1:0] rd_sel, wr_sel;
    reg           rd_busy, wr_busy;

    // respondedor de erro (endereco nao mapeado)
    reg           err_rvalid, err_bvalid;

    // ---------------- leitura
    wire rd_go = s_arvalid && !rd_busy;
    genvar i;
    generate
        for (i = 0; i < NS; i = i + 1) begin : g_rd
            assign m_araddr [i*32 +: 32] = s_araddr;
            assign m_arvalid[i]          = rd_go && (rd_dec == i);
            assign m_rready [i]          = rd_busy && (rd_sel == i) && s_rready;
        end
    endgenerate

    assign s_arready = rd_go && ((rd_dec == NONE) ? 1'b1 : m_arready[rd_dec]);

    always @(posedge clk) begin
        if (!rst_n) begin
            rd_busy    <= 1'b0;
            rd_sel     <= NONE;
            err_rvalid <= 1'b0;
        end else begin
            if (s_arvalid && s_arready) begin
                rd_busy    <= 1'b1;
                rd_sel     <= rd_dec;
                err_rvalid <= (rd_dec == NONE);
            end else if (s_rvalid && s_rready) begin
                rd_busy    <= 1'b0;
                err_rvalid <= 1'b0;
            end
        end
    end

    assign s_rvalid = rd_busy && ((rd_sel == NONE) ? err_rvalid : m_rvalid[rd_sel]);
    assign s_rdata  = (rd_sel == NONE) ? 32'h0   : m_rdata[rd_sel*32 +: 32];
    assign s_rresp  = (rd_sel == NONE) ? 2'b11   : m_rresp[rd_sel*2 +: 2];   // DECERR

    // ---------------- escrita (AW e W andam juntos neste SoC)
    wire wr_go = s_awvalid && s_wvalid && !wr_busy;
    generate
        for (i = 0; i < NS; i = i + 1) begin : g_wr
            assign m_awaddr [i*32 +: 32] = s_awaddr;
            assign m_wdata  [i*32 +: 32] = s_wdata;
            assign m_wstrb  [i*4  +: 4]  = s_wstrb;
            assign m_awvalid[i]          = wr_go && (wr_dec == i);
            assign m_wvalid [i]          = wr_go && (wr_dec == i);
            assign m_bready [i]          = wr_busy && (wr_sel == i) && s_bready;
        end
    endgenerate

    wire wr_acc = (wr_dec == NONE) ? 1'b1 : (m_awready[wr_dec] && m_wready[wr_dec]);
    assign s_awready = wr_go && wr_acc;
    assign s_wready  = wr_go && wr_acc;

    always @(posedge clk) begin
        if (!rst_n) begin
            wr_busy    <= 1'b0;
            wr_sel     <= NONE;
            err_bvalid <= 1'b0;
        end else begin
            if (s_awvalid && s_awready) begin
                wr_busy    <= 1'b1;
                wr_sel     <= wr_dec;
                err_bvalid <= (wr_dec == NONE);
            end else if (s_bvalid && s_bready) begin
                wr_busy    <= 1'b0;
                err_bvalid <= 1'b0;
            end
        end
    end

    assign s_bvalid = wr_busy && ((wr_sel == NONE) ? err_bvalid : m_bvalid[wr_sel]);
    assign s_bresp  = (wr_sel == NONE) ? 2'b11 : m_bresp[wr_sel*2 +: 2];
endmodule
