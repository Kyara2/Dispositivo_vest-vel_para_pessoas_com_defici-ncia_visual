//=============================================================================
// periph_i2c.v -- mestre I2C byte a byte (escravo AXI4-Lite), usado para o
// sensor laser de tempo de voo VL53L0X (endereco 7 bits 0x29)
// Author: Kyara Esteves de Sousa
//
// O VL53L0X precisa de ~150 escritas de configuracao antes de medir
// (sequencia da ST, portada no firmware a partir da biblioteca da Pololu),
// por isso o hardware fica no nivel de "byte": o firmware monta cada
// transacao e le o resultado da distancia por MMIO.
//
// Registradores:
//   0x00 PRESCALE (RW) ciclos de clock por QUARTO de periodo de SCL
//                      (100 kHz @ 27 MHz -> 67; 400 kHz -> 17)
//   0x04 CMD      (W)  bit0 START (ou START repetido), bit1 STOP,
//                      bit2 WRITE (envia TXDATA), bit3 READ (recebe em RXDATA),
//                      bit4 NACK (na leitura, responde NACK = ultimo byte)
//                      ordem de execucao: START -> WRITE/READ -> STOP
//   0x08 TXDATA   (RW) byte a enviar
//   0x0C RXDATA   (R)  ultimo byte recebido
//   0x10 STATUS   (R)  bit0 busy, bit1 nack (escravo nao reconheceu o
//                      ultimo WRITE), bit2 SDA, bit3 SCL (nivel nos pinos)
//
// Saidas open-drain: *_oe = 1 puxa a linha para 0; *_oe = 0 solta (pull-up
// externo leva a 1). Suporta clock stretching (espera SCL subir de verdade).
//=============================================================================
`timescale 1ns / 1ps

module periph_i2c #(
    parameter PRESCALE_RST = 67
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire [31:0] s_awaddr,  input  wire s_awvalid, output wire s_awready,
    input  wire [31:0] s_wdata,   input  wire [3:0] s_wstrb, input wire s_wvalid, output wire s_wready,
    output wire [1:0]  s_bresp,   output wire s_bvalid,  input  wire s_bready,
    input  wire [31:0] s_araddr,  input  wire s_arvalid, output wire s_arready,
    output wire [31:0] s_rdata,   output wire [1:0] s_rresp, output wire s_rvalid, input wire s_rready,
    input  wire        scl_i,
    output wire        scl_oe,
    input  wire        sda_i,
    output wire        sda_oe
);
    wire        wr_en, rd_en;
    wire [7:0]  wr_addr, rd_addr;
    wire [31:0] wr_data;
    wire [3:0]  wr_strb;
    reg  [31:0] rd_data;

    axil2reg #(.AW(8)) u_if (
        .clk(clk), .rst_n(rst_n),
        .s_awaddr(s_awaddr), .s_awvalid(s_awvalid), .s_awready(s_awready),
        .s_wdata(s_wdata), .s_wstrb(s_wstrb), .s_wvalid(s_wvalid), .s_wready(s_wready),
        .s_bresp(s_bresp), .s_bvalid(s_bvalid), .s_bready(s_bready),
        .s_araddr(s_araddr), .s_arvalid(s_arvalid), .s_arready(s_arready),
        .s_rdata(s_rdata), .s_rresp(s_rresp), .s_rvalid(s_rvalid), .s_rready(s_rready),
        .wr_en(wr_en), .wr_addr(wr_addr), .wr_data(wr_data), .wr_strb(wr_strb),
        .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd_data));

    // sincroniza as linhas (podem mudar a qualquer momento)
    reg [1:0] scl_s, sda_s;
    always @(posedge clk) begin
        if (!rst_n) begin scl_s <= 2'b11; sda_s <= 2'b11; end
        else        begin scl_s <= {scl_s[0], scl_i}; sda_s <= {sda_s[0], sda_i}; end
    end
    wire scl_in = scl_s[1];
    wire sda_in = sda_s[1];

    reg [15:0] prescale;
    reg [7:0]  txdata, rxdata;
    reg        nack;

    // ------------------------------------------------------------ motor de bits
    localparam ST_IDLE = 3'd0, ST_START = 3'd1, ST_BIT = 3'd2, ST_STOP = 3'd3, ST_NEXT = 3'd4;

    reg [2:0]  st;
    reg [1:0]  q;            // quarto de periodo dentro da fase atual
    reg [15:0] cnt;
    reg        scl_r, sda_r; // nivel desejado (1 = solta a linha)
    reg        do_start, do_stop, do_wr, do_rd, do_nack;
    reg [3:0]  bitn;         // 0..7 dados, 8 = ACK
    reg [7:0]  sh;

    assign scl_oe = ~scl_r;
    assign sda_oe = ~sda_r;
    wire busy = (st != ST_IDLE);

    wire tick = (cnt == 16'd0);

    always @(posedge clk) begin
        if (!rst_n) begin
            st       <= ST_IDLE;
            q        <= 2'd0;
            cnt      <= 16'd0;
            scl_r    <= 1'b1;
            sda_r    <= 1'b1;
            prescale <= PRESCALE_RST;
            txdata   <= 8'h00;
            rxdata   <= 8'h00;
            nack     <= 1'b0;
            do_start <= 1'b0; do_stop <= 1'b0; do_wr <= 1'b0; do_rd <= 1'b0; do_nack <= 1'b0;
            bitn     <= 4'd0;
            sh       <= 8'h00;
        end else begin
            // escrita de registradores (CMD so' e' aceito com o motor parado)
            if (wr_en) begin
                case (wr_addr[7:2])
                    6'd0: prescale <= (wr_data[15:0] == 16'd0) ? 16'd1 : wr_data[15:0];
                    6'd2: txdata   <= wr_data[7:0];
                    6'd1: if (!busy) begin
                        do_start <= wr_data[0];
                        do_stop  <= wr_data[1];
                        do_wr    <= wr_data[2];
                        do_rd    <= wr_data[3] & ~wr_data[2];
                        do_nack  <= wr_data[4];
                        st       <= ST_NEXT;
                        q        <= 2'd0;
                        cnt      <= 16'd0;
                    end
                    default: ;
                endcase
            end

            if (busy && st != ST_NEXT) begin
                if (!tick) begin
                    cnt <= cnt - 16'd1;
                end else if (q == 2'd2 && scl_r && !scl_in) begin
                    // clock stretching: o escravo esta' segurando SCL baixo
                    cnt <= 16'd0;
                end else begin
                    cnt <= prescale - 16'd1;
                    q   <= q + 2'd1;

                    case (st)
                        // START (ou START repetido): SDA cai com SCL alto
                        ST_START: case (q)
                            2'd0: begin sda_r <= 1'b1; scl_r <= 1'b0; end
                            2'd1: begin sda_r <= 1'b1; scl_r <= 1'b1; end
                            2'd2: begin sda_r <= 1'b0; scl_r <= 1'b1; end
                            2'd3: begin sda_r <= 1'b0; scl_r <= 1'b0; do_start <= 1'b0; st <= ST_NEXT; end
                        endcase

                        // um bit de dado/ACK: muda SDA com SCL baixo, amostra com SCL alto
                        ST_BIT: case (q)
                            2'd0: begin
                                scl_r <= 1'b0;
                                if (bitn < 4'd8) sda_r <= do_wr ? sh[7] : 1'b1;        // escrita: dado; leitura: solta
                                else             sda_r <= do_wr ? 1'b1 : do_nack;       // ACK: escrita solta; leitura: ACK=0/NACK=1
                            end
                            2'd1: scl_r <= 1'b1;
                            2'd2: begin
                                if (bitn < 4'd8) begin
                                    if (!do_wr) sh <= {sh[6:0], sda_in};               // leitura: amostra o bit
                                end else if (do_wr) begin
                                    nack <= sda_in;                                    // 1 = escravo nao reconheceu
                                end
                            end
                            2'd3: begin
                                scl_r <= 1'b0;
                                if (bitn == 4'd8) begin
                                    if (do_rd) rxdata <= sh;
                                    do_wr <= 1'b0; do_rd <= 1'b0;
                                    st    <= ST_NEXT;
                                end else begin
                                    bitn <= bitn + 4'd1;
                                    if (do_wr && bitn < 4'd8) sh <= {sh[6:0], 1'b0};
                                end
                            end
                        endcase

                        // STOP: SDA sobe com SCL alto
                        ST_STOP: case (q)
                            2'd0: begin scl_r <= 1'b0; sda_r <= 1'b0; end
                            2'd1: begin scl_r <= 1'b1; sda_r <= 1'b0; end
                            2'd2: begin scl_r <= 1'b1; sda_r <= 1'b1; end
                            2'd3: begin do_stop <= 1'b0; st <= ST_NEXT; end
                        endcase
                        default: ;
                    endcase
                end
            end

            // sequenciador: START -> byte -> STOP -> IDLE
            if (st == ST_NEXT && !(wr_en && wr_addr[7:2] == 6'd1)) begin
                q   <= 2'd0;
                cnt <= prescale - 16'd1;
                if (do_start)              st <= ST_START;
                else if (do_wr || do_rd) begin
                    st   <= ST_BIT;
                    bitn <= 4'd0;
                    sh   <= do_wr ? txdata : 8'h00;
                    if (do_wr) nack <= 1'b0;
                end
                else if (do_stop)          st <= ST_STOP;
                else                       st <= ST_IDLE;
            end
        end
    end

    always @(*) begin
        case (rd_addr[7:2])
            6'd0:    rd_data = {16'b0, prescale};
            6'd2:    rd_data = {24'b0, txdata};
            6'd3:    rd_data = {24'b0, rxdata};
            6'd4:    rd_data = {28'b0, scl_in, sda_in, nack, busy};
            default: rd_data = 32'b0;
        endcase
    end
endmodule
