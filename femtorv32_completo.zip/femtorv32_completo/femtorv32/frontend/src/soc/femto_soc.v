//=============================================================================
// femto_soc.v -- SoC: FemtoRV32 Quark + RAM (macros OpenRAM) + coprocessador
// de fusao sensorial (fusion_node) + sensores, tudo em AXI4-Lite
// Author: Kyara Esteves de Sousa
//
//              +------------------+
//   FemtoRV32  | femto_axil_master|  AXI4-Lite   +-----------+
//   Quark  ----|  (ponte nativa)  |--------------| axil_xbar |
//              +------------------+              +-----------+
//                                                  |  escravos:
//     0  0x000000  RAM      axil_sram -> femto_sram (RAM_BANKS x 4 KB, macros)
//     1  0x400000  SYSINFO  periph_sysinfo (CLK_HZ, flag SIM, LEDs)
//     2  0x400100  UART     periph_uart    (TX 8N1 -> terminal)
//     3  0x400200  HCSR04   periph_hcsr04  (ultrassom, distancia em mm)
//     4  0x400300  I2C      periph_i2c     (VL53L0X, laser ToF)
//     5  0x400400  FUSION   periph_fusion  (1 fusion_node: K, q_hat, sigma^2)
//
// Mesmo RTL para o Cadence (RAM = macros sram_32x1024_freepdk45) e para a
// Tang Primer 20K (com o parametro FPGA=1 a femto_sram usa BSRAM inicializada
// com o firmware; ver fpga/). O programa roda da RAM a partir do endereco 0.
//
// I2C: portas separadas (entrada / habilita-puxa-para-zero). O top da FPGA
// transforma em pinos tri-state; no ASIC isso fica com os pads.
//=============================================================================
`timescale 1ns / 1ps

module femto_soc #(
    parameter CLK_HZ       = 27000000,
    parameter SIM          = 0,
    parameter RAM_BANKS    = 4,                          // 16 KB
    parameter BAUD         = 115200,
    parameter UART_DIV     = CLK_HZ / BAUD,
    parameter US_PERIOD    = CLK_HZ / 1000 * 60,         // HC-SR04: 60 ms entre medidas
    parameter US_TIMEOUT   = CLK_HZ / 1000 * 38,
    parameter I2C_PRESCALE = CLK_HZ / 400000,            // 100 kHz (quarto de periodo)
    parameter FPGA         = 0,                          // 1 = RAM em BSRAM com firmware (Tang Primer 20K)
    parameter INIT_PREFIX  = "soc_fw"                    // FPGA: soc_fw_b0.hex .. b3.hex
)(
    input  wire       clk,
    input  wire       rst_n,          // assincrono, ativo baixo (botao / pad)

    output wire       uart_tx,

    output wire       us_trig,        // HC-SR04
    input  wire       us_echo,

    input  wire       i2c_scl_i,      // VL53L0X
    output wire       i2c_scl_oe,
    input  wire       i2c_sda_i,
    output wire       i2c_sda_oe,

    output wire [3:0] leds
);
    localparam NS = 6;

    // ---------------- reset: assercao assincrona, liberacao sincrona
    reg [2:0] rst_sync;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) rst_sync <= 3'b000;
        else        rst_sync <= {rst_sync[1:0], 1'b1};
    end
    wire rstn = rst_sync[2];

    // ---------------- CPU
    wire [31:0] mem_addr, mem_wdata, mem_rdata;
    wire [3:0]  mem_wmask;
    wire        mem_rstrb, mem_rbusy, mem_wbusy;

    femtorv32_quark #(.RESET_ADDR(32'h0), .ADDR_WIDTH(24)) u_cpu (
        .clk(clk),
        .mem_addr(mem_addr), .mem_wdata(mem_wdata), .mem_wmask(mem_wmask),
        .mem_rdata(mem_rdata), .mem_rstrb(mem_rstrb),
        .mem_rbusy(mem_rbusy), .mem_wbusy(mem_wbusy),
        .reset(rstn)
    );

    // ---------------- ponte -> AXI4-Lite
    wire [31:0] m_awaddr, m_wdata, m_araddr, m_rdata;
    wire [3:0]  m_wstrb;
    wire [2:0]  m_awprot, m_arprot;
    wire [1:0]  m_bresp, m_rresp;
    wire        m_awvalid, m_awready, m_wvalid, m_wready, m_bvalid, m_bready;
    wire        m_arvalid, m_arready, m_rvalid, m_rready;
    wire [7:0]  bus_err;

    femto_axil_master u_bridge (
        .clk(clk), .rst_n(rstn),
        .mem_addr(mem_addr), .mem_wdata(mem_wdata), .mem_wmask(mem_wmask),
        .mem_rstrb(mem_rstrb), .mem_rdata(mem_rdata),
        .mem_rbusy(mem_rbusy), .mem_wbusy(mem_wbusy),
        .m_awaddr(m_awaddr), .m_awprot(m_awprot), .m_awvalid(m_awvalid), .m_awready(m_awready),
        .m_wdata(m_wdata), .m_wstrb(m_wstrb), .m_wvalid(m_wvalid), .m_wready(m_wready),
        .m_bresp(m_bresp), .m_bvalid(m_bvalid), .m_bready(m_bready),
        .m_araddr(m_araddr), .m_arprot(m_arprot), .m_arvalid(m_arvalid), .m_arready(m_arready),
        .m_rdata(m_rdata), .m_rresp(m_rresp), .m_rvalid(m_rvalid), .m_rready(m_rready),
        .err_count(bus_err)
    );

    // ---------------- crossbar
    wire [NS*32-1:0] x_awaddr, x_wdata, x_araddr, x_rdata;
    wire [NS*4-1:0]  x_wstrb;
    wire [NS*2-1:0]  x_bresp, x_rresp;
    wire [NS-1:0]    x_awvalid, x_awready, x_wvalid, x_wready, x_bvalid, x_bready;
    wire [NS-1:0]    x_arvalid, x_arready, x_rvalid, x_rready;

    axil_xbar #(.NS(NS), .RAM_BYTES(RAM_BANKS * 4096)) u_xbar (
        .clk(clk), .rst_n(rstn),
        .s_awaddr(m_awaddr), .s_awvalid(m_awvalid), .s_awready(m_awready),
        .s_wdata(m_wdata), .s_wstrb(m_wstrb), .s_wvalid(m_wvalid), .s_wready(m_wready),
        .s_bresp(m_bresp), .s_bvalid(m_bvalid), .s_bready(m_bready),
        .s_araddr(m_araddr), .s_arvalid(m_arvalid), .s_arready(m_arready),
        .s_rdata(m_rdata), .s_rresp(m_rresp), .s_rvalid(m_rvalid), .s_rready(m_rready),
        .m_awaddr(x_awaddr), .m_awvalid(x_awvalid), .m_awready(x_awready),
        .m_wdata(x_wdata), .m_wstrb(x_wstrb), .m_wvalid(x_wvalid), .m_wready(x_wready),
        .m_bresp(x_bresp), .m_bvalid(x_bvalid), .m_bready(x_bready),
        .m_araddr(x_araddr), .m_arvalid(x_arvalid), .m_arready(x_arready),
        .m_rdata(x_rdata), .m_rresp(x_rresp), .m_rvalid(x_rvalid), .m_rready(x_rready)
    );

    // atalho para ligar o escravo i do crossbar
    `define AXIL_PORTS(i) \
        .s_awaddr (x_awaddr [(i)*32 +: 32]), .s_awvalid(x_awvalid[i]), .s_awready(x_awready[i]), \
        .s_wdata  (x_wdata  [(i)*32 +: 32]), .s_wstrb  (x_wstrb[(i)*4 +: 4]), \
        .s_wvalid (x_wvalid [i]),            .s_wready (x_wready [i]), \
        .s_bresp  (x_bresp  [(i)*2 +: 2]),   .s_bvalid (x_bvalid [i]), .s_bready (x_bready [i]), \
        .s_araddr (x_araddr [(i)*32 +: 32]), .s_arvalid(x_arvalid[i]), .s_arready(x_arready[i]), \
        .s_rdata  (x_rdata  [(i)*32 +: 32]), .s_rresp  (x_rresp[(i)*2 +: 2]), \
        .s_rvalid (x_rvalid [i]),            .s_rready (x_rready [i])

    // 0: RAM
    axil_sram #(.BANKS(RAM_BANKS), .FPGA(FPGA), .INIT_PREFIX(INIT_PREFIX)) u_ram (
        .clk(clk), .rst_n(rstn), `AXIL_PORTS(0));

    // 1: SYSINFO
    wire [31:0] tohost;
    periph_sysinfo #(.CLK_HZ(CLK_HZ), .SIM(SIM)) u_sys (
        .clk(clk), .rst_n(rstn), `AXIL_PORTS(1),
        .bus_err_count(bus_err), .leds(leds), .tohost(tohost));

    // 2: UART
    periph_uart #(.DIV(UART_DIV)) u_uart (
        .clk(clk), .rst_n(rstn), `AXIL_PORTS(2), .uart_tx(uart_tx));

    // 3: HC-SR04
    periph_hcsr04 #(.CLK_HZ(CLK_HZ), .PERIOD_CYC(US_PERIOD), .TIMEOUT_CYC(US_TIMEOUT)) u_us (
        .clk(clk), .rst_n(rstn), `AXIL_PORTS(3), .trigger(us_trig), .echo(us_echo));

    // 4: I2C (VL53L0X)
    periph_i2c #(.PRESCALE_RST(I2C_PRESCALE)) u_i2c (
        .clk(clk), .rst_n(rstn), `AXIL_PORTS(4),
        .scl_i(i2c_scl_i), .scl_oe(i2c_scl_oe), .sda_i(i2c_sda_i), .sda_oe(i2c_sda_oe));

    // 5: FUSION (coprocessador)
    wire fusion_irq_unused;
    periph_fusion #(.W(16), .FRAC(15)) u_fusion (
        .clk(clk), .rst_n(rstn), `AXIL_PORTS(5), .irq_done(fusion_irq_unused));

    `undef AXIL_PORTS
endmodule
