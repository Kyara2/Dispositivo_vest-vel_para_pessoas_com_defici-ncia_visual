//=============================================================================
// periph_sysinfo.v -- informacoes do sistema + LEDs (escravo AXI4-Lite)
// Author: Kyara Esteves de Sousa
//
//   0x00 ID       (R)  0x46454D53 ("FEMS")
//   0x04 CLK_HZ   (R)  frequencia do clock do SoC (o firmware calcula baud,
//                      tempos em us e timeouts a partir daqui)
//   0x08 FLAGS    (R)  bit0 = SIM (1 na simulacao: firmware encurta esperas
//                      e encerra depois de N rodadas)
//   0x0C LEDS     (RW) bits [3:0] -> pinos de LED
//   0x10 TOHOST   (RW) usado so' na simulacao (o firmware escreve o resultado)
//   0x14 BUSERR   (R)  respostas de erro vistas pela ponte AXI (debug)
//=============================================================================
`timescale 1ns / 1ps

module periph_sysinfo #(
    parameter CLK_HZ = 27000000,
    parameter SIM    = 0
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire [31:0] s_awaddr,  input  wire s_awvalid, output wire s_awready,
    input  wire [31:0] s_wdata,   input  wire [3:0] s_wstrb, input wire s_wvalid, output wire s_wready,
    output wire [1:0]  s_bresp,   output wire s_bvalid,  input  wire s_bready,
    input  wire [31:0] s_araddr,  input  wire s_arvalid, output wire s_arready,
    output wire [31:0] s_rdata,   output wire [1:0] s_rresp, output wire s_rvalid, input wire s_rready,
    input  wire [7:0]  bus_err_count,
    output reg  [3:0]  leds,
    output reg  [31:0] tohost
);
    wire        wr_en, rd_en;
    wire [7:0]  wr_addr, rd_addr;
    wire [31:0] wr_data;
    wire [3:0]  wr_strb;
    reg  [31:0] rd_data;

    axil2reg #(.AW(8)) u_if (
        .clk(clk), .rst_n(rst_n),
        .s_awaddr(s_awaddr), .s_awvalid(s_awvalid), .s_awready(s_awready),
        .s_wdata(s_wdata), .s_wstrb(s_wstrb), .s_wvalid(s_wvalid), .s_wready(s_wready),
        .s_bresp(s_bresp), .s_bvalid(s_bvalid), .s_bready(s_bready),
        .s_araddr(s_araddr), .s_arvalid(s_arvalid), .s_arready(s_arready),
        .s_rdata(s_rdata), .s_rresp(s_rresp), .s_rvalid(s_rvalid), .s_rready(s_rready),
        .wr_en(wr_en), .wr_addr(wr_addr), .wr_data(wr_data), .wr_strb(wr_strb),
        .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd_data));

    always @(posedge clk) begin
        if (!rst_n) begin
            leds   <= 4'b0;
            tohost <= 32'b0;
        end else if (wr_en) begin
            if (wr_addr[7:2] == 6'd3) leds   <= wr_data[3:0];
            if (wr_addr[7:2] == 6'd4) tohost <= wr_data;
        end
    end

    always @(*) begin
        case (rd_addr[7:2])
            6'd0:    rd_data = 32'h46454D53;
            6'd1:    rd_data = CLK_HZ;
            6'd2:    rd_data = {31'b0, (SIM != 0)};
            6'd3:    rd_data = {28'b0, leds};
            6'd4:    rd_data = tohost;
            6'd5:    rd_data = {24'b0, bus_err_count};
            default: rd_data = 32'b0;
        endcase
    end
endmodule
