//=============================================================================
// periph_hcsr04.v -- controlador do sensor ultrassonico HC-SR04 com leitura
// por MMIO (escravo AXI4-Lite)
// Author: Kyara Esteves de Sousa
//
// Baseado no controlador_ultrassonico.v (mesma ideia: gera o trigger
// periodicamente e conta o pulso de echo em "fatias" de distancia), com:
//   - unidade em MILIMETROS (o nucleo de fusao trabalha em mm);
//   - constantes derivadas de CLK_HZ (o original era fixo em 12 MHz:
//     696 ciclos/cm). 5,8 us de echo por mm (ida e volta, ~343 m/s);
//   - reset sincrono ativo-baixo (padrao do SoC, sintetizavel em ASIC);
//   - timeout (sem obstaculo o HC-SR04 segura o echo ~38 ms, ou nunca
//     responde) e contador de amostras / flag de "dado novo".
//
// Registradores:
//   0x00 DIST_MM     (R) ultima distancia valida, mm  (ler limpa STATUS.new)
//   0x04 STATUS      (R) bit0 valid (ja' mediu ao menos uma vez), bit1 new,
//                        bit2 timeout na ultima tentativa
//   0x08 COUNT       (R) numero de medicoes validas
//   0x0C ECHO_CYCLES (R) largura do ultimo echo, em ciclos de clock
//   0x10 CYC_PER_MM  (R) constante usada
//
// ATENCAO (hardware): o HC-SR04 e' 5 V. O pino ECHO precisa de divisor
// resistivo / level shifter antes de entrar na FPGA (3,3 V).
//=============================================================================
`timescale 1ns / 1ps

module periph_hcsr04 #(
    parameter CLK_HZ      = 27000000,
    parameter PERIOD_CYC  = CLK_HZ / 1000 * 60,      // 60 ms entre medidas (datasheet)
    parameter TRIG_CYC    = CLK_HZ / 1000000 * 10,   // pulso de trigger de 10 us
    parameter TIMEOUT_CYC = CLK_HZ / 1000 * 38       // echo > 38 ms = sem obstaculo
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire [31:0] s_awaddr,  input  wire s_awvalid, output wire s_awready,
    input  wire [31:0] s_wdata,   input  wire [3:0] s_wstrb, input wire s_wvalid, output wire s_wready,
    output wire [1:0]  s_bresp,   output wire s_bvalid,  input  wire s_bready,
    input  wire [31:0] s_araddr,  input  wire s_arvalid, output wire s_arready,
    output wire [31:0] s_rdata,   output wire [1:0] s_rresp, output wire s_rvalid, input wire s_rready,
    output reg         trigger,
    input  wire        echo
);
    // ciclos por mm = CLK_HZ * 5,8 us, arredondado (27 MHz -> 157; 12 MHz -> 70)
    localparam CYC_PER_MM = ((CLK_HZ / 1000) * 58 + 5000) / 10000;

    wire        wr_en, rd_en;
    wire [7:0]  wr_addr, rd_addr;
    wire [31:0] wr_data;
    wire [3:0]  wr_strb;
    reg  [31:0] rd_data;

    axil2reg #(.AW(8)) u_if (
        .clk(clk), .rst_n(rst_n),
        .s_awaddr(s_awaddr), .s_awvalid(s_awvalid), .s_awready(s_awready),
        .s_wdata(s_wdata), .s_wstrb(s_wstrb), .s_wvalid(s_wvalid), .s_wready(s_wready),
        .s_bresp(s_bresp), .s_bvalid(s_bvalid), .s_bready(s_bready),
        .s_araddr(s_araddr), .s_arvalid(s_arvalid), .s_arready(s_arready),
        .s_rdata(s_rdata), .s_rresp(s_rresp), .s_rvalid(s_rvalid), .s_rready(s_rready),
        .wr_en(wr_en), .wr_addr(wr_addr), .wr_data(wr_data), .wr_strb(wr_strb),
        .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd_data));

    // ---------------- sincronizacao do echo (entrada assincrona)
    reg [2:0] echo_sync;
    always @(posedge clk) begin
        if (!rst_n) echo_sync <= 3'b000;
        else        echo_sync <= {echo_sync[1:0], echo};
    end
    wire echo_rise = (echo_sync[2:1] == 2'b01);
    wire echo_fall = (echo_sync[2:1] == 2'b10);

    // ---------------- trigger periodico
    reg [31:0] t;
    always @(posedge clk) begin
        if (!rst_n) begin
            t       <= 32'd0;
            trigger <= 1'b0;
        end else begin
            t       <= (t >= PERIOD_CYC - 1) ? 32'd0 : t + 32'd1;
            trigger <= (t < TRIG_CYC);
        end
    end
    wire period_start = (t == 32'd0);

    // ---------------- medicao do echo
    reg        measuring, got_echo;
    reg [31:0] echo_cnt;
    reg [15:0] sub_cnt;
    reg [15:0] mm_cnt;

    reg [15:0] dist_mm;
    reg [31:0] echo_cycles, count;
    reg        valid, new_flag, timeout_flag;

    always @(posedge clk) begin
        if (!rst_n) begin
            measuring    <= 1'b0;
            got_echo     <= 1'b0;
            echo_cnt     <= 32'd0;
            sub_cnt      <= 16'd0;
            mm_cnt       <= 16'd0;
            dist_mm      <= 16'd0;
            echo_cycles  <= 32'd0;
            count        <= 32'd0;
            valid        <= 1'b0;
            new_flag     <= 1'b0;
            timeout_flag <= 1'b0;
        end else begin
            // ler DIST_MM limpa "new" (uma medida que termina no mesmo ciclo
            // vence, porque e' atribuida depois)
            if (rd_en && rd_addr[7:2] == 6'd0) new_flag <= 1'b0;

            // novo ciclo de trigger: se a tentativa anterior nem respondeu, e' timeout
            if (period_start) begin
                if (!got_echo && !measuring) timeout_flag <= 1'b1;
                got_echo <= 1'b0;
            end

            if (echo_rise) begin
                measuring <= 1'b1;
                got_echo  <= 1'b1;
                echo_cnt  <= 32'd0;
                sub_cnt   <= 16'd0;
                mm_cnt    <= 16'd0;
            end else if (measuring) begin
                echo_cnt <= echo_cnt + 32'd1;
                if (sub_cnt == CYC_PER_MM - 1) begin
                    sub_cnt <= 16'd0;
                    if (mm_cnt != 16'hFFFF) mm_cnt <= mm_cnt + 16'd1;
                end else begin
                    sub_cnt <= sub_cnt + 16'd1;
                end

                if (echo_fall) begin
                    measuring    <= 1'b0;
                    dist_mm      <= mm_cnt;
                    echo_cycles  <= echo_cnt;
                    count        <= count + 32'd1;
                    valid        <= 1'b1;
                    new_flag     <= 1'b1;
                    timeout_flag <= 1'b0;
                end else if (echo_cnt >= TIMEOUT_CYC) begin
                    measuring    <= 1'b0;           // sem obstaculo / echo preso
                    timeout_flag <= 1'b1;
                end
            end

        end
    end

    always @(*) begin
        case (rd_addr[7:2])
            6'd0:    rd_data = {16'b0, dist_mm};
            6'd1:    rd_data = {29'b0, timeout_flag, new_flag, valid};
            6'd2:    rd_data = count;
            6'd3:    rd_data = echo_cycles;
            6'd4:    rd_data = CYC_PER_MM;
            default: rd_data = 32'b0;
        endcase
    end
endmodule
