//=============================================================================
// axil2reg.v -- escravo AXI4-Lite generico -> barramento simples de
// registradores (usado por todos os perifericos de IO do SoC).
// Author: Kyara Esteves de Sousa
//
//   escrita: AW e W aceitos juntos -> wr_en pulsa 1 ciclo com wr_addr/
//            wr_data/wr_strb; BVALID no ciclo seguinte.
//   leitura: AR aceito -> rd_en pulsa 1 ciclo com rd_addr; o periferico
//            devolve rd_data COMBINACIONALMENTE nesse mesmo ciclo; o dado e'
//            registrado e RVALID sobe no ciclo seguinte. rd_en serve para
//            efeitos colaterais de leitura (ex.: limpar flag "dado novo").
//=============================================================================
`timescale 1ns / 1ps

module axil2reg #(
    parameter AW = 8                    // bits de endereco dentro do periferico
)(
    input  wire          clk,
    input  wire          rst_n,

    input  wire [31:0]   s_awaddr,
    input  wire          s_awvalid,
    output wire          s_awready,
    input  wire [31:0]   s_wdata,
    input  wire [3:0]    s_wstrb,
    input  wire          s_wvalid,
    output wire          s_wready,
    output wire [1:0]    s_bresp,
    output reg           s_bvalid,
    input  wire          s_bready,
    input  wire [31:0]   s_araddr,
    input  wire          s_arvalid,
    output wire          s_arready,
    output reg  [31:0]   s_rdata,
    output wire [1:0]    s_rresp,
    output reg           s_rvalid,
    input  wire          s_rready,

    output wire          wr_en,
    output wire [AW-1:0] wr_addr,
    output wire [31:0]   wr_data,
    output wire [3:0]    wr_strb,
    output wire          rd_en,
    output wire [AW-1:0] rd_addr,
    input  wire [31:0]   rd_data
);
    assign s_awready = s_awvalid && s_wvalid && !s_bvalid;
    assign s_wready  = s_awready;
    assign s_bresp   = 2'b00;
    assign s_arready = s_arvalid && !s_rvalid;
    assign s_rresp   = 2'b00;

    assign wr_en   = s_awready;
    assign wr_addr = s_awaddr[AW-1:0];
    assign wr_data = s_wdata;
    assign wr_strb = s_wstrb;
    assign rd_en   = s_arready;
    assign rd_addr = s_araddr[AW-1:0];

    always @(posedge clk) begin
        if (!rst_n) begin
            s_bvalid <= 1'b0;
            s_rvalid <= 1'b0;
            s_rdata  <= 32'b0;
        end else begin
            if (wr_en)                     s_bvalid <= 1'b1;
            else if (s_bvalid && s_bready) s_bvalid <= 1'b0;

            if (rd_en) begin
                s_rvalid <= 1'b1;
                s_rdata  <= rd_data;
            end else if (s_rvalid && s_rready) begin
                s_rvalid <= 1'b0;
            end
        end
    end
endmodule
