//=============================================================================
// axil_sram.v -- escravo AXI4-Lite em volta da femto_sram (macros OpenRAM)
// Author: Kyara Esteves de Sousa
//
// Reaproveita a femto_sram ja' sintetizada/validada (mesma casca, mesmas
// macros). A macro registra o pedido na subida e entrega o dado no ciclo
// seguinte (valido ate' a proxima subida), entao:
//   AR aceito no ciclo N -> RVALID no ciclo N+1 com RDATA = saida da macro.
//   Se o mestre nao aceitar (RREADY=0) nesse ciclo, o dado e' guardado em
//   rdata_hold (a saida da macro vira X depois da subida) -- AXI exige RDATA
//   estavel enquanto RVALID estiver alto.
//   AW+W aceitos no ciclo N -> escrita na macro, BVALID no ciclo N+1.
// Porta unica: leitura tem prioridade se AR e AW chegarem juntos (nao
// acontece com o femto_axil_master, que tem 1 transacao por vez).
//=============================================================================
`timescale 1ns / 1ps

module axil_sram #(
    parameter BANKS       = 4,           // 4 KB por banco
    parameter FPGA        = 0,           // repassado a' femto_sram (BSRAM + firmware)
    parameter INIT_PREFIX = "soc_fw"
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire [31:0] s_awaddr,
    input  wire        s_awvalid,
    output wire        s_awready,
    input  wire [31:0] s_wdata,
    input  wire [3:0]  s_wstrb,
    input  wire        s_wvalid,
    output wire        s_wready,
    output wire [1:0]  s_bresp,
    output reg         s_bvalid,
    input  wire        s_bready,
    input  wire [31:0] s_araddr,
    input  wire        s_arvalid,
    output wire        s_arready,
    output wire [31:0] s_rdata,
    output wire [1:0]  s_rresp,
    output reg         s_rvalid,
    input  wire        s_rready
);
    wire idle = !s_rvalid && !s_bvalid;

    wire rd_acc = s_arvalid && idle;
    wire wr_acc = s_awvalid && s_wvalid && idle && !s_arvalid;

    assign s_arready = rd_acc;
    assign s_awready = wr_acc;
    assign s_wready  = wr_acc;
    assign s_bresp   = 2'b00;
    assign s_rresp   = 2'b00;

    wire [31:0] ram_rdata;
    wire        ram_rbusy_unused, ram_wbusy_unused;

    femto_sram #(.BANKS(BANKS), .FPGA(FPGA), .INIT_PREFIX(INIT_PREFIX)) u_ram (
        .clk       (clk),
        .sel       (rd_acc | wr_acc),
        .mem_addr  (rd_acc ? s_araddr : s_awaddr),
        .mem_wdata (s_wdata),
        .mem_wmask (wr_acc ? s_wstrb : 4'b0000),
        .mem_rstrb (rd_acc),
        .mem_rdata (ram_rdata),
        .mem_rbusy (ram_rbusy_unused),
        .mem_wbusy (ram_wbusy_unused)
    );

    reg        first;        // 1 = primeiro ciclo de RVALID (dado vem direto da macro)
    reg [31:0] rdata_hold;

    assign s_rdata = first ? ram_rdata : rdata_hold;

    always @(posedge clk) begin
        if (!rst_n) begin
            s_rvalid   <= 1'b0;
            s_bvalid   <= 1'b0;
            first      <= 1'b0;
            rdata_hold <= 32'b0;
        end else begin
            if (rd_acc) begin
                s_rvalid <= 1'b1;
                first    <= 1'b1;
            end else if (s_rvalid) begin
                if (s_rready) begin
                    s_rvalid <= 1'b0;
                    first    <= 1'b0;
                end else if (first) begin
                    rdata_hold <= ram_rdata;     // mestre atrasou: segura o dado
                    first      <= 1'b0;
                end
            end

            if (wr_acc)                     s_bvalid <= 1'b1;
            else if (s_bvalid && s_bready)  s_bvalid <= 1'b0;
        end
    end
endmodule
