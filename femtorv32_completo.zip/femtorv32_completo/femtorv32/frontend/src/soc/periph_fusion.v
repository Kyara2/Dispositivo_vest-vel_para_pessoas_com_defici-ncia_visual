//=============================================================================
// periph_fusion.v -- coprocessador de fusao sensorial (1 fusion_node) como
// escravo AXI4-Lite do SoC FemtoRV32
// Author: Kyara Esteves de Sousa
//
// O fusion_node (gain -> channel + variance) calcula, para um par de medidas:
//   K      = s1/(s1+s2)          (UQ1.15, 32768 = 1.0)       eq. 11
//   q_hat  = q1 + K*(q2-q1)      (mm)                        eq. 7/9
//   s_new  = s1 - K*s1           (mm^2)                      eq. 10
// (q1 = ultrassom, q2 = laser ToF, s = variancias sigma^2 em mm^2)
//
// Registradores:
//   0x00 Q1        (RW) medida 1, mm
//   0x04 Q2        (RW) medida 2, mm
//   0x08 SIGMA1_SQ (RW) variancia do sensor 1, mm^2
//   0x0C SIGMA2_SQ (RW) variancia do sensor 2, mm^2
//   0x10 CTRL      (W)  bit0 = START (ignorado se ocupado)
//   0x14 STATUS    (R)  bit0 busy, bit1 done (vai a 1 no resultado, zera no START)
//   0x18 K         (R)  ganho UQ1.15
//   0x1C QHAT      (R)  estimativa fundida, mm
//   0x20 SIGMA_NEW (R)  variancia apos a fusao, mm^2
//   0x24 LAT       (R)  ciclos do START ate' o resultado (so' o nucleo)
//   0x28 ID        (R)  0xF0510001 (versao: 1 node)
//
// Escrever Q1..SIGMA2 nao dispara nada: o firmware escreve os 4 e da' START
// (o fusion_node copia as entradas no START, entao podem mudar depois).
// Para o fusion_core com 8 nodes, basta replicar o banco de registradores
// (ou usar um offset por canal) -- a interface do node e' a mesma.
//=============================================================================
`timescale 1ns / 1ps

module periph_fusion #(
    parameter W    = 16,
    parameter FRAC = 15
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire [31:0] s_awaddr,  input  wire s_awvalid, output wire s_awready,
    input  wire [31:0] s_wdata,   input  wire [3:0] s_wstrb, input wire s_wvalid, output wire s_wready,
    output wire [1:0]  s_bresp,   output wire s_bvalid,  input  wire s_bready,
    input  wire [31:0] s_araddr,  input  wire s_arvalid, output wire s_arready,
    output wire [31:0] s_rdata,   output wire [1:0] s_rresp, output wire s_rvalid, input wire s_rready,
    output wire        irq_done                      // pulso de 1 ciclo no resultado (nao usado pelo Quark)
);
    wire        wr_en, rd_en;
    wire [7:0]  wr_addr, rd_addr;
    wire [31:0] wr_data;
    wire [3:0]  wr_strb;
    reg  [31:0] rd_data;

    axil2reg #(.AW(8)) u_if (
        .clk(clk), .rst_n(rst_n),
        .s_awaddr(s_awaddr), .s_awvalid(s_awvalid), .s_awready(s_awready),
        .s_wdata(s_wdata), .s_wstrb(s_wstrb), .s_wvalid(s_wvalid), .s_wready(s_wready),
        .s_bresp(s_bresp), .s_bvalid(s_bvalid), .s_bready(s_bready),
        .s_araddr(s_araddr), .s_arvalid(s_arvalid), .s_arready(s_arready),
        .s_rdata(s_rdata), .s_rresp(s_rresp), .s_rvalid(s_rvalid), .s_rready(s_rready),
        .wr_en(wr_en), .wr_addr(wr_addr), .wr_data(wr_data), .wr_strb(wr_strb),
        .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd_data));

    reg  [W-1:0] q1, q2, s1, s2;
    reg  [W-1:0] k_r, qhat_r, snew_r;
    reg          done;
    reg  [31:0]  lat, lat_cnt;
    reg          start;

    wire         node_busy, node_valid;
    wire [W-1:0] node_k, node_qhat, node_snew;

    fusion_node #(.W(W), .FRAC(FRAC)) u_node (
        .clk(clk), .rst_n(rst_n),
        .in_valid(start),
        .q1(q1), .q2(q2), .sigma1_sq(s1), .sigma2_sq(s2),
        .busy(node_busy), .out_valid(node_valid),
        .k(node_k), .q_hat(node_qhat), .sigma_new_sq(node_snew)
    );

    assign irq_done = node_valid;

    always @(posedge clk) begin
        if (!rst_n) begin
            q1 <= {W{1'b0}}; q2 <= {W{1'b0}}; s1 <= {W{1'b0}}; s2 <= {W{1'b0}};
            k_r <= {W{1'b0}}; qhat_r <= {W{1'b0}}; snew_r <= {W{1'b0}};
            done <= 1'b0; start <= 1'b0;
            lat <= 32'd0; lat_cnt <= 32'd0;
        end else begin
            start <= 1'b0;
            if (wr_en) begin
                case (wr_addr[7:2])
                    6'd0: q1 <= wr_data[W-1:0];
                    6'd1: q2 <= wr_data[W-1:0];
                    6'd2: s1 <= wr_data[W-1:0];
                    6'd3: s2 <= wr_data[W-1:0];
                    6'd4: if (wr_data[0] && !node_busy && !start) begin
                              start   <= 1'b1;
                              done    <= 1'b0;
                              lat_cnt <= 32'd0;
                          end
                    default: ;
                endcase
            end

            if (node_busy || start) lat_cnt <= lat_cnt + 32'd1;

            if (node_valid) begin
                k_r    <= node_k;
                qhat_r <= node_qhat;
                snew_r <= node_snew;
                done   <= 1'b1;
                lat    <= lat_cnt + 32'd1;
            end
        end
    end

    always @(*) begin
        case (rd_addr[7:2])
            6'd0:    rd_data = {{(32-W){1'b0}}, q1};
            6'd1:    rd_data = {{(32-W){1'b0}}, q2};
            6'd2:    rd_data = {{(32-W){1'b0}}, s1};
            6'd3:    rd_data = {{(32-W){1'b0}}, s2};
            6'd5:    rd_data = {30'b0, done, node_busy | start};
            6'd6:    rd_data = {{(32-W){1'b0}}, k_r};
            6'd7:    rd_data = {{(32-W){1'b0}}, qhat_r};
            6'd8:    rd_data = {{(32-W){1'b0}}, snew_r};
            6'd9:    rd_data = lat;
            6'd10:   rd_data = 32'hF0510001;
            default: rd_data = 32'b0;
        endcase
    end
endmodule
