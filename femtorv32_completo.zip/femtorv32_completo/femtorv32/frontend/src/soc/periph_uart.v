//=============================================================================
// periph_uart.v -- UART TX 8N1 (escravo AXI4-Lite)
// Author: Kyara Esteves de Sousa
//
// Registradores (offset):
//   0x00 TXDATA  (W)  escreve um byte e inicia a transmissao (ignorado se ocupado)
//   0x04 STATUS  (R)  bit0 = tx_busy
//   0x08 DIV     (R)  ciclos de clock por bit (CLK_HZ/BAUD)
// Na Tang Primer 20K Dock o TX vai para o pino M11, que chega no PC pela
// mesma USB do programador (BL616) como uma porta serial.
//=============================================================================
`timescale 1ns / 1ps

module periph_uart #(
    parameter DIV = 234                  // 27 MHz / 115200
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire [31:0] s_awaddr,  input  wire s_awvalid, output wire s_awready,
    input  wire [31:0] s_wdata,   input  wire [3:0] s_wstrb, input wire s_wvalid, output wire s_wready,
    output wire [1:0]  s_bresp,   output wire s_bvalid,  input  wire s_bready,
    input  wire [31:0] s_araddr,  input  wire s_arvalid, output wire s_arready,
    output wire [31:0] s_rdata,   output wire [1:0] s_rresp, output wire s_rvalid, input wire s_rready,
    output reg         uart_tx
);
    wire        wr_en, rd_en;
    wire [7:0]  wr_addr, rd_addr;
    wire [31:0] wr_data;
    wire [3:0]  wr_strb;
    reg  [31:0] rd_data;

    axil2reg #(.AW(8)) u_if (
        .clk(clk), .rst_n(rst_n),
        .s_awaddr(s_awaddr), .s_awvalid(s_awvalid), .s_awready(s_awready),
        .s_wdata(s_wdata), .s_wstrb(s_wstrb), .s_wvalid(s_wvalid), .s_wready(s_wready),
        .s_bresp(s_bresp), .s_bvalid(s_bvalid), .s_bready(s_bready),
        .s_araddr(s_araddr), .s_arvalid(s_arvalid), .s_arready(s_arready),
        .s_rdata(s_rdata), .s_rresp(s_rresp), .s_rvalid(s_rvalid), .s_rready(s_rready),
        .wr_en(wr_en), .wr_addr(wr_addr), .wr_data(wr_data), .wr_strb(wr_strb),
        .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd_data));

    reg        active;
    reg [3:0]  idx;            // bit em transmissao: 0 = start, 1..8 = dados, 9 = stop
    reg [15:0] cnt;
    reg [9:0]  frame;
    wire       busy = active;

    always @(posedge clk) begin
        if (!rst_n) begin
            uart_tx <= 1'b1;
            active  <= 1'b0;
            idx     <= 4'd0;
            cnt     <= 16'd0;
            frame   <= 10'h3FF;
        end else if (!active) begin
            uart_tx <= 1'b1;
            if (wr_en && wr_addr[7:2] == 6'd0 && wr_strb[0]) begin
                frame   <= {1'b1, wr_data[7:0], 1'b0};   // stop, dados (LSB primeiro), start
                uart_tx <= 1'b0;                          // start bit ja' na saida
                active  <= 1'b1;
                idx     <= 4'd0;
                cnt     <= DIV - 1;
            end
        end else if (cnt != 16'd0) begin
            cnt <= cnt - 16'd1;
        end else begin
            cnt <= DIV - 1;
            if (idx == 4'd9) begin
                active  <= 1'b0;                          // stop bit durou DIV ciclos
            end else begin
                idx     <= idx + 4'd1;
                uart_tx <= frame[idx + 4'd1];
            end
        end
    end

    always @(*) begin
        case (rd_addr[7:2])
            6'd1:    rd_data = {31'b0, busy};
            6'd2:    rd_data = DIV;
            default: rd_data = 32'b0;
        endcase
    end
endmodule
