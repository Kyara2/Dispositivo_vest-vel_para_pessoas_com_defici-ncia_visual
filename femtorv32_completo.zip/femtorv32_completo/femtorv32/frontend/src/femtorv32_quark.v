/*******************************************************************/
// FemtoRV32 "Quark" -- versao adaptada para sintese ASIC (Cadence Genus,
// GPDK045) e simulacao gate-level com SDF no Xcelium.
//
// Original: learn-fpga/FemtoRV/RTL/PROCESSOR/femtorv32_quark.v
//           Bruno Levy, Matthias Koch, 2020-2021 (licenca BSD-3, ver repo)
//           https://github.com/BrunoLevy/learn-fpga
// Copia intocada do original: frontend/upstream/femtorv32_quark.v
//
// Instruction set: RV32I + RDCYCLE (sem CSR, sem IRQ, FENCE nao suportado)
//
// Mudancas em relacao ao original (todas marcadas com [ASIC-n] no codigo):
//
//  [ASIC-1] Modulo renomeado de FemtoRV32 para femtorv32_quark, para bater
//           com HDL_NAME/DESIGN do fluxo (todas as variantes do FemtoRV
//           usam o mesmo nome de modulo FemtoRV32 no repo original).
//  [ASIC-2] Declaracoes reordenadas (declare-before-use). O original usa
//           varios sinais antes de declara-los (instr, state, PC, cycles,
//           LOAD_data, writeBack, funct3IsShift...), o que o Yosys aceita
//           mas e' fora do LRM e pode virar erro/warning no Genus/Xcelium.
//  [ASIC-3] Reset sincrono (mesmo "reset" ativo-baixo do original) tambem
//           em instr, aluShamt, aluReg e cycles. Em FPGA esses registradores
//           nascem em 0 pelo bitstream; em ASIC nascem X, e aluShamt=X
//           trava a FSM em WAIT_ALU_OR_MEM na simulacao pos-sintese
//           (aluBusy = |aluShamt = X). O original so' zerava isso dentro de
//           `ifdef BENCH (initial), que nao e' sintetizavel.
//  [ASIC-4] Leitura de x0 forcada a zero no proprio decode. No original,
//           registerFile[0] nunca e' escrito e dependia do valor inicial 0
//           do FPGA (ou do initial do BENCH). Em ASIC seria um FF sem
//           driver (X), e o Genus pode remove-lo/deixa-lo flutuando.
//
// O comportamento funcional (ISA, temporizacao de ciclos, interface de
// memoria) e' identico ao original.
//
// Parameters:
//  RESET_ADDR  endereco de reset (default 0)
//  ADDR_WIDTH  largura do barramento de endereco interno (default 24)
//
// Macros opcionais (iguais ao original):
//  NRV_IS_IO_ADDR(addr)  1 se addr esta no espaco de IO (wait states)
//  NRV_COUNTER_WIDTH     largura do contador de ciclos (default 32)
//  NRV_TWOLEVEL_SHIFTER  shifter de 2 niveis (4 bits/ciclo)
/*******************************************************************/

`define NRV_ARCH     "rv32i"
`define NRV_ABI      "ilp32"
`define NRV_OPTIMIZE "-Os"

module femtorv32_quark (                 // [ASIC-1]
   input         clk,

   output [31:0] mem_addr,  // address bus
   output [31:0] mem_wdata, // data to be written
   output [3:0]  mem_wmask, // write mask for the 4 bytes of each word
   input  [31:0] mem_rdata, // input lines for both data and instr
   output        mem_rstrb, // active to initiate memory read (used by IO)
   input         mem_rbusy, // asserted if memory is busy reading value
   input         mem_wbusy, // asserted if memory is busy writing value

   input         reset      // set to 0 to reset the processor
);

   parameter RESET_ADDR = 32'h00000000;
   parameter ADDR_WIDTH = 24;

   /***************************************************************************/
   // [ASIC-2] Declaracoes de estado (antes no meio/fim do arquivo)
   /***************************************************************************/

   localparam FETCH_INSTR_bit     = 0;
   localparam WAIT_INSTR_bit      = 1;
   localparam EXECUTE_bit         = 2;
   localparam WAIT_ALU_OR_MEM_bit = 3;
   localparam NB_STATES           = 4;

   localparam FETCH_INSTR     = 1 << FETCH_INSTR_bit;
   localparam WAIT_INSTR      = 1 << WAIT_INSTR_bit;
   localparam EXECUTE         = 1 << EXECUTE_bit;
   localparam WAIT_ALU_OR_MEM = 1 << WAIT_ALU_OR_MEM_bit;

   (* onehot *)
   reg [NB_STATES-1:0]  state;

   reg [ADDR_WIDTH-1:0] PC;     // The program counter.
   reg [31:2]           instr;  // Latched instruction (bits 0,1 ignored).

   reg [31:0] rs1;
   reg [31:0] rs2;

   (* no_rw_check *)
   reg [31:0] registerFile [31:0];

`ifdef NRV_COUNTER_WIDTH
   reg [`NRV_COUNTER_WIDTH-1:0] cycles;
`else
   reg [31:0]                   cycles;
`endif

   reg  [31:0] aluReg;    // The internal register of the ALU, used by shift.
   reg  [4:0]  aluShamt;  // Current shift amount.

   /***************************************************************************/
   // Instruction decoding.
   /***************************************************************************/

   wire [4:0] rdId = instr[11:7];

   (* onehot *)
   wire [7:0] funct3Is = 8'b00000001 << instr[14:12];

   wire [31:0] Uimm = {    instr[31],   instr[30:12], {12{1'b0}}};
   wire [31:0] Iimm = {{21{instr[31]}}, instr[30:20]};
   /* verilator lint_off UNUSED */
   wire [31:0] Simm = {{21{instr[31]}}, instr[30:25],instr[11:7]};
   wire [31:0] Bimm = {{20{instr[31]}}, instr[7],instr[30:25],instr[11:8],1'b0};
   wire [31:0] Jimm = {{12{instr[31]}}, instr[19:12],instr[20],instr[30:21],1'b0};
   /* verilator lint_on UNUSED */

   wire isLoad    =  (instr[6:2] == 5'b00000); // rd <- mem[rs1+Iimm]
   wire isALUimm  =  (instr[6:2] == 5'b00100); // rd <- rs1 OP Iimm
   wire isStore   =  (instr[6:2] == 5'b01000); // mem[rs1+Simm] <- rs2
   wire isALUreg  =  (instr[6:2] == 5'b01100); // rd <- rs1 OP rs2
   wire isSYSTEM  =  (instr[6:2] == 5'b11100); // rd <- cycles
   wire isJAL     =  instr[3];                 // rd <- PC+4; PC<-PC+Jimm
   wire isJALR    =  (instr[6:2] == 5'b11001); // rd <- PC+4; PC<-rs1+Iimm
   wire isLUI     =  (instr[6:2] == 5'b01101); // rd <- Uimm
   wire isAUIPC   =  (instr[6:2] == 5'b00101); // rd <- PC + Uimm
   wire isBranch  =  (instr[6:2] == 5'b11000); // if(rs1 OP rs2) PC<-PC+Bimm

   wire isALU = isALUimm | isALUreg;

   /***************************************************************************/
   // The ALU. Does operations and tests combinatorially, except shifts.
   /***************************************************************************/

   wire [31:0] aluIn1 = rs1;
   wire [31:0] aluIn2 = isALUreg | isBranch ? rs2 : Iimm;

   wire aluBusy = |aluShamt;
   wire aluWr;

   wire [31:0] aluPlus  = aluIn1 + aluIn2;
   wire [32:0] aluMinus = {1'b1, ~aluIn2} + {1'b0,aluIn1} + 33'b1;
   wire        LT  = (aluIn1[31] ^ aluIn2[31]) ? aluIn1[31] : aluMinus[32];
   wire        LTU = aluMinus[32];
   wire        EQ  = (aluMinus[31:0] == 0);

   wire funct3IsShift = funct3Is[1] | funct3Is[5];   // [ASIC-2] subiu

   wire [31:0] aluOut =
     (funct3Is[0]  ? instr[30] & instr[5] ? aluMinus[31:0] : aluPlus : 32'b0) |
     (funct3Is[2]  ? {31'b0, LT}                                     : 32'b0) |
     (funct3Is[3]  ? {31'b0, LTU}                                    : 32'b0) |
     (funct3Is[4]  ? aluIn1 ^ aluIn2                                 : 32'b0) |
     (funct3Is[6]  ? aluIn1 | aluIn2                                 : 32'b0) |
     (funct3Is[7]  ? aluIn1 & aluIn2                                 : 32'b0) |
     (funct3IsShift ? aluReg                                         : 32'b0) ;

   always @(posedge clk) begin
      if (!reset) begin                                   // [ASIC-3]
         aluReg   <= 32'b0;
         aluShamt <= 5'b0;
      end else if(aluWr) begin
         if (funct3IsShift) begin  // SLL, SRA, SRL
            aluReg   <= aluIn1;
            aluShamt <= aluIn2[4:0];
         end
      end
`ifdef NRV_TWOLEVEL_SHIFTER
      else if(|aluShamt[4:2]) begin // Shift by 4
         aluShamt <= aluShamt - 4;
         aluReg <= funct3Is[1] ? aluReg << 4 :
                   {{4{instr[30] & aluReg[31]}}, aluReg[31:4]};
      end
`endif
      // funct3=001              -> SLL  (aluReg <= aluReg << 1)
      // funct3=101 &  instr[30] -> SRA  (aluReg <= {aluReg[31], aluReg[31:1]})
      // funct3=101 & !instr[30] -> SRL  (aluReg <= {1'b0,       aluReg[31:1]})
      else if (|aluShamt) begin
         aluShamt <= aluShamt - 1;
         aluReg <= funct3Is[1] ? aluReg << 1 :              // SLL
                   {instr[30] & aluReg[31], aluReg[31:1]};  // SRA,SRL
      end
   end

   /***************************************************************************/
   // The predicate for conditional branches.
   /***************************************************************************/

   wire predicate =
        funct3Is[0] &  EQ  | // BEQ
        funct3Is[1] & !EQ  | // BNE
        funct3Is[4] &  LT  | // BLT
        funct3Is[5] & !LT  | // BGE
        funct3Is[6] &  LTU | // BLTU
        funct3Is[7] & !LTU ; // BGEU

   /***************************************************************************/
   // Program counter and branch target computation.
   /***************************************************************************/

   wire [ADDR_WIDTH-1:0] PCplus4 = PC + 4;

   wire [ADDR_WIDTH-1:0] PCplusImm = PC + ( instr[3] ? Jimm[ADDR_WIDTH-1:0] :
                                            instr[4] ? Uimm[ADDR_WIDTH-1:0] :
                                                       Bimm[ADDR_WIDTH-1:0] );

   wire [ADDR_WIDTH-1:0] loadstore_addr = rs1[ADDR_WIDTH-1:0] +
                   (instr[5] ? Simm[ADDR_WIDTH-1:0] : Iimm[ADDR_WIDTH-1:0]);

   /* verilator lint_off WIDTH */
   assign mem_addr = state[WAIT_INSTR_bit] | state[FETCH_INSTR_bit] ?
                     PC : loadstore_addr ;
   /* verilator lint_on WIDTH */

   /***************************************************************************/
   // LOAD/STORE
   /***************************************************************************/

   wire mem_byteAccess     = instr[13:12] == 2'b00;
   wire mem_halfwordAccess = instr[13:12] == 2'b01;

   // [ASIC-2] LOAD_halfword/LOAD_byte declarados antes de LOAD_sign/LOAD_data
   wire [15:0] LOAD_halfword =
               loadstore_addr[1] ? mem_rdata[31:16] : mem_rdata[15:0];

   wire  [7:0] LOAD_byte =
               loadstore_addr[0] ? LOAD_halfword[15:8] : LOAD_halfword[7:0];

   wire LOAD_sign =
        !instr[14] & (mem_byteAccess ? LOAD_byte[7] : LOAD_halfword[15]);

   wire [31:0] LOAD_data =
         mem_byteAccess ? {{24{LOAD_sign}},     LOAD_byte} :
     mem_halfwordAccess ? {{16{LOAD_sign}}, LOAD_halfword} :
                          mem_rdata ;

   assign mem_wdata[ 7: 0] = rs2[7:0];
   assign mem_wdata[15: 8] = loadstore_addr[0] ? rs2[7:0]  : rs2[15: 8];
   assign mem_wdata[23:16] = loadstore_addr[1] ? rs2[7:0]  : rs2[23:16];
   assign mem_wdata[31:24] = loadstore_addr[0] ? rs2[7:0]  :
                             loadstore_addr[1] ? rs2[15:8] : rs2[31:24];

   wire [3:0] STORE_wmask =
              mem_byteAccess      ?
                    (loadstore_addr[1] ?
                          (loadstore_addr[0] ? 4'b1000 : 4'b0100) :
                          (loadstore_addr[0] ? 4'b0010 : 4'b0001)
                    ) :
              mem_halfwordAccess ?
                    (loadstore_addr[1] ? 4'b1100 : 4'b0011) :
              4'b1111;

   /***************************************************************************/
   // The value written back to the register file.
   /***************************************************************************/

   /* verilator lint_off WIDTH */
   wire [31:0] writeBackData  =
      (isSYSTEM            ? cycles     : 32'b0) |  // SYSTEM
      (isLUI               ? Uimm       : 32'b0) |  // LUI
      (isALU               ? aluOut     : 32'b0) |  // ALUreg, ALUimm
      (isAUIPC             ? PCplusImm  : 32'b0) |  // AUIPC
      (isJALR   | isJAL    ? PCplus4    : 32'b0) |  // JAL, JALR
      (isLoad              ? LOAD_data  : 32'b0) ;  // Load
   /* verilator lint_on WIDTH */

   /***************************************************************************/
   // The register file.
   /***************************************************************************/

   wire writeBack = ~(isBranch | isStore ) &
                    (state[EXECUTE_bit] | state[WAIT_ALU_OR_MEM_bit]);

   always @(posedge clk) begin
     if (writeBack)
       if (rdId != 0)
         registerFile[rdId] <= writeBackData;
   end

   // [ASIC-4] x0 lido sempre como zero
   wire [4:0]  rs1Id_next = mem_rdata[19:15];
   wire [4:0]  rs2Id_next = mem_rdata[24:20];
   wire [31:0] rs1_next   = (rs1Id_next == 5'd0) ? 32'b0 : registerFile[rs1Id_next];
   wire [31:0] rs2_next   = (rs2Id_next == 5'd0) ? 32'b0 : registerFile[rs2Id_next];

   /*************************************************************************/
   // The state machine.
   /*************************************************************************/

   assign mem_rstrb = state[EXECUTE_bit] & isLoad | state[FETCH_INSTR_bit];
   assign mem_wmask = {4{state[EXECUTE_bit] & isStore}} & STORE_wmask;
   assign aluWr     = state[EXECUTE_bit] & isALU;

   wire jumpToPCplusImm = isJAL | (isBranch & predicate);
`ifdef NRV_IS_IO_ADDR
   wire needToWait = isLoad |
                     isStore  & `NRV_IS_IO_ADDR(mem_addr) |
                     isALU & funct3IsShift;
`else
   wire needToWait = isLoad | isStore | isALU & funct3IsShift;
`endif

   always @(posedge clk) begin
      if(!reset) begin
         state <= WAIT_ALU_OR_MEM; // Just waiting for !mem_wbusy
         PC    <= RESET_ADDR[ADDR_WIDTH-1:0];
         instr <= 30'b0;                                  // [ASIC-3]
      end else

      (* parallel_case *)
      case(1'b1)

        state[WAIT_INSTR_bit]: begin
           if(!mem_rbusy) begin
              rs1   <= rs1_next;                          // [ASIC-4]
              rs2   <= rs2_next;                          // [ASIC-4]
              instr <= mem_rdata[31:2];
              state <= EXECUTE;
           end
        end

        state[EXECUTE_bit]: begin
           PC <= isJALR          ? {aluPlus[ADDR_WIDTH-1:1],1'b0} :
                 jumpToPCplusImm ? PCplusImm :
                 PCplus4;
           state <= needToWait ? WAIT_ALU_OR_MEM : FETCH_INSTR;
        end

        state[WAIT_ALU_OR_MEM_bit]: begin
           if(!aluBusy & !mem_rbusy & !mem_wbusy) state <= FETCH_INSTR;
        end

        default: begin // FETCH_INSTR
          state <= WAIT_INSTR;
        end

      endcase
   end

   /***************************************************************************/
   // Cycle counter
   /***************************************************************************/

   always @(posedge clk) begin
      if (!reset) cycles <= 0;                            // [ASIC-3]
      else        cycles <= cycles + 1;
   end

endmodule
