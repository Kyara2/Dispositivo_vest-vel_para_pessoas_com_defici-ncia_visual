// ============================================================================
// fusion_node: wires fusion_gain -> fusion_channel + fusion_variance,
// matching the paper's overall architecture (Fig. 4: gain feeds BOTH the
// position-estimate module (eq. 9) and the variance module (eq. 10)).
//
// Interface is "fire and wait", inherited from fusion_gain: the whole node
// is bottlenecked by the gain divider (the only non-pipelined stage), so
// there is no benefit to accepting a new request before the current one
// finishes -- assert in_valid for one cycle, `busy` stays high, `out_valid`
// pulses once with k / q_hat / sigma_new_sq all valid TOGETHER on the same
// cycle (fusion_channel has one more pipeline stage than fusion_variance,
// so the variance path is delayed by exactly 1 cycle here to line them up
// -- matching how the paper describes gain/position/variance emerging
// together, not as three separately-timed results).
//
// q1, q2, sigma1_sq, sigma2_sq are LATCHED the moment in_valid is accepted,
// so the caller only needs to hold them stable for one cycle, not for the
// whole ~(FRAC+2)+3 cycle computation.
// ============================================================================
module fusion_node #(
    parameter W    = 16,
    parameter FRAC = 15
)(
    input  wire          clk,
    input  wire          rst_n,
    input  wire          in_valid,
    input  wire [W-1:0]  q1,          // ultrasonic measurement, mm
    input  wire [W-1:0]  q2,          // infrared measurement, mm
    input  wire [W-1:0]  sigma1_sq,   // sigma_us^2, mm^2
    input  wire [W-1:0]  sigma2_sq,   // sigma_ir^2, mm^2
    output wire           busy,
    output reg            out_valid,
    output reg  [W-1:0]  k,            // UQ1.15 gain actually used this round
    output reg  [W-1:0]  q_hat,        // fused estimate, mm
    output reg  [W-1:0]  sigma_new_sq  // updated variance, mm^2
);
    // ---- latch the inputs that must survive the gain computation --------
    reg [W-1:0] q1_l, q2_l, sigma1_sq_l;
    always @(posedge clk) begin
        if (!rst_n) begin
            q1_l <= {W{1'b0}};
            q2_l <= {W{1'b0}};
            sigma1_sq_l <= {W{1'b0}};
        end else if (in_valid && !busy) begin
            q1_l        <= q1;
            q2_l        <= q2;
            sigma1_sq_l <= sigma1_sq;
        end
    end

    // ---- busy: high from the accepted in_valid until the aligned output --
    reg busy_r;
    always @(posedge clk) begin
        if (!rst_n)              busy_r <= 1'b0;
        else if (in_valid && !busy_r) busy_r <= 1'b1;
        else if (out_valid)      busy_r <= 1'b0;
    end
    assign busy = busy_r;

    // ---- gain: K = sigma1_sq/(sigma1_sq+sigma2_sq), eq. 11 ---------------
    wire             gain_busy, gain_valid;
    wire [W-1:0]     gain_k;
    fusion_gain #(.W(W), .FRAC(FRAC)) u_gain (
        .clk(clk), .rst_n(rst_n),
        .in_valid(in_valid && !busy_r),
        .sigma1_sq(sigma1_sq), .sigma2_sq(sigma2_sq),
        .busy(gain_busy), .out_valid(gain_valid), .k(gain_k)
    );

    // hold k steady from the moment the gain finishes until the aligned
    // output fires -- safe because only one computation is ever in flight
    // (busy blocks a new in_valid until this one's out_valid has fired).
    reg [W-1:0] k_hold;
    always @(posedge clk) begin
        if (gain_valid) k_hold <= gain_k;
    end

    // ---- position estimate: q_hat = q1 + K*(q2-q1), eq. 7/9 --------------
    wire             ch_valid;
    wire [W-1:0]     ch_qhat;
    fusion_channel #(.W(W), .FRAC(FRAC)) u_channel (
        .clk(clk), .rst_n(rst_n), .in_valid(gain_valid),
        .q1(q1_l), .q2(q2_l), .k(gain_k),
        .out_valid(ch_valid), .q_hat(ch_qhat)
    );

    // ---- variance update: sigma_new_sq = sigma1_sq - K*sigma1_sq, eq. 10 -
    wire             var_valid_raw;
    wire [W-1:0]     var_sigma_raw;
    fusion_variance #(.W(W), .FRAC(FRAC)) u_variance (
        .clk(clk), .rst_n(rst_n), .in_valid(gain_valid),
        .sigma1_sq(sigma1_sq_l), .k(gain_k),
        .out_valid(var_valid_raw), .sigma_new_sq(var_sigma_raw)
    );

    // fusion_channel (3-stage) has one more register than fusion_variance
    // (2-stage) -- delay the variance result by exactly 1 cycle so both
    // land on the SAME out_valid pulse as fusion_channel's.
    reg             var_valid_d;
    reg [W-1:0]     var_sigma_d;
    always @(posedge clk) begin
        var_valid_d <= var_valid_raw;
        var_sigma_d <= var_sigma_raw;
    end

    // ---- final aligned output ---------------------------------------------
    always @(posedge clk) begin
        if (!rst_n) begin
            out_valid    <= 1'b0;
            k             <= {W{1'b0}};
            q_hat        <= {W{1'b0}};
            sigma_new_sq <= {W{1'b0}};
        end else begin
            out_valid <= ch_valid;
            if (ch_valid) begin
                k            <= k_hold;
                q_hat        <= ch_qhat;
                sigma_new_sq <= var_sigma_d;
            end
        end
    end
endmodule
