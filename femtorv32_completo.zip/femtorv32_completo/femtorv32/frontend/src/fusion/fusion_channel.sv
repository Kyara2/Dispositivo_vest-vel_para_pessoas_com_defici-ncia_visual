// ============================================================================
// fusion_channel: q_hat = q1 + K*(q2 - q1)   (paper eq. 7 / KF form eq. 9)
// K = sigma1^2/(sigma1^2+sigma2^2), precomputed offline, unsigned Q1.15 (32768 = 1.0)
//
// q1, q2, q_hat : PLAIN INTEGERS in mm -- zero fractional bits, on purpose.
//   The measurement itself only ever has whole-mm resolution (that's what the
//   sensor + its linearization stage hand us), so giving these ports extra
//   fractional bits would just be padding zeros: no real precision to carry.
//   q1 = prior/first source, q2 = second source -- same notation as the
//   paper, independent of which physical sensor feeds which input (here
//   q1 = ultrasonic, q2 = infrared, but the module itself doesn't know that).
//
// BUT the CALCULATION in between is not whole-mm the whole way through, and
// that is deliberate, not an oversight:
//   diff = q2 - q1            -- still a whole number of mm (subtraction of
//                                 two integers can't invent fractional mm)
//   prod = diff * k            -- K is a FRACTION (Q1.15), so this product is
//                                 inherently fractional mm, carried as a raw
//                                 integer scaled by 2^FRAC. Concretely:
//                                 prod_2 / 2^FRAC == diff * K_real, in mm,
//                                 decimal point and all (e.g. 746.25 mm).
//                                 There is no way to multiply an integer mm
//                                 count by a fractional gain and get a whole
//                                 number back WITHOUT either throwing away
//                                 bits early or carrying them through --
//                                 prod_2 is deliberately wide enough (2W+2
//                                 bits) to carry them through.
//   rnd  = round(prod/2^FRAC)  -- the ONLY place the design rounds back down
//                                 to whole mm. Doing this once, at the very
//                                 end, bounds the rounding error to <=0.5 mm
//                                 total. Rounding q1/q2 themselves to
//                                 fractional mm earlier, or rounding diff*K
//                                 in more than one step, would only add more
//                                 0.5 mm error terms for no benefit -- the
//                                 input never had fractional information to
//                                 preserve in the first place.
//   q_hat = q1 + rnd            -- back to a plain integer mm count, same
//                                 representation as q1/q2/the sensor input.
//
// So: "use decimal mm in the calculation" -- yes, but only where a fraction
// is mathematically unavoidable (the diff*K product), and only internally;
// the ports stay whole-mm integers because that's the true resolution of
// the data on both ends. If the sensors ever gained sub-mm resolution, only
// q1/q2 (and the final saturation widths) would need to grow fractional
// bits -- K's Q1.15 format and the single-round-at-the-end structure
// wouldn't need to change at all.
//
// Latency 3 cycles, throughput 1 result/cycle.
// ============================================================================
module fusion_channel #(
    parameter W    = 16,
    parameter FRAC = 15
)(
    input  wire           clk,
    input  wire           rst_n,
    input  wire           in_valid,
    input  wire [W-1:0]   q1,        // first measurement, whole mm
    input  wire [W-1:0]   q2,        // second measurement, whole mm
    input  wire [W-1:0]   k,         // UQ1.15 gain (the only fractional quantity in)
    output reg            out_valid,
    output reg  [W-1:0]   q_hat      // fused estimate, whole mm (rounded once, see below)
);
    // ---- stage 1: difference -------------------------------------------
    // Still whole mm: subtracting two integers can't produce a fraction.
    reg                   v1;
    reg  [W-1:0]          q1_1, k_1;
    reg  signed [W:0]     innovation_1;    // q2 - q1, whole mm
    always @(posedge clk) begin
        if (!rst_n) v1 <= 1'b0;
        else        v1 <= in_valid;
        q1_1   <= q1;
        k_1    <= k;
        innovation_1 <= $signed({1'b0, q2}) - $signed({1'b0, q1});
    end

    // ---- stage 2: multiply by K ------------------------------------------
    // Here is where fractional mm enters the picture: innovation_1 (whole
    // mm) times k (a Q1.15 FRACTION) is a product whose true value is
    // "diff * K_real" mm, essentially never a whole number. prod_2 is kept
    // at full width (2W+2 bits) specifically so none of that fractional-mm
    // information is lost before stage 3 rounds it back down once.
    reg                   v2;
    reg  [W-1:0]          q1_2;
    reg  signed [2*W+1:0] prod_2;          // = innovation_1 * K_real * 2^FRAC
    wire signed [W:0]     k_1s = {1'b0, k_1};
    always @(posedge clk) begin
        if (!rst_n) v2 <= 1'b0;
        else        v2 <= v1;
        q1_2   <= q1_1;
        prod_2 <= innovation_1 * k_1s;
    end

    // ---- stage 3: round (the ONE place that leaves decimal mm behind),
    //               add q1, saturate -------------------------------------
    localparam signed [2*W+1:0] HALF = (1 <<< (FRAC-1));
    wire signed [2*W+1:0] rnd  = (prod_2 + HALF) >>> FRAC;   // rounds to nearest whole mm
    wire signed [2*W+1:0] sum  = $signed({{(W+2){1'b0}}, q1_2}) + rnd;
    wire signed [2*W+1:0] maxv = $signed({{(W+2){1'b0}}, {W{1'b1}}});
    always @(posedge clk) begin
        if (!rst_n) out_valid <= 1'b0;
        else        out_valid <= v2;
        if (sum[2*W+1])      q_hat <= {W{1'b0}};       // negative -> 0
        else if (sum > maxv) q_hat <= {W{1'b1}};       // overflow -> max
        else                 q_hat <= sum[W-1:0];
    end
endmodule