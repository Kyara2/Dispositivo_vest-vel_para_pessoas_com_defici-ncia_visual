// ============================================================================
// fusion_variance: sigma_new_sq = sigma1_sq - K*sigma1_sq   (paper eq. 10)
// Pipelined, latency 2 cycles, throughput 1 result/cycle -- same streaming
// style as fusion_channel. Meant to run alongside fusion_channel on the
// same (sigma1_sq, k) pair each sample: fusion_channel updates the fused
// estimate, this module updates the uncertainty that goes with it.
//
// sigma1_sq, sigma_new_sq : PLAIN INTEGERS, mm^2 -- same "no fractional
//   bits on the measurement side" convention as q1/q2 in fusion_channel.
// k : UQ1.15 gain (32768 = 1.0) -- the SAME k value and format
//   fusion_channel consumes; typically driven by fusion_gain's output.
//
// K is only ever <= 1.0 by its definition (eq. 11: a convex weight), so
// K*sigma1_sq <= sigma1_sq and sigma_new_sq should never need to saturate
// in normal operation -- the clamp-to-0 below exists only as a defensive
// backstop for an out-of-contract K > 1.0 fed in directly (same philosophy
// as fusion_channel's saturation logic).
// ============================================================================
module fusion_variance #(
    parameter W    = 16,
    parameter FRAC = 15
)(
    input  wire           clk,
    input  wire           rst_n,
    input  wire           in_valid,
    input  wire [W-1:0]   sigma1_sq,     // sigma1^2, mm^2, plain integer
    input  wire [W-1:0]   k,             // UQ1.15 gain (same k fusion_channel uses)
    output reg             out_valid,
    output reg  [W-1:0]   sigma_new_sq   // updated variance, mm^2
);
    // ---- stage 1: multiply sigma1_sq by K --------------------------------
    // Same reasoning as fusion_channel stage 2: sigma1_sq (plain integer) times
    // k (a Q1.15 FRACTION) is inherently fractional mm^2, carried at full
    // width (2W bits, no information lost) until stage 2 rounds it once.
    reg                 v1;
    reg  [W-1:0]        sigma1_sq_1;
    reg  [2*W-1:0]      prod_1;          // = sigma1_sq * K_real * 2^FRAC
    always @(posedge clk) begin
        if (!rst_n) v1 <= 1'b0;
        else        v1 <= in_valid;
        sigma1_sq_1 <= sigma1_sq;
        prod_1 <= sigma1_sq * k;          // unsigned x unsigned, both plain magnitudes
    end

    // ---- stage 2: round (half-up, the one place that leaves decimal
    //               mm^2 behind), subtract, saturate at 0 -----------------
    localparam [2*W-1:0] HALF = (1 <<< (FRAC-1));
    wire [2*W-1:0]       rnd  = (prod_1 + HALF) >> FRAC;            // round(K*sigma1_sq)
    wire signed [2*W:0]  diff = $signed({{(W+1){1'b0}}, sigma1_sq_1}) -
                                 $signed({1'b0, rnd});
    wire signed [2*W:0]  maxv = $signed({{(W+1){1'b0}}, {W{1'b1}}});
    always @(posedge clk) begin
        if (!rst_n) out_valid <= 1'b0;
        else        out_valid <= v1;
        if (diff[2*W])          sigma_new_sq <= {W{1'b0}};   // negative (K>1, out of contract) -> 0
        else if (diff > maxv)   sigma_new_sq <= {W{1'b1}};   // overflow -> max (defensive, shouldn't occur)
        else                    sigma_new_sq <= diff[W-1:0];
    end
endmodule
