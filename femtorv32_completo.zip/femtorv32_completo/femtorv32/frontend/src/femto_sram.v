//=============================================================================
// femto_sram.v -- RAM do FemtoRV32 feita com MACROS de SRAM (caixa-preta)
// Author: Kyara Esteves de Sousa
//
// A memoria NAO e' sintetizada a partir de portas: cada banco e' uma
// instancia da macro sram_32x1024_freepdk45 (4 KB, 1 porta RW, mascara de
// byte), gerada pelo compilador de memoria OpenRAM. O Genus enxerga a macro
// so' pelo .lib (timing/area/potencia) e o Innovus pelo .lef; o .v
// comportamental serve so' para simulacao. Ver tech/sram/README.md.
//
// Este arquivo e' a "casca" sintetizavel em volta das macros: decodifica o
// banco, gera chip-select/write-enable ativos em baixo e escolhe a saida do
// banco certo. Total = BANKS x 4 KB (default 2 -> 8 KB).
//
// Interface: a mesma da FemtoRV32 (mem_addr/wdata/wmask/rstrb/rdata/rbusy/
// wbusy), mais "sel" (a decodificacao de endereco do SoC diz se o acesso e'
// desta RAM). Na proxima etapa este bloco vira escravo AXI4.
//
// Temporizacao da macro OpenRAM: registra as entradas na borda de SUBIDA e
// faz o acesso na borda de DESCIDA. O dado lido aparece no meio do ciclo
// seguinte ao rstrb e fica valido ate a proxima subida -- exatamente a
// latencia de 1 ciclo que o Quark espera (le mem_rdata no ciclo apos o
// rstrb). Por isso rbusy/wbusy sao sempre 0 e nao ha nenhum registrador de
// dado aqui. Consequencia para o STA: o caminho dout0 -> registradores do
// processador tem MEIO periodo (lancado na descida, capturado na subida).
//=============================================================================

`timescale 1ns / 1ps

module femto_sram #(
    parameter BANKS       = 2,               // numero de macros de 4 KB (1, 2, 4 ou 8)
    parameter FPGA        = 0,               // 1 = BSRAM da FPGA com firmware (ver fpga/)
    parameter INIT_PREFIX = "soc_fw"         // FPGA: arquivos <prefixo>_b<n>.hex
)(
    input  wire        clk,
    input  wire        sel,                  // acesso pertence a esta RAM
    input  wire [31:0] mem_addr,             // endereco de BYTE
    input  wire [31:0] mem_wdata,
    input  wire [3:0]  mem_wmask,
    input  wire        mem_rstrb,
    output wire [31:0] mem_rdata,
    output wire        mem_rbusy,
    output wire        mem_wbusy
);

    localparam WORD_BITS = 10;               // 1024 palavras por macro
    localparam BANK_BITS = (BANKS > 1) ? $clog2(BANKS) : 1;

    wire        wr   = sel & (|mem_wmask);
    wire        rd   = sel & mem_rstrb;
    wire [WORD_BITS-1:0] word = mem_addr[WORD_BITS+1:2];

    // banco endereçado (bits acima dos 4 KB)
    wire [BANK_BITS-1:0] bank = (BANKS > 1) ? mem_addr[WORD_BITS+2 +: BANK_BITS] : 1'b0;

    // banco da ULTIMA leitura -- escolhe o mux de saida no ciclo seguinte
    reg  [BANK_BITS-1:0] rd_bank_q;
    always @(posedge clk)
        if (rd) rd_bank_q <= bank;

    wire [31:0] dout [0:BANKS-1];

    genvar b;
    generate
        for (b = 0; b < BANKS; b = b + 1) begin : g_bank
            wire hit = (bank == b);
            if (FPGA != 0) begin : g_fpga
                // FPGA: modelo sintetizavel (BSRAM) com o firmware pre-carregado
                // (fpga/sram_32x1024_fpga.v), um .hex por banco. No ASIC
                // (FPGA=0) so' o ramo de baixo e' elaborado: a macro.
                sram_32x1024_freepdk45 #(.INIT_FILE(
                    (b == 0) ? {INIT_PREFIX, "_b0.hex"} : (b == 1) ? {INIT_PREFIX, "_b1.hex"} :
                    (b == 2) ? {INIT_PREFIX, "_b2.hex"} : (b == 3) ? {INIT_PREFIX, "_b3.hex"} :
                    (b == 4) ? {INIT_PREFIX, "_b4.hex"} : (b == 5) ? {INIT_PREFIX, "_b5.hex"} :
                    (b == 6) ? {INIT_PREFIX, "_b6.hex"} : {INIT_PREFIX, "_b7.hex"})) u_sram (
                    .clk0(clk), .csb0(~((rd | wr) & hit)), .web0(~wr), .wmask0(mem_wmask),
                    .addr0(word), .din0(mem_wdata), .dout0(dout[b]));
            end else begin : g_asic
            sram_32x1024_freepdk45 u_sram (
                .clk0   (clk),
                .csb0   (~((rd | wr) & hit)),    // chip select, ativo baixo
                .web0   (~wr),                    // write enable, ativo baixo
                .wmask0 (mem_wmask),
                .addr0  (word),
                .din0   (mem_wdata),
                .dout0  (dout[b])
            );
            end
        end
    endgenerate

    assign mem_rdata = dout[rd_bank_q];
    assign mem_rbusy = 1'b0;
    assign mem_wbusy = 1'b0;

endmodule
