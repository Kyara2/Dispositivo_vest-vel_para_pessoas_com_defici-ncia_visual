// femtorv32_sram_tb.sv -- integracao: FemtoRV32 Quark executando a partir
// da femto_sram (macros OpenRAM), SEM modelo de memoria no testbench.
// Author: Kyara Esteves de Sousa
//
// Prova que a memoria funciona com o protocolo real do processador antes de
// partir para o SoC com AXI4. O programa (+PROGRAM, default c_suite_8k.hex,
// 2048 palavras) e' pre-carregado direto no array de cada macro (modelo
// comportamental). O testbench so' cuida do espaco de IO (bit 22):
//   0x400000 TOHOST, 0x400004 CONSOLE, 0x400008 SIGNATURE -- mesma convencao
//   do femtorv32_quark_tb.
//
// So' RTL (os dois DUTs sao RTL + modelo da macro).
// Plusargs: +PROGRAM=<hex> +CLK_NS=<real> +MAX_CYCLES=<n>

`timescale 1ns/1ps

module femtorv32_sram_tb;

    localparam int BANKS = 2;
    localparam int WORDS = BANKS * 1024;
    localparam int RAM_BYTES = WORDS * 4;

    logic clk = 0, reset = 0;
    wire  [31:0] mem_addr, mem_wdata, ram_rdata;
    wire  [3:0]  mem_wmask;
    wire         mem_rstrb, ram_rbusy, ram_wbusy;

    // decodificacao de endereco (o que o SoC vai fazer de verdade)
    wire is_io  = mem_addr[22];
    wire is_ram = !is_io && (mem_addr < RAM_BYTES);

    // a leitura de IO devolve 0; o mux de saida usa o alvo da ultima leitura
    logic rd_io_q = 0;
    always @(posedge clk) if (mem_rstrb) rd_io_q <= is_io;
    wire [31:0] mem_rdata = rd_io_q ? 32'h0 : ram_rdata;

    femtorv32_quark cpu (
        .clk(clk), .mem_addr(mem_addr), .mem_wdata(mem_wdata), .mem_wmask(mem_wmask),
        .mem_rdata(mem_rdata), .mem_rstrb(mem_rstrb), .mem_rbusy(ram_rbusy),
        .mem_wbusy(ram_wbusy), .reset(reset));

    femto_sram #(.BANKS(BANKS)) ram (
        .clk(clk), .sel(is_ram), .mem_addr(mem_addr), .mem_wdata(mem_wdata),
        .mem_wmask(mem_wmask), .mem_rstrb(mem_rstrb), .mem_rdata(ram_rdata),
        .mem_rbusy(ram_rbusy), .mem_wbusy(ram_wbusy));

    // ------------------------------------------------------------ preload
    logic [31:0] image [0:WORDS-1];
    string program_file = "c_suite_8k.hex";
    real   clk_ns = 10.0;
    int    max_cycles = 3000000;

    genvar gb;
    generate
        for (gb = 0; gb < BANKS; gb++) begin : g_load
            initial begin
                #0.001;   // depois do $readmemh abaixo
                for (int i = 0; i < 1024; i++)
                    ram.g_bank[gb].g_asic.u_sram.mem[i] = image[gb*1024 + i];
            end
        end
    endgenerate

    initial begin
        void'($value$plusargs("PROGRAM=%s", program_file));
        void'($value$plusargs("CLK_NS=%f", clk_ns));
        void'($value$plusargs("MAX_CYCLES=%d", max_cycles));
        for (int i = 0; i < WORDS; i++) image[i] = 32'h0;
        $readmemh(program_file, image);
        $display("==============================================================");
        $display("[tb] FemtoRV32 Quark + femto_sram (%0d x macro OpenRAM 4 KB)", BANKS);
        $display("[tb] programa: %s   clock: %0.3f ns", program_file, clk_ns);
        $display("==============================================================");
        fork forever #(clk_ns/2.0) clk = ~clk; join_none
        repeat (10) @(posedge clk);
        reset <= #0.3 1'b1;
    end

    // ------------------------------------------------------------ IO + checagens
    int errors = 0;
    bit done = 0, bol = 1;
    logic [31:0] tohost = 0;
    longint cycle = 0;

    always @(posedge clk) if (reset) begin
        cycle++;
        if ((mem_rstrb === 1'b1 || |mem_wmask) && !is_io && !is_ram) begin
            errors++;
            if (errors < 10) $display("[tb] ERRO @%0t: acesso fora da RAM/IO addr=%h", $time, mem_addr);
        end
        if (mem_rstrb === 1'b1 && is_ram && cycle > 3 && $isunknown(mem_addr)) begin
            errors++;
            if (errors < 10) $display("[tb] ERRO @%0t: endereco com X", $time);
        end
        if (|mem_wmask && is_io) begin
            case (mem_addr[3:2])
                2'd0: begin tohost = mem_wdata; done = 1; end
                2'd1: begin
                    if (bol) $write("[console] ");
                    $write("%c", mem_wdata[7:0]);
                    bol = (mem_wdata[7:0] == 8'h0A);
                end
                2'd2: $display("[signature] 0x%08h", mem_wdata);
                default: ;
            endcase
        end
        if (done || cycle >= max_cycles) begin
            if (!bol) $write("\n");
            $display("==============================================================");
            $display("[tb] ciclos: %0d", cycle);
            if (!done)                           $display("RESULT: FAIL -- TIMEOUT");
            else if (tohost === 1 && errors == 0) $display("RESULT: PASS");
            else $display("RESULT: FAIL -- TOHOST=0x%08h (teste %0d), %0d erro(s)", tohost, tohost >> 1, errors);
            $display("==============================================================");
            $finish;
        end
    end

endmodule
