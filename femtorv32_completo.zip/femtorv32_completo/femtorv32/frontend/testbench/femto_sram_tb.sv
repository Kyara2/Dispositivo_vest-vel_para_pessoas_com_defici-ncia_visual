// femto_sram_tb.sv -- testbench funcional da RAM do FemtoRV32
// Author: Kyara Esteves de Sousa
//
// Testa o femto_sram (macros OpenRAM) -- ou, com `define FF_RAM, o
// femto_ram_ff (flip-flops) -- usando o MESMO protocolo do FemtoRV32:
// leitura = mem_rstrb com endereco, dado lido amostrado na borda de subida
// seguinte; escrita = mem_wmask != 0 com endereco/dado no mesmo ciclo.
//
// Fases:
//   1. preenche a memoria toda com palavras (wmask=1111) e le tudo de volta
//   2. todas as mascaras de byte/meia-palavra em enderecos variados
//   3. acessos com sel=0 (NAO podem escrever)
//   4. trafego aleatorio: leituras/escritas/ociosos misturados, inclusive
//      leitura logo apos escrita no mesmo endereco e acessos consecutivos
//      (mais agressivo que o Quark, que nunca faz dois acessos seguidos)
// Tudo e' comparado com um modelo de referencia (array no testbench).
//
// Plusargs: +CLK_NS=<real> (default 10)  +SEED=<n>  +N_RANDOM=<n> (default 20000)
// Defines : POST_SYNTH (netlist do Genus), SDF_FILE="..." (com POST_SYNTH)

`timescale 1ns/1ps

`ifdef FF_RAM
module femto_ram_ff_tb;
    localparam int WORDS = 256;
`else
module femto_sram_tb;
    localparam int BANKS = 2;
    localparam int WORDS = BANKS * 1024;
`endif

    localparam real IO_DLY = 0.3;   // entradas mudam 0.3 ns apos a subida (= in_delay do SDC)

    logic        clk = 0;
    logic        sel = 0;
    logic [31:0] mem_addr = 0;
    logic [31:0] mem_wdata = 0;
    logic [3:0]  mem_wmask = 0;
    logic        mem_rstrb = 0;
    wire  [31:0] mem_rdata;
    wire         mem_rbusy, mem_wbusy;

`ifdef FF_RAM
  `ifdef POST_SYNTH
    femto_ram_ff dut (
  `else
    femto_ram_ff #(.WORDS(WORDS)) dut (
  `endif
`else
  `ifdef POST_SYNTH
    femto_sram dut (
  `else
    femto_sram #(.BANKS(BANKS)) dut (
  `endif
`endif
        .clk(clk), .sel(sel), .mem_addr(mem_addr), .mem_wdata(mem_wdata),
        .mem_wmask(mem_wmask), .mem_rstrb(mem_rstrb), .mem_rdata(mem_rdata),
        .mem_rbusy(mem_rbusy), .mem_wbusy(mem_wbusy));

`ifdef POST_SYNTH
`ifdef SDF_FILE
    initial begin
        $display("[tb] anotando SDF: %s", `SDF_FILE);
        $sdf_annotate(`SDF_FILE, dut, , "sdf_annotate.log", "MAXIMUM");
    end
`endif
`endif

    real clk_ns = 10.0;
    int  seed = 1, seed_tmp, n_random = 20000;
    int  errors = 0, n_rd = 0, n_wr = 0, n_chk = 0;
    int  n_mask[16];

    logic [31:0] ref_mem [0:WORDS-1];

    // Leitura pendente. Igual ao Quark: rstrb no ciclo N, a RAM captura na
    // subida que fecha N, o dado vale durante N+1 e e' amostrado na subida
    // que fecha N+1. Por isso a conferencia anda 2 subidas atras da emissao.
    bit          pend = 0,   pend_q = 0;
    logic [31:0] pend_exp,   pend_exp_q;
    int unsigned pend_word,  pend_word_q;

    initial begin
        void'($value$plusargs("CLK_NS=%f", clk_ns));
        void'($value$plusargs("SEED=%d", seed));
        void'($value$plusargs("N_RANDOM=%d", n_random));
        seed_tmp = seed; void'($urandom(seed_tmp));
        fork forever #(clk_ns/2.0) clk = ~clk; join_none
    end

    function automatic logic [31:0] merge(input logic [31:0] old, input logic [31:0] d, input logic [3:0] m);
        for (int b = 0; b < 4; b++) if (m[b]) old[8*b +: 8] = d[8*b +: 8];
        return old;
    endfunction

    // Um ciclo de barramento. Na subida: confere a leitura pendente (dado
    // do ciclo anterior) e depois aplica a operacao nova (+IO_DLY).
    task automatic cycle(input bit s, input bit rd, input logic [3:0] wm,
                         input int unsigned w, input logic [31:0] d);
        @(posedge clk);
        if (pend_q) begin
            n_chk++;
            if (mem_rdata !== pend_exp_q) begin
                errors++;
                if (errors <= 10)
                    $display("[tb] ERRO @%0t: palavra %0d lida 0x%08h, esperado 0x%08h", $time, pend_word_q, mem_rdata, pend_exp_q);
            end
        end
        pend_q = pend; pend_exp_q = pend_exp; pend_word_q = pend_word;
        pend = 0;
        if (mem_rbusy !== 1'b0 || mem_wbusy !== 1'b0) begin
            errors++;
            if (errors <= 10) $display("[tb] ERRO @%0t: rbusy/wbusy deveriam ser 0", $time);
        end
        #(IO_DLY);
        sel       = s;
        mem_addr  = {w[29:0], 2'b00};
        if (rd && wm == 4'b0)                  // leitura: bits [1:0] sao offset de byte
            mem_addr[1:0] = $urandom_range(0, 3); // e devem ser ignorados pela RAM
        mem_rstrb = rd;
        mem_wmask = wm;
        mem_wdata = d;
        if (s && rd && wm == 4'b0) begin
            pend = 1; pend_word = w; pend_exp = ref_mem[w]; n_rd++;
        end
        if (s && wm != 0) begin
            ref_mem[w] = merge(ref_mem[w], d, wm); n_wr++; n_mask[wm]++;
        end
    endtask

    task automatic idle();
        cycle(0, 0, 4'b0000, 0, 32'h0);
    endtask

    // Escrita no formato do Quark: dado replicado nas faixas de byte certas
    function automatic logic [31:0] lane(input logic [31:0] v, input logic [3:0] m);
        case (m)
            4'b0001, 4'b0010, 4'b0100, 4'b1000: return {4{v[7:0]}};
            4'b0011, 4'b1100:                   return {2{v[15:0]}};
            default:                            return v;
        endcase
    endfunction

    function automatic logic [3:0] MASKS(input int i);   // as 7 mascaras que o Quark gera
        case (i)
            0: return 4'b0001;  1: return 4'b0010;  2: return 4'b0100;  3: return 4'b1000;
            4: return 4'b0011;  5: return 4'b1100;  default: return 4'b1111;
        endcase
    endfunction

    initial begin
        int unsigned w;
        logic [31:0] d;
        logic [3:0]  m;
        int r;

        for (int i = 0; i < WORDS; i++) ref_mem[i] = 32'h0;
        repeat (3) @(posedge clk);

        $display("==============================================================");
`ifdef FF_RAM
        $display("[tb] DUT: femto_ram_ff (flip-flops), %0d palavras", WORDS);
`else
        $display("[tb] DUT: femto_sram (macros OpenRAM), %0d bancos x 1024 palavras", BANKS);
`endif
`ifdef POST_SYNTH
        $display("[tb] modo: POST-SYNTHESIS (netlist)");
`else
        $display("[tb] modo: RTL");
`endif
        $display("[tb] clock %0.3f ns, seed %0d, %0d acessos aleatorios", clk_ns, seed, n_random);
        $display("==============================================================");

        // ---- fase 1: preenche e le tudo
        for (int i = 0; i < WORDS; i++) cycle(1, 0, 4'b1111, i, 32'hA5000000 ^ (i * 32'h01010101) ^ (i << 7));
        for (int i = 0; i < WORDS; i++) begin cycle(1, 1, 4'b0000, i, 32'h0); end
        idle();
        $display("[tb] fase 1 (preenche/le %0d palavras): %0d erro(s)", WORDS, errors);

        // ---- fase 2: todas as mascaras, padrao do Quark (escreve, ocioso, le, ocioso)
        for (int k = 0; k < 7; k++)
            for (int j = 0; j < 16; j++) begin
                w = (j * 131 + k * 17) % WORDS;
                d = $urandom();
                cycle(1, 0, MASKS(k), w, lane(d, MASKS(k)));
                idle();
                cycle(1, 1, 4'b0000, w, 32'h0);
                idle();
            end
        $display("[tb] fase 2 (mascaras de byte/meia-palavra): %0d erro(s)", errors);

        // ---- fase 3: sel=0 nao pode escrever (o modelo de referencia nao muda)
        for (int j = 0; j < 64; j++) cycle(0, 0, 4'b1111, $urandom_range(0, WORDS-1), 32'hDEADDEAD);
        for (int j = 0; j < 64; j++) cycle(1, 1, 4'b0000, j * (WORDS / 64), 32'h0);
        idle();
        $display("[tb] fase 3 (sel=0 ignora escritas): %0d erro(s)", errors);

        // ---- fase 4: aleatorio, com rajadas e leitura-apos-escrita
        for (int j = 0; j < n_random; j++) begin
            r = $urandom_range(0, 99);
            w = $urandom_range(0, WORDS-1);
            if (r < 40) begin
                cycle(1, 1, 4'b0000, w, 32'h0);
            end else if (r < 75) begin
                m = MASKS($urandom_range(0, 6));
                cycle(1, 0, m, w, lane($urandom(), m));
            end else if (r < 85) begin
                m = MASKS($urandom_range(0, 6));
                cycle(1, 0, m, w, lane($urandom(), m));
                cycle(1, 1, 4'b0000, w, 32'h0);          // le logo em seguida
            end else if (r < 90) begin
                cycle(0, $urandom_range(0,1), MASKS($urandom_range(0,6)), w, $urandom());
            end else begin
                idle();
            end
        end
        idle(); idle();
        $display("[tb] fase 4 (aleatorio): %0d erro(s)", errors);

        $display("==============================================================");
        $display("[tb] leituras conferidas: %0d   escritas: %0d", n_chk, n_wr);
        $display("[tb] escritas por mascara: 0001=%0d 0010=%0d 0100=%0d 1000=%0d 0011=%0d 1100=%0d 1111=%0d",
                 n_mask[1], n_mask[2], n_mask[4], n_mask[8], n_mask[3], n_mask[12], n_mask[15]);
        if (errors == 0) $display("RESULT: PASS");
        else             $display("RESULT: FAIL -- %0d erro(s)", errors);
        $display("==============================================================");
        $finish;
    end

    initial begin
        #(100.0 * 1000.0 * 1000.0);
        $display("RESULT: FAIL -- TIMEOUT");
        $finish;
    end

endmodule
