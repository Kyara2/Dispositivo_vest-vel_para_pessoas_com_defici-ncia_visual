// femto_ram_ff_tb.sv -- mesmo testbench do femto_sram, apontado para a
// versao em flip-flops (femto_ram_ff). Precisa de -incdir frontend/testbench.
`define FF_RAM
`include "femto_sram_tb.sv"
