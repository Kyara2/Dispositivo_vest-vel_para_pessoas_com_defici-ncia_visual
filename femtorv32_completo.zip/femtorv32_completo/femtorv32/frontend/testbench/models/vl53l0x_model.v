// vl53l0x_model.v -- modelo comportamental (SIMULACAO) do VL53L0X como
// escravo I2C, suficiente para o driver do firmware inicializar e medir.
// Author: Kyara Esteves de Sousa
//
// - endereco 7 bits 0x29, ponteiro de registrador com auto-incremento;
// - 256 registradores de 8 bits, com os valores que o driver confere:
//     0xC0 = 0xEE (ID do modelo), 0x13 = 0x07 (amostra sempre pronta),
//     0x83 com bit 4 sempre lido como 1 (handshake do getSpadInfo),
//     0x92 = info de SPADs, 0x50/0x70/0x46/0x51-52/0x71-72 = tempos padrao;
// - 0x1E/0x1F (RESULT_RANGE_STATUS+10) devolvem range_mm[idx]; cada escrita
//   em 0x0B (SYSTEM_INTERRUPT_CLEAR) depois de uma leitura de distancia
//   avanca para a proxima distancia da lista.
// Nao modela fisica nem calibracao: so' o protocolo/registradores.
`timescale 1ns/1ps

module vl53l0x_model #(
    parameter [6:0] ADDR = 7'h29
)(
    inout wire scl,
    inout wire sda
);
    reg drive_low = 1'b0;
    assign sda = drive_low ? 1'b0 : 1'bz;

    wire scl_in = (scl !== 1'b0);
    wire sda_in = (sda !== 1'b0);

    reg [7:0]  regs [0:255];
    reg [15:0] range_list [0:15];
    integer    range_idx = 0;
    integer    n_writes = 0, n_reads = 0;
    reg        range_was_read = 0;

    integer i;
    initial begin
        for (i = 0; i < 256; i = i + 1) regs[i] = 8'h00;
        regs[8'hC0] = 8'hEE;
        regs[8'h91] = 8'h3C;
        regs[8'h92] = 8'h05;      // 5 SPADs, tipo "nao-abertura"
        regs[8'h84] = 8'h11;
        regs[8'h50] = 8'h06;      // pre-range VCSEL  -> 14 pclks
        regs[8'h70] = 8'h04;      // final-range VCSEL -> 10 pclks
        regs[8'h46] = 8'h05;
        regs[8'h51] = 8'h00; regs[8'h52] = 8'h66;
        regs[8'h71] = 8'h01; regs[8'h72] = 8'hAE;
        for (i = 176; i <= 181; i = i + 1) regs[i] = 8'hFF;
        for (i = 0; i < 16; i = i + 1) range_list[i] = 16'd500;
    end

    function [7:0] read_reg(input [7:0] a);
        begin
            case (a)
                8'h13:   read_reg = 8'h07;
                8'h83:   read_reg = regs[a] | 8'h10;
                8'h1E:   begin read_reg = range_list[range_idx % 16][15:8]; range_was_read = 1; end
                8'h1F:   begin read_reg = range_list[range_idx % 16][7:0];  range_was_read = 1; end
                default: read_reg = regs[a];
            endcase
            n_reads = n_reads + 1;
        end
    endfunction

    task write_reg(input [7:0] a, input [7:0] v);
        begin
            regs[a] = v;
            n_writes = n_writes + 1;
            if (a == 8'h0B && range_was_read) begin
                range_idx = range_idx + 1;
                range_was_read = 0;
            end
        end
    endtask

    // ---------------- protocolo I2C
    // mode: 0 ocioso, 1 recebendo endereco, 2 recebendo dados (escrita), 3 transmitindo (leitura)
    integer   mode = 0;
    integer   bitpos = 0;
    reg [7:0] sh = 0, txb = 0, ptr = 0;
    reg       rw = 0, first = 0, mack = 0;

    always @(negedge sda) if (scl_in) begin            // START / START repetido
        mode = 1; bitpos = -1; drive_low = 1'b0;
    end
    always @(posedge sda) if (scl_in) begin            // STOP
        mode = 0; drive_low = 1'b0;
    end

    always @(posedge scl) begin
        if ((mode == 1 || mode == 2) && bitpos >= 0 && bitpos < 8) sh = {sh[6:0], sda_in};
        if (mode == 3 && bitpos == 8) mack = !sda_in;  // 0 = ACK do mestre
    end

    always @(negedge scl) begin
        if (mode == 0) begin
            drive_low = 1'b0;
        end else if (bitpos < 7) begin
            bitpos = bitpos + 1;
            if (mode == 3 && bitpos >= 0) drive_low = ~txb[7 - bitpos];
        end else if (bitpos == 7) begin
            bitpos = 8;
            if (mode == 1) begin
                if (sh[7:1] == ADDR) begin drive_low = 1'b1; rw = sh[0]; end
                else begin mode = 0; drive_low = 1'b0; end
            end else if (mode == 2) begin
                drive_low = 1'b1;                          // ACK
                if (first) begin ptr = sh; first = 0; end
                else begin write_reg(ptr, sh); ptr = ptr + 1; end
            end else if (mode == 3) begin
                drive_low = 1'b0;                          // solta para o ACK do mestre
            end
        end else begin                                     // fim do bit de ACK
            bitpos = 0;
            if (mode == 1) begin
                if (rw) begin mode = 3; txb = read_reg(ptr); ptr = ptr + 1; drive_low = ~txb[7]; end
                else    begin mode = 2; first = 1; drive_low = 1'b0; end
            end else if (mode == 2) begin
                drive_low = 1'b0;
            end else if (mode == 3) begin
                if (mack) begin txb = read_reg(ptr); ptr = ptr + 1; drive_low = ~txb[7]; end
                else      begin mode = 0; drive_low = 1'b0; end
            end
        end
    end
endmodule
