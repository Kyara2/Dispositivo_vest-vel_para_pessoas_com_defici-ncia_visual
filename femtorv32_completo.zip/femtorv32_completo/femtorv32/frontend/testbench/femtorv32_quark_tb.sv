// femtorv32_quark_tb.sv -- testbench funcional (sem UVM) do FemtoRV32 Quark
// Author: Kyara Esteves de Sousa
//
// Usado tanto na simulacao RTL (pre-synthesis) quanto na simulacao da
// netlist do Genus (post-synthesis, com +define+POST_SYNTH e SDF).
//
// O que o testbench faz:
//   - modela uma RAM de 64 KB com a mesma interface/temporizacao da
//     FemtoSoC original (leitura registrada 1 ciclo apos mem_rstrb, escrita
//     com mascara de bytes), carregada com um programa .hex ($readmemh);
//   - opcionalmente injeta wait states aleatorios em mem_rbusy/mem_wbusy
//     (+WAITSTATES=1), para exercitar o handshake da FSM do Quark;
//   - decodifica o espaco de IO (bit 22 do endereco):
//       0x400000 TOHOST    1 = PASS, (n<<1)|1 = FAIL no teste n
//       0x400004 CONSOLE   putchar -> impresso no log com prefixo [console]
//       0x400008 SIGNATURE valor impresso no log com prefixo [signature]
//   - checa o protocolo (nenhuma transacao nova com rbusy/wbusy altos),
//     X/Z nas saidas do processador apos o reset (importante na
//     simulacao gate-level), acessos fora da RAM, e timeout;
//   - imprime "RESULT: PASS" / "RESULT: FAIL" (o run.sh faz grep disso).
//
// Plusargs:
//   +PROGRAM=<arquivo.hex>  programa a carregar (obrigatorio)
//   +CLK_NS=<real>          periodo do clock em ns (default 10)
//   +WAITSTATES=<0|1>       wait states aleatorios (default 0)
//   +SEED=<int>             semente do $urandom (default 1)
//   +MAX_CYCLES=<int>       timeout em ciclos (default 5000000)
//   +TRACE                  (so' RTL) imprime PC/instrucao a cada EXECUTE
//
// Defines:
//   POST_SYNTH              simulacao da netlist (desliga sondas internas)
//   SDF_FILE="<arq.sdf>"    com POST_SYNTH, anota atrasos via $sdf_annotate

`timescale 1ns/1ps

module femtorv32_quark_tb;

    // ------------------------------------------------------------------
    // Parametros do "sistema"
    // ------------------------------------------------------------------
    localparam int  RAM_WORDS   = 16384;            // 64 KB
    localparam int  RAM_AW      = 14;               // log2(RAM_WORDS)
    localparam logic [31:0] IO_TOHOST    = 32'h0040_0000;
    localparam logic [31:0] IO_CONSOLE   = 32'h0040_0004;
    localparam logic [31:0] IO_SIGNATURE = 32'h0040_0008;

    // Atraso das entradas do DUT apos a borda de clock (equivale ao
    // in_delay do SDC). Evita corrida com o clock na simulacao gate-level.
    localparam real IO_DLY = 0.3;

    // ------------------------------------------------------------------
    // Sinais
    // ------------------------------------------------------------------
    logic        clk   = 1'b0;
    logic        reset = 1'b0;        // ativo BAIXO (0 = em reset), como no original
    wire  [31:0] mem_addr;
    wire  [31:0] mem_wdata;
    wire  [3:0]  mem_wmask;
    wire         mem_rstrb;
    logic [31:0] mem_rdata = 32'h0;
    logic        mem_rbusy = 1'b0;
    logic        mem_wbusy = 1'b0;

    // ------------------------------------------------------------------
    // DUT
    // ------------------------------------------------------------------
    femtorv32_quark dut (
        .clk       (clk),
        .mem_addr  (mem_addr),
        .mem_wdata (mem_wdata),
        .mem_wmask (mem_wmask),
        .mem_rdata (mem_rdata),
        .mem_rstrb (mem_rstrb),
        .mem_rbusy (mem_rbusy),
        .mem_wbusy (mem_wbusy),
        .reset     (reset)
    );

`ifdef POST_SYNTH
`ifdef SDF_FILE
    initial begin
        $display("[tb] anotando SDF: %s", `SDF_FILE);
        $sdf_annotate(`SDF_FILE, dut, , "sdf_annotate.log", "MAXIMUM");
    end
`endif
`endif

    // ------------------------------------------------------------------
    // Configuracao via plusargs
    // ------------------------------------------------------------------
    string  program_file;
    real    clk_ns     = 10.0;
    int     waitstates = 0;
    int     seed       = 1;
    int     seed_tmp;
    int     max_cycles = 5000000;
    bit     trace      = 0;

    logic [31:0] RAM [0:RAM_WORDS-1];

    initial begin
        if (!$value$plusargs("PROGRAM=%s", program_file)) begin
            $display("RESULT: FAIL -- falta +PROGRAM=<arquivo.hex>");
            $finish;
        end
        void'($value$plusargs("CLK_NS=%f",     clk_ns));
        void'($value$plusargs("WAITSTATES=%d", waitstates));
        void'($value$plusargs("SEED=%d",       seed));
        void'($value$plusargs("MAX_CYCLES=%d", max_cycles));
        trace = $test$plusargs("TRACE");

        for (int i = 0; i < RAM_WORDS; i++) RAM[i] = 32'h0;
        $readmemh(program_file, RAM);

        $display("==============================================================");
        $display("[tb] FemtoRV32 Quark -- testbench funcional");
`ifdef POST_SYNTH
        $display("[tb] modo        : POST-SYNTHESIS (netlist)");
`else
        $display("[tb] modo        : RTL (pre-synthesis)");
`endif
        $display("[tb] programa    : %s", program_file);
        $display("[tb] clock       : %0.3f ns", clk_ns);
        $display("[tb] wait states : %0s (seed %0d)", waitstates ? "aleatorios" : "nao", seed);
        $display("[tb] RAM[0..1]   : %h %h", RAM[0], RAM[1]);
        $display("==============================================================");
        seed_tmp = seed;
        void'($urandom(seed_tmp));         // semeia o gerador do testbench
        if (^RAM[0] === 1'bx) begin
            $display("RESULT: FAIL -- nao consegui ler o programa %s", program_file);
            $finish;
        end

        fork
            forever #(clk_ns / 2.0) clk = ~clk;
        join_none

        repeat (10) @(posedge clk);
        reset <= #(IO_DLY) 1'b1;
    end

    // ------------------------------------------------------------------
    // Modelo de memoria + IO
    // ------------------------------------------------------------------
    function automatic bit is_io (input logic [31:0] a);
        return a[22];
    endfunction

    function automatic bit in_ram (input logic [31:0] a);
        return (a[31:2] < RAM_WORDS);
    endfunction

    logic [RAM_AW-1:0] rd_word_q;
    logic [31:0]       rd_addr_q;
    int                rcnt = 0;
    int                wcnt = 0;

    function automatic logic [31:0] mem_read (input logic [31:0] a);
        if (is_io(a))       return 32'h0;
        else if (in_ram(a)) return RAM[a[RAM_AW+1:2]];
        else                return 32'hDEAD_BEEF;
    endfunction

    // resultado / estatisticas
    int     errors       = 0;
    bit     done         = 0;
    logic [31:0] tohost_val = 32'h0;
    longint cycle        = 0;
    longint cycles_at_reset_release = 0;
    longint instr_count  = 0;
    bit     console_bol  = 1;     // proximo char comeca uma linha nova

    always @(posedge clk) begin
        int lat;
        if (!reset) begin
            rcnt      =  0;
            wcnt      =  0;
            mem_rbusy <= #(IO_DLY) 1'b0;
            mem_wbusy <= #(IO_DLY) 1'b0;
        end else begin
            // -------------------------- checagens de X/Z nas saidas
            if ($isunknown(mem_rstrb) || $isunknown(mem_wmask)) begin
                errors++;
                if (errors < 10)
                    $display("[tb] ERRO @%0t: X/Z em mem_rstrb=%b mem_wmask=%b", $time, mem_rstrb, mem_wmask);
            end
            if ((mem_rstrb === 1'b1 || |mem_wmask) && $isunknown(mem_addr)) begin
                errors++;
                if (errors < 10) $display("[tb] ERRO @%0t: X/Z em mem_addr=%h", $time, mem_addr);
            end

            // -------------------------- protocolo: nenhuma transacao nova
            // enquanto a memoria sinaliza ocupada (mem_wbusy/mem_rbusy aqui
            // e' o valor que o DUT enxergou durante o ciclo que terminou)
            if (mem_wbusy === 1'b1 && (mem_rstrb === 1'b1 || |mem_wmask)) begin
                errors++;
                if (errors < 10) $display("[tb] ERRO @%0t: nova transacao (rstrb=%b wmask=%b) com mem_wbusy=1", $time, mem_rstrb, mem_wmask);
            end
            if (mem_rbusy === 1'b1 && (mem_rstrb === 1'b1 || |mem_wmask)) begin
                errors++;
                if (errors < 10) $display("[tb] ERRO @%0t: nova transacao (rstrb=%b wmask=%b) com mem_rbusy=1", $time, mem_rstrb, mem_wmask);
            end

            // -------------------------- leitura
            if (mem_rstrb === 1'b1) begin
                if (!is_io(mem_addr) && !in_ram(mem_addr)) begin
                    errors++;
                    if (errors < 10) $display("[tb] ERRO @%0t: leitura fora da RAM, addr=%h", $time, mem_addr);
                end
                rd_addr_q = mem_addr;
                lat = waitstates ? $urandom_range(0, 3) : 0;
                if (lat == 0) begin
                    mem_rdata <= #(IO_DLY) mem_read(mem_addr);
                    mem_rbusy <= #(IO_DLY) 1'b0;
                    rcnt = 0;
                end else begin
                    mem_rdata <= #(IO_DLY) 32'hxxxx_xxxx;   // dado invalido enquanto ocupado
                    mem_rbusy <= #(IO_DLY) 1'b1;
                    rcnt = lat;
                end
            end else if (rcnt != 0) begin
                rcnt--;
                if (rcnt == 0) begin
                    mem_rdata <= #(IO_DLY) mem_read(rd_addr_q);
                    mem_rbusy <= #(IO_DLY) 1'b0;
                end
            end

            // -------------------------- escrita
            if (|mem_wmask) begin
                if ($isunknown(mem_wdata)) begin
                    for (int b = 0; b < 4; b++)
                        if (mem_wmask[b] && $isunknown(mem_wdata[8*b +: 8])) begin
                            errors++;
                            if (errors < 10) $display("[tb] ERRO @%0t: X/Z em mem_wdata=%h (wmask=%b)", $time, mem_wdata, mem_wmask);
                        end
                end
                if (is_io(mem_addr)) begin
                    case ({mem_addr[31:2], 2'b00})
                        IO_TOHOST: begin
                            tohost_val = mem_wdata;
                            done = 1;
                        end
                        IO_CONSOLE: begin
                            if (console_bol) $write("[console] ");
                            $write("%c", mem_wdata[7:0]);
                            console_bol = (mem_wdata[7:0] == 8'h0A);
                        end
                        IO_SIGNATURE: $display("[signature] 0x%08h", mem_wdata);
                        default: begin
                            errors++;
                            $display("[tb] ERRO @%0t: escrita em IO desconhecido addr=%h", $time, mem_addr);
                        end
                    endcase
                end else if (in_ram(mem_addr)) begin
                    for (int b = 0; b < 4; b++)
                        if (mem_wmask[b]) RAM[mem_addr[RAM_AW+1:2]][8*b +: 8] = mem_wdata[8*b +: 8];
                end else begin
                    errors++;
                    if (errors < 10) $display("[tb] ERRO @%0t: escrita fora da RAM, addr=%h", $time, mem_addr);
                end

                lat = waitstates ? $urandom_range(0, 3) : 0;
                wcnt = lat;
                mem_wbusy <= #(IO_DLY) (lat != 0);
            end else if (wcnt != 0) begin
                wcnt--;
                if (wcnt == 0) mem_wbusy <= #(IO_DLY) 1'b0;
            end
        end
    end

    // ------------------------------------------------------------------
    // Contadores, trace (so' RTL) e fim de teste
    // ------------------------------------------------------------------
    always @(posedge clk) begin
        cycle++;
        if (!reset) cycles_at_reset_release = cycle;
`ifndef POST_SYNTH
        if (reset && dut.state[dut.EXECUTE_bit]) begin
            instr_count++;
            if (trace)
                $display("[trace] %0d PC=%06h instr=%08h", cycle, dut.PC, {dut.instr, 2'b11});
        end
`endif
    end

    initial begin
        longint run_cycles;
        wait (reset === 1'b1);
        fork
            wait (done);
            begin
                @(posedge clk);
                while (cycle - cycles_at_reset_release < max_cycles) @(posedge clk);
            end
        join_any
        disable fork;
        repeat (2) @(posedge clk);
        run_cycles = cycle - cycles_at_reset_release;

        if (!console_bol) $write("\n");
        $display("==============================================================");
        $display("[tb] programa : %s", program_file);
        $display("[tb] ciclos   : %0d", run_cycles);
`ifndef POST_SYNTH
        $display("[tb] instrucoes executadas: %0d   CPI medio: %0.2f",
                 instr_count, instr_count ? real'(run_cycles) / real'(instr_count) : 0.0);
`endif
        if (!done) begin
            $display("RESULT: FAIL -- TIMEOUT apos %0d ciclos (programa nunca escreveu no TOHOST)", max_cycles);
        end else if (tohost_val === 32'd1 && errors == 0) begin
            $display("RESULT: PASS");
        end else if (tohost_val === 32'd1) begin
            $display("RESULT: FAIL -- programa reportou PASS, mas o testbench viu %0d erro(s) de protocolo/X", errors);
        end else if (tohost_val[0] === 1'b1) begin
            $display("RESULT: FAIL -- programa reportou falha no teste %0d (TOHOST=0x%08h), %0d erro(s) de protocolo",
                     tohost_val >> 1, tohost_val, errors);
        end else begin
            $display("RESULT: FAIL -- valor inesperado no TOHOST: 0x%08h", tohost_val);
        end
        $display("==============================================================");
        $finish;
    end

endmodule
