// femto_soc_tb.sv -- testbench de sistema do femto_soc
// Author: Kyara Esteves de Sousa
//
// Roda o firmware real (soc_fw.hex) no SoC completo:
//   - RAM: as 4 macros sao pre-carregadas com o programa (modelo da macro);
//   - HC-SR04: modelo que responde ao trigger com um echo de largura
//     proporcional a' distancia da lista us_mm[] (5,8 us por mm);
//   - VL53L0X: modelo I2C (models/vl53l0x_model.v) com a lista tof_mm[];
//   - UART: decodifica o TX e imprime cada linha no log com [uart].
// O firmware, com SYSINFO.SIM=1, faz o autoteste HW x SW + 4 rodadas de
// sensores e termina imprimindo "RESULT: PASS" ou "RESULT: FAIL" na UART.
// O testbench repete isso e confere tambem as distancias lidas.
//
// Modos:
//   RTL (padrao): parametros acelerados (UART_DIV=8, trigger a cada 5 ms) e
//     preload das macros por nome hierarquico.
//   POS-SINTESE (+define+POST_SYNTH, ./exe.sh post): o DUT e' a netlist do
//     Genus, sem parametros (UART 115200, trigger a cada 60 ms, como no chip).
//     O preload e' feito pelo proprio modelo da macro (+SRAM_PRELOAD=<prefixo>,
//     cada macro le <prefixo>_b<N>.hex), porque os nomes mudam na netlist.
//     O firmware e' o soc_fw_post (forca o modo simulacao: 4 rodadas e RESULT).
//     Com +define+DFT a netlist tem as portas de scan: SE=0 (modo funcional).
//     Com +define+SDF_FILE=... anota os atrasos do Genus.
// Com +define+TB_FPGA_RAM usa a RAM da FPGA (fpga/sram_32x1024_fpga.v), que
// carrega sozinha os soc_fw_b*.hex da pasta atual -- valida a configuracao
// que vai para a Tang Primer 20K.
// Plusargs: +PROGRAM=<soc_fw.hex>  +MAX_MS=<tempo maximo simulado, ms>

`timescale 1ns/1ps

module femto_soc_tb;
    localparam int  CLK_HZ   = 27_000_000;
    localparam real CLK_NS   = 1.0e9 / CLK_HZ;
`ifdef POST_SYNTH
    localparam int  UART_DIV = CLK_HZ / 115200;   // netlist: divisor sintetizado (234)
`else
    localparam int  UART_DIV = 8;                 // UART acelerada na simulacao
`endif
    localparam int  BANKS    = 4;

    logic clk = 0, rst_n = 0;
    wire  uart_tx, us_trig;
    logic us_echo = 0;
    wire  scl_oe, sda_oe;
    wire  [3:0] leds;
    tri1  scl, sda;                               // pull-ups do barramento I2C

    assign scl = scl_oe ? 1'b0 : 1'bz;
    assign sda = sda_oe ? 1'b0 : 1'bz;

`ifdef POST_SYNTH
    femto_soc dut (
        .clk(clk), .rst_n(rst_n), .uart_tx(uart_tx),
        .us_trig(us_trig), .us_echo(us_echo),
        .i2c_scl_i(scl), .i2c_scl_oe(scl_oe), .i2c_sda_i(sda), .i2c_sda_oe(sda_oe),
`ifdef DFT
        .SE(1'b0), .dft_sdi_1(1'b0), .dft_sdo_1(),      // scan desligado: modo funcional
`endif
        .leds(leds));
`ifdef SDF_FILE
    initial begin
        $display("[tb] anotando SDF: %s", `SDF_FILE);
        $sdf_annotate(`SDF_FILE, dut, , "sdf_annotate.log", "MAXIMUM");
    end
`endif
`else
    femto_soc #(
        .CLK_HZ(CLK_HZ), .SIM(1), .RAM_BANKS(BANKS),
        .UART_DIV(UART_DIV),
        .US_PERIOD(CLK_HZ / 1000 * 5),            // trigger a cada 5 ms (60 ms no hardware real)
        .US_TIMEOUT(CLK_HZ / 1000 * 4)
`ifdef TB_FPGA_RAM
        , .FPGA(1), .INIT_PREFIX("soc_fw")      // RAM da FPGA: carrega soc_fw_b*.hex sozinha
`endif
    ) dut (
        .clk(clk), .rst_n(rst_n), .uart_tx(uart_tx),
        .us_trig(us_trig), .us_echo(us_echo),
        .i2c_scl_i(scl), .i2c_scl_oe(scl_oe), .i2c_sda_i(sda), .i2c_sda_oe(sda_oe),
        .leds(leds));
`endif

    vl53l0x_model u_vl (.scl(scl), .sda(sda));

    always #(CLK_NS / 2.0) clk = ~clk;

    // ------------------------------------------------------------ distancias
    // distancias (mm) que os modelos devolvem, em sequencia
    function automatic int us_mm(input int i);
        case (i % 8) 0: return 523; 1: return 610; 2: return 342; 3: return 455;
                     4: return 600; 5: return 380; 6: return 500; default: return 333; endcase
    endfunction
    function automatic int tof_mm(input int i);
        case (i % 8) 0: return 517; 1: return 602; 2: return 351; 3: return 449;
                     4: return 611; 5: return 372; 6: return 498; default: return 340; endcase
    endfunction
    int us_idx = 0;

    initial begin
        #0.002;
        for (int i = 0; i < 16; i++) u_vl.range_list[i] = tof_mm(i);
    end

    // HC-SR04: ~100 us apos o trigger, echo alto por dist*5,8 us
    always @(negedge us_trig) begin
        if (!us_echo) begin
            int d;
            d = us_mm(us_idx);
            us_idx++;
            #(100_000);
            us_echo = 1'b1;
            #(d * 5800);
            us_echo = 1'b0;
        end
    end

    // ------------------------------------------------------------ preload da RAM
    logic [31:0] image [0:BANKS*1024-1];
    string program_file = "soc_fw.hex";
    int    max_ms = 200;

`ifndef TB_FPGA_RAM
`ifndef POST_SYNTH
    genvar gb;
    generate
        for (gb = 0; gb < BANKS; gb++) begin : g_load
            initial begin
                #0.001;
                for (int i = 0; i < 1024; i++)
                    dut.u_ram.u_ram.g_bank[gb].g_asic.u_sram.mem[i] = image[gb*1024 + i];
            end
        end
    endgenerate
`endif
`endif

    initial begin
        void'($value$plusargs("PROGRAM=%s", program_file));
        void'($value$plusargs("MAX_MS=%d", max_ms));
        for (int i = 0; i < BANKS*1024; i++) image[i] = 32'h0;
`ifndef POST_SYNTH
        $readmemh(program_file, image);              // pos-sintese: cada macro carrega o seu banco
`endif
        $display("==============================================================");
        $display("[tb] femto_soc: Quark + AXI4-Lite + fusion_node + HC-SR04 + VL53L0X + UART");
`ifdef POST_SYNTH
        $display("[tb] modo: POS-SINTESE (netlist do Genus%s)",
`ifdef DFT
                 " com DFT, SE=0"
`else
                 ""
`endif
                 );
        $display("[tb] RAM: cada macro carrega <SRAM_PRELOAD>_b<N>.hex   clock %0d MHz", CLK_HZ/1000000);
`else
        $display("[tb] programa: %s   clock %0d MHz   RAM %0d KB", program_file, CLK_HZ/1000000, BANKS*4);
`endif
        $display("==============================================================");
        repeat (20) @(posedge clk);
        rst_n <= #1 1'b1;
    end

    // ------------------------------------------------------------ UART RX
    logic [8*12-1:0] last12 = '0;
    bit   bol = 1, pass_seen = 0, fail_seen = 0;
    int   n_chars = 0;

    initial begin
        logic [7:0] ch;
        forever begin
            @(negedge uart_tx);
            if (rst_n === 1'b1) begin
                repeat (UART_DIV / 2) @(posedge clk);          // meio do start bit
                if (uart_tx === 1'b0) begin
                    for (int b = 0; b < 8; b++) begin
                        repeat (UART_DIV) @(posedge clk);
                        ch[b] = uart_tx;
                    end
                    repeat (UART_DIV) @(posedge clk);          // stop bit
                    n_chars++;
                    if (ch != 8'h0D) begin
                        if (bol && ch != 8'h0A) $write("[uart] ");
                        $write("%c", ch);
                        bol = (ch == 8'h0A);
                        last12 = {last12[8*11-1:0], ch};
                        if (last12 == "RESULT: PASS") pass_seen = 1;
                        if (last12 == "RESULT: FAIL") fail_seen = 1;
                    end
                end
            end
        end
    end

    // ------------------------------------------------------------ fim
    initial begin
        fork
            wait (pass_seen || fail_seen);
            #(longint'(max_ms) * 1_000_000);
        join_any
        repeat (5000) @(posedge clk);        // o firmware ainda manda "\r\n" e escreve TOHOST
        $display("");
        $display("==============================================================");
        $display("[tb] caracteres na UART: %0d   ecos HC-SR04 gerados: %0d   leituras I2C de registrador: %0d",
                 n_chars, us_idx, u_vl.n_reads);
`ifdef POST_SYNTH
        if (pass_seen)                              $display("RESULT: PASS");   // TOHOST virou flip-flops na netlist
`else
        if (pass_seen && dut.u_sys.tohost == 32'd1) $display("RESULT: PASS");
`endif
        else if (!pass_seen && !fail_seen)          $display("RESULT: FAIL -- TIMEOUT (%0d ms simulados)", max_ms);
        else                                        $display("RESULT: FAIL -- firmware reportou falha");
        $display("==============================================================");
        $finish;
    end
endmodule
