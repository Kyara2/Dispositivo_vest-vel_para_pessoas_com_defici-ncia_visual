# pre_syn.tcl -- usado so' com "./exe.sh pre gui": abre o banco de ondas e
# sonda o testbench inteiro. Depois e' so' dar "run" no SimVision.
database -open waves -shm -into waves.shm -default
probe -create femtorv32_quark_tb -all -depth all -database waves
