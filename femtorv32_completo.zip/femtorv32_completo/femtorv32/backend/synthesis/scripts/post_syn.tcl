# post_syn.tcl -- usado so' com GENERATE_VCD=yes na simulacao pos-sintese.
# Gera um VCD da atividade da netlist (rodando o programa escolhido) para o
# Genus usar em report_power com atividade real (read_stimulus no
# synthesis.tcl, que le "vcd_file.vcd" da pasta work/<MODULE>).
set PROJECT_DIR $env(PROJECT_DIR)
set MODULE      $env(MODULE)
database -open vcd_db -vcd -into ${PROJECT_DIR}/backend/synthesis/work/${MODULE}/vcd_file.vcd
probe -create femtorv32_quark_tb.dut -all -depth all -database vcd_db
run
exit
