
#-----------------------------------------------------------------------------
# Common path variables (directory structure dependent)
#-----------------------------------------------------------------------------
set BACKEND_DIR              ${PROJECT_DIR}/backend
set SYNT_DIR                 ${BACKEND_DIR}/synthesis
set SCRIPT_DIR               ${SYNT_DIR}/scripts
# MODULE separa relatorios/deliverables de cada design em subpastas -- assim
# sintetizar outra variante do FemtoRV (ou outra frequencia, via MODULE
# diferente) nao sobrescreve o resultado anterior.
set MODULE                   $env(MODULE)
# Com DFT os resultados vao para <MODULE>_dft (nao sobrescrevem a sintese sem DFT)
set OUT_TAG                  $env(OUT_TAG)
set RPT_DIR                  ${SYNT_DIR}/reports/${OUT_TAG}
set DEV_DIR                  ${SYNT_DIR}/deliverables/${OUT_TAG}
set LAYOUT_DIR               ${BACKEND_DIR}/layout
file mkdir ${RPT_DIR}
file mkdir ${DEV_DIR}

#-----------------------------------------------------------------------------
# Setting rtl search directories
#-----------------------------------------------------------------------------
set FRONTEND_DIR ${PROJECT_DIR}/frontend
set OTHERS ""
lappend FRONTEND_DIR $OTHERS

#-----------------------------------------------------------------------------
# Setting technology directories
#-----------------------------------------------------------------------------
set LIB_DIR ${TECH_DIR}/gsclib045_svt_v4.7/gsclib045/timing
#lappend LIB_DIR ${TECH_DIR}/io

set LEF_DIR ${TECH_DIR}/gsclib045_svt_v4.7/gsclib045/lef
#lappend LEF_DIR ${TECH_DIR}/giolib045_v3.3/lef
