
#set LIBRARY_SPEED $env(LIBRARY_SPEED)

#-----------------------------------------------------------------------------
# Create Library Domain
#-----------------------------------------------------------------------------
create_library_domain {worst best} 
get_db library_domains *

#-----------------------------------------------------------------------------
# LEF Files and Technology Library
#-----------------------------------------------------------------------------
set_db lib_search_path "${LIB_DIR} ${LEF_DIR} ${SRAM_LIB_DIR} ${SRAM_LEF_DIR}"
set_db [get_db library_domains worst] .library "${WORST_LIST} ${SRAM_WORST_LIST}"
set_db [get_db library_domains best] .library "${BEST_LIST} ${SRAM_BEST_LIST}"
# SRAM_*_LIST ficam vazios quando o design nao usa a macro (ver synthesis.tcl).
# A macro OpenRAM tem corner proprio (FreePDK45: TT 1.0V/25C, ou SS/FF se
# gerados) -- nao bate exatamente com os corners da gsclib045; o Genus usa a
# tabela da macro como esta. Ver tech/sram/README.md.

#-----------------------------------------------------------------------------
# Operating conditions
#-----------------------------------------------------------------------------
get_db [get_db library_domains *worst] .operating_conditions
set_db [get_db library_domains *worst] .operating_conditions ${WORST_LIB_OPERATING_CONDITION}
get_db [get_db library_domains *worst] .operating_conditions
#--
get_db [get_db library_domains *best] .operating_conditions
set_db [get_db library_domains *best] .operating_conditions ${BEST_LIB_OPERATING_CONDITION}
get_db [get_db library_domains *best] .operating_conditions
#--
get_db [get_db library_domain *worst] .default
get_db [get_db library_domain *best] .default 
#--
get_db [vfind /libraries -library_domain worst] .active_operating_conditions
get_db [vfind /libraries -library_domain best] .active_operating_conditions 


# Set the fast library as default-------------------------------------------------
if { $LIBRARY_SPEED eq "fast" } {
       set_db [get_db library_domain *best] .default true

# --------------------------------------------------------------------------------

} elseif {  $LIBRARY_SPEED eq "slow" }  { 
# Set the slow library as default-------------------------------------------------
        set_db [get_db library_domain *worst] .default true
}
# --------------------------------------------------------------------------------


#--
#delete_obj [get_db library_domains *best]
#delete_obj [get_db library_domains *worst]

#-----------------------------------------------------------------------------
# LEF, QRC and CAP Files
#-----------------------------------------------------------------------------

# Load lef files (tech LEF primeiro, depois celulas, depois a macro de SRAM)
set_db lef_library "${LEF_LIST} ${SRAM_LEF_LIST}"

#-----------------------------------------------------------------------------
# Macro de SRAM: o Genus marca 'avoid'/'dont_use' em lib_cells que acha
# suspeitas (o .lib da OpenRAM ja' vem com dont_use : true, e celulas sem
# area ou sem LEF tambem caem nisso). Uma instancia de celula 'avoid' fica
# NAO RESOLVIDA -- caixa-preta vazia, sem timing nem area, e a sintese
# termina sem erro. Licao do projeto neorv32-sky130.
#-----------------------------------------------------------------------------
if { $SRAM_WORST_LIST ne "" } {
    set sram_lcs [get_db lib_cells *${SRAM_NAME}*]
    if { [llength $sram_lcs] == 0 } {
        puts "ERRO: lib_cell ${SRAM_NAME} nao carregada -- confira SRAM_*_LIST e lib_search_path"
    }
    foreach lc $sram_lcs {
        catch { set_db $lc .avoid false }
        catch { set_db $lc .dont_use false }
        puts "SRAM macro liberada: $lc  area=[get_db $lc .area]  avoid=[get_db $lc .avoid]"
    }
}

# Load cap table files
#set_db cap_table_file ${WORST_CAP_LIST}

# Load QRC tech files. OBS: Data from existing 'cap_table_file' is overwritten by technology file
set_db qrc_tech_file ${QRC_LIST}

# Use PLE mode
get_db interconnect_mode
set_db interconnect_mode ple ;# global

#-----------------------------------------------------------------------------
# Manage Cells
#-----------------------------------------------------------------------------
# Try to save power; gated clock cells
# No scan flip-flops
get_lib_cells
get_db lib_cells *SDFF*
get_db base_cell:SDFFRHQX1 .dont_use
set_db base_cell:SDFFRHQX1 .dont_use true
foreach lc [get_db base_cells -if {.name == "SDFF*"}] {
  get_db $lc .dont_use
  set_db $lc .dont_use true
}

foreach lc [get_db base_cells -if {.name == "TLATS*"}] {
  get_db $lc .dont_use
  set_db $lc .dont_use true
}

#-----------------------------------------------------------------------------
# Report important info
#-----------------------------------------------------------------------------
# To find libraries present in the library domain
get_db [get_db library_sets *worst] .libraries
get_db [get_db library_sets *best] .libraries
# To get all library cells from all the libraries present in the library domain
get_db [get_db library_sets *worst] .libraries.lib_cells
get_db [get_db library_sets *best] .libraries.lib_cells
# To get lib_cells only from a particular library in the library domain
get_db [get_db [get_db library_sets *worst] .libraries *slow_vdd1v0] .lib_cells
get_db [get_db [get_db library_sets *best] .libraries *fast_vdd1v2] .lib_cells 
# To find a particular lib_cell in the library domain 
get_db [get_db library_sets *worst] .libraries.lib_cells -regexp XOR
get_db [get_db library_sets *best] .libraries.lib_cells -regexp XOR
# To know all attributes of a particular lib_cell in a library domain in Common_UI
get_db [get_db [get_db library_sets *worst] .libraries.lib_cells -regexp CLKXOR2X1] .*



