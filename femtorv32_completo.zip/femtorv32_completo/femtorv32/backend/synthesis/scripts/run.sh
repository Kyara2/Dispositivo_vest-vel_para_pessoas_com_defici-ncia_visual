#!/bin/bash
# run.sh -- dispatcher do fluxo Cadence (Xcelium + Genus) do FemtoRV32 Quark
# Author: Kyara Esteves de Sousa
# Mesmo padrao do projeto fusion_core: chamado pelo ./exe.sh da raiz.
#
#   ./exe.sh pre  [gui]     simulacao funcional RTL (Xcelium)
#   ./exe.sh syn            sintese logica (Genus)
#   ./exe.sh post [gui]     simulacao da netlist (Xcelium + SDF)
#   ./exe.sh genus          abre so' o Genus, sem rodar o script
#
# MODULEs:
#   femtorv32_quark  processador (default)
#   femto_sram       RAM com macros de SRAM OpenRAM (caixa-preta, tech/sram/)
#   femto_ram_ff     a mesma RAM em flip-flops (comparacao / plano B)
#   femtorv32_sram   SO' SIMULACAO (pre): Quark executando a partir da femto_sram
#   femto_soc        SoC: Quark + AXI4-Lite + RAM (macros) + fusion_node + HC-SR04
#                    + I2C (VL53L0X) + UART  (pre roda o firmware soc_fw)
#
# Variaveis de ambiente opcionais (exportar ANTES do ./exe.sh):
#   MODULE=<ver lista acima>   design a rodar
#   PROGRAM=isa_test|c_suite   programa (frontend/firmware/hex/<PROGRAM>.hex)
#                              (femtorv32_sram usa c_suite_8k por default)
#   WAITSTATES=0|1             wait states aleatorios na memoria do TB
#   SEED=<n>                   semente do TB (wait states)
#   SDF=yes|no                 so' no post: anota atrasos do SDF (default yes)
#   CLK_PERIOD=<ns>            sobrescreve o periodo abaixo (sintese E sims)
#
# Exemplos:
#   ./exe.sh pre                                   # isa_test, sem wait states
#   PROGRAM=c_suite WAITSTATES=1 ./exe.sh pre
#   ./exe.sh syn
#   PROGRAM=c_suite ./exe.sh post
#   CLK_PERIOD=5 ./exe.sh syn
#   MODULE=femto_sram ./exe.sh pre ; MODULE=femto_sram ./exe.sh syn ; MODULE=femto_sram ./exe.sh post
#   MODULE=femtorv32_sram ./exe.sh pre

# Clock Period in ns. Default 10 ns (100 MHz); o femto_soc usa 37.037 ns
# (27 MHz), que e' o CLK_HZ do RTL e o clock da Tang Primer 20K -- assim
# baud da UART, tempos dos sensores e firmware valem igual no ASIC e na FPGA.
# Para outra frequencia no SoC, mude CLK_PERIOD E o parametro CLK_HZ do femto_soc.
if [[ "${MODULE:-}" == "femto_soc" ]]; then
    export CLK_PERIOD=${CLK_PERIOD:-37.037}
else
    export CLK_PERIOD=${CLK_PERIOD:-10}
fi

# PROJECT_NAME e' o nome REAL da pasta do projeto no disco. MODULE escolhe
# o design (top-level) -- deixei o case pronto pra quando entrar outra
# variante do FemtoRV (electron, gracilis...).
export PROJECT_NAME="femtorv32"
export MODULE=${MODULE:-femtorv32_quark}
export DESIGN="${MODULE}"
export USER=aluno18 ;# put here YOUR user name at this machine
#export PROJECT_DIR=/home/${USER}/projetos/${PROJECT_NAME}
export PROJECT_DIR=/prj/ci/workarea/${USER}/projetos/${PROJECT_NAME}
export BACKEND_DIR=${PROJECT_DIR}/backend
export FRONTEND_DIR=${PROJECT_DIR}/frontend
export HDL_SRC=${FRONTEND_DIR}/src
export TB_SRC=${FRONTEND_DIR}/testbench
export FW_HEX=${FRONTEND_DIR}/firmware/hex

# Macro de SRAM (OpenRAM, FreePDK45) -- ver tech/sram/README.md
export SRAM_NAME="sram_32x1024_freepdk45"
export SRAM_DIR=${PROJECT_DIR}/tech/sram/${SRAM_NAME}
export SRAM_SIM_MODEL=${SRAM_DIR}/verilog/${SRAM_NAME}.v

# USE_SRAM_MACRO: o design instancia a macro (Genus precisa do .lib/.lef dela,
# simulacao precisa do modelo comportamental). IS_CPU_TB: o testbench roda
# um programa (+PROGRAM). SIM_ONLY: nao tem sintese.
export USE_SRAM_MACRO="no"; IS_CPU_TB="no"; SIM_ONLY="no"; IS_SOC="no"
case "$MODULE" in
    femtorv32_quark)
        export MODULE_FILES="femtorv32_quark.v"; IS_CPU_TB="yes" ;;
    femto_sram)
        export MODULE_FILES="femto_sram.v"; export USE_SRAM_MACRO="yes" ;;
    femto_ram_ff)
        export MODULE_FILES="femto_ram_ff.v" ;;
    femtorv32_sram)
        export MODULE_FILES="femtorv32_quark.v femto_sram.v"; export USE_SRAM_MACRO="yes"
        IS_CPU_TB="yes"; SIM_ONLY="yes"
        export PROGRAM=${PROGRAM:-c_suite_8k} ;;
    femto_soc)
        export MODULE_FILES="femtorv32_quark.v femto_sram.v \
            fusion/fusion_gain.sv fusion/fusion_channel.sv fusion/fusion_variance.sv fusion/fusion_node.sv \
            soc/axil2reg.v soc/femto_axil_master.v soc/axil_xbar.v soc/axil_sram.v \
            soc/periph_sysinfo.v soc/periph_uart.v soc/periph_hcsr04.v soc/periph_i2c.v soc/periph_fusion.v \
            soc/femto_soc.v"
        export USE_SRAM_MACRO="yes"; IS_CPU_TB="yes"; IS_SOC="yes"
        export PROGRAM=${PROGRAM:-soc_fw} ;;
    *)
        echo "ERRO: MODULE='$MODULE' desconhecido. Use femtorv32_quark, femto_sram, femto_ram_ff ou femtorv32_sram."
        exit 1 ;;
esac
export MODULE_FILES_FULL=""
for f in $MODULE_FILES; do MODULE_FILES_FULL="$MODULE_FILES_FULL ${HDL_SRC}/${f}"; done

#export TECH_DIR=/opt/GPDK045 ; # technology dependent
export TECH_DIR=/pdk/gpdk045 ;  # technology dependent
export HDL_NAME=${DESIGN}
export HDL_TYPE="verilog"       ; # vhdl or verilog or system_verilog (o RTL do FemtoRV e' Verilog-2001)
# o SoC mistura .v com os .sv do nucleo de fusao: le tudo como SystemVerilog
[[ "$MODULE" == "femto_soc" ]] && export HDL_TYPE="system_verilog"
export GENERATE_VCD="no"        ; # no or yes
export SYNTHESIS_WITH_DFT=${SYNTHESIS_WITH_DFT:-no}  ; # no or yes (SYNTHESIS_WITH_DFT=yes ./exe.sh syn)
export LIBRARY_SPEED="slow"     ; # The options are slow or fast

# Programa / testbench
export PROGRAM=${PROGRAM:-isa_test}
export WAITSTATES=${WAITSTATES:-0}
export SEED=${SEED:-1}
export SDF=${SDF:-yes}

# The standard slow is: "slow_vdd1v0_basicCells.lib"
export WORST_LIB_NAME="slow_vdd1v0_basicCells"
export WORST_LIST="${WORST_LIB_NAME}.lib"  ; # This is the slow lib
# The standard fast is: fast_vdd1v2_basicCells.lib
export BEST_LIB_NAME="fast_vdd1v2_basicCells"
export BEST_LIST="${BEST_LIB_NAME}.lib"   ; # This is the fast lib

echo "BEST_LIST: $BEST_LIST, WORST_LIST: $WORST_LIST"

export PRE_SYN_SCRIPT=${PROJECT_DIR}/backend/synthesis/scripts/pre_syn.tcl
export POST_SYN_SCRIPT=${PROJECT_DIR}/backend/synthesis/scripts/post_syn.tcl

# Mesmo PATH do projeto fusion_core (XCELIUM2603 primeiro; DDI221 antes do
# DDI261 por causa do libxcb-icccm.so.4 que falta no servidor).
export PATH=/tools/cadence/XCELIUM2603/tools/bin/64bit:/tools/cadence/XCELIUM2603/tools/bin:/tools/cadence/XCELIUM2603/bin:/tools/cadence/VMANAGER2603/bin:/tools/cadence/VMANAGER2603/tools/bin:/tools/cadence/DDI221/bin:/tools/cadence/DDI221/tools/bin:/tools/cadence/DDI261/bin:/tools/cadence/DDI261/tools/bin:/tools/cadence/CONFRML261/bin:/tools/cadence/CONFRML261/tools/bin:/tools/cadence/MODUS261/bin:/tools/cadence/MODUS261/tools/bin:/tools/cadence/PEGASUS261/bin:/tools/cadence/PEGASUS261/tools/bin:/tools/cadence/PVS251/bin:/tools/cadence/PVS251/tools/bin:/tools/cadence/QUANTUS261/bin:/tools/cadence/QUANTUS261/tools/bin:/tools/cadence/SPECTRE251/bin:/tools/cadence/SPECTRE251/tools/bin:/tools/cadence/SSV261/bin:/tools/cadence/SSV261/tools/bin:/tools/cadence/IC618/bin:/tools/cadence/IC618/tools/bin:/tools/bin:/tools/cadence/QUANTUS221/bin:/tools/cadence/QUANTUS221/tools/bin:/tools/cadence/PEGASUS231/bin:/tools/cadence/PEGASUS231/tools/bin:/tools/cadence/SSV231/bin:/tools/cadence/SSV231/tools/bin:/tools/cadence/XCELIUM2309/tools/bin/64bit:/tools/cadence/XCELIUM2309/tools/bin:/tools/cadence/MODUS231/bin:/tools/cadence/MODUS231/tools/bin:/tools/cadence/CONFRML232/bin:/tools/cadence/CONFRML232/tools/bin:/tools/cadence/DDI221/bin:/tools/cadence/DDI221/tools/bin:/tools/cadence/PVS231/bin:/tools/cadence/PVS231/tools/bin:/tools/cadence/INCISIVE152/bin:/tools/cadence/SPECTRE231/bin:/tools/cadence/SPECTRE231/tools/bin:/tools/cadence/ICADVM201/bin:/tools/cadence/ICADVM201/tools/bin:/tools/cadence/ICADVM201/tools/dFII/bin:/home/${USER}/.local/bin:/home/${USER}/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin

echo "The name of this script is $0, the first argument is $1, the second arguments is $2"
echo "HDL_TYPE: $HDL_TYPE"

export HDL_LIBS=""

if [[ "$HDL_TYPE" == "vhdl" ]]; then
    export HDL_EXTENSION="vhd"
elif [[ "$HDL_TYPE" == "system_verilog" ]]; then
    export HDL_EXTENSION="sv"
else
    export HDL_EXTENSION="v"
fi

# O testbench e' SystemVerilog mesmo com o RTL em Verilog
export HDL_TESTBENCH=${HDL_NAME}_tb.sv

if [[ "$SYNTHESIS_WITH_DFT" == "yes" ]]; then
    export DFT_STRING="POST_DFT"
    export OUT_TAG="${MODULE}_dft"      # resultados com DFT em <MODULE>_dft
else
    export DFT_STRING="PRE_DFT"
    export OUT_TAG="${MODULE}"
fi

if [[ "$LIBRARY_SPEED" == "slow" ]]; then
    export SYNTHESIS_LIBRARY=$WORST_LIST
    export SYNTHESIS_LIBRARY_STRING="$WORST_LIB_NAME.v"
elif [[ "$LIBRARY_SPEED" == "fast" ]]; then
    export SYNTHESIS_LIBRARY=$BEST_LIST
    export SYNTHESIS_LIBRARY_STRING="$BEST_LIB_NAME.v"
fi

echo "HDL string: $HDL_EXTENSION, HDL libs: $HDL_LIBS,  DFT: $DFT_STRING, SYNTHESIS_LIBRARY: $SYNTHESIS_LIBRARY"
echo "HDL_SRC: $HDL_SRC"

if [ "$1" == "pre-synthesis" ] || [ "$1" == "pre" ]; then
    export OPTION="pre-synthesis";
elif [ "$1" == "post-synthesis" ] || [ "$1" == "post" ]; then
    export OPTION="post-synthesis";
elif [ "$1" == "synthesis" ] || [ "$1" == "syn" ] ; then
    export OPTION="synthesis";
elif [ "$1" == "genus" ] || [ "$1" == "g" ] ; then
    export OPTION="genus";
else
    echo "ERRO: opcao '$1' desconhecida. Use pre [gui], syn, post [gui] ou genus."
    exit 1
fi

echo "OPTION: $OPTION"

# Confere programa/testbench antes de chamar o xrun
check_sim_inputs () {
    if [ ! -f "${TB_SRC}/${HDL_TESTBENCH}" ]; then
        echo "ERRO: nao achei ${TB_SRC}/${HDL_TESTBENCH} -- confira MODULE='$MODULE'."
        exit 1
    fi
    if [[ "$USE_SRAM_MACRO" == "yes" ]] && [ ! -f "$SRAM_SIM_MODEL" ]; then
        echo "ERRO: nao achei o modelo da macro $SRAM_SIM_MODEL"
        exit 1
    fi
    if [[ "$IS_CPU_TB" == "yes" ]] && [ ! -f "${FW_HEX}/${PROGRAM}.hex" ]; then
        echo "ERRO: nao achei ${FW_HEX}/${PROGRAM}.hex -- programas disponiveis:"
        ls ${FW_HEX}/*.hex 2>/dev/null | xargs -n1 basename | sed 's/\.hex$//'
        exit 1
    fi
}

# Le o log e imprime a linha FUNCTIONAL_RESULT (o run_all_functional.sh faz grep dela)
print_result () {
    local LOG=$1
    local TAG=$2
    echo "----------------------------------------------------------------------"
    echo "LOG: ${LOG}"
    grep -E "^\[console\]" ${LOG} 2>/dev/null
    grep -E "\[tb\] (ciclos|instrucoes)" ${LOG} 2>/dev/null
    if grep -qE "^RESULT: PASS" ${LOG} 2>/dev/null; then
        echo "FUNCTIONAL_RESULT: PASS   [${TAG}]"
    elif grep -qE "^RESULT: FAIL" ${LOG} 2>/dev/null; then
        grep -E "^RESULT: FAIL" ${LOG}
        echo "FUNCTIONAL_RESULT: FAIL   [${TAG}] -- ver o log acima"
    else
        echo "FUNCTIONAL_RESULT: INDEFINIDO [${TAG}] -- o testbench nao imprimiu RESULT: PASS/FAIL (erro de compilacao/elaboracao?), confere o log"
    fi
    echo "----------------------------------------------------------------------"
}

# Arquivos/plusargs extras de simulacao conforme o MODULE
SIM_EXTRA_FILES=""
[[ "$USE_SRAM_MACRO" == "yes" ]] && SIM_EXTRA_FILES="${SRAM_SIM_MODEL}"
[[ "$IS_SOC" == "yes" ]] && SIM_EXTRA_FILES="${SIM_EXTRA_FILES} ${TB_SRC}/models/vl53l0x_model.v"
SIM_PLUSARGS="+CLK_NS=${CLK_PERIOD} +SEED=${SEED}"
if [[ "$IS_SOC" == "yes" ]]; then
    SIM_PLUSARGS="+PROGRAM=${FW_HEX}/${PROGRAM}.hex +MAX_MS=${MAX_MS:-200}"
    RUN_TAG="${PROGRAM}"
elif [[ "$IS_CPU_TB" == "yes" ]]; then
    SIM_PLUSARGS="${SIM_PLUSARGS} +PROGRAM=${FW_HEX}/${PROGRAM}.hex +WAITSTATES=${WAITSTATES}"
    RUN_TAG="${PROGRAM}_ws${WAITSTATES}"
else
    RUN_TAG="mem"
fi

# Prepara as views da macro para o Genus:
#  - escolhe os .lib de cada corner (SS/FF se existirem, senao TT nos dois);
#  - gera o LEF com os nomes de camada da GPDK045. A OpenRAM (FreePDK45)
#    escreve "metal1..metal4"; o tech LEF da GPDK045 tem outros nomes, e o
#    Genus aborta com "layer ... not found" (mesmo erro do projeto sky130).
#    O prefixo certo e' lido do proprio tech LEF da GPDK.
prepare_sram_views () {
    local LIBD=${SRAM_DIR}/lib
    local TT=${SRAM_NAME}_TT_1p0V_25C.lib
    export SRAM_WORST_LIB=$TT; export SRAM_BEST_LIB=$TT
    [ -f ${LIBD}/${SRAM_NAME}_SS_0p9V_125C.lib ] && export SRAM_WORST_LIB=${SRAM_NAME}_SS_0p9V_125C.lib
    [ -f ${LIBD}/${SRAM_NAME}_FF_1p1V_0C.lib ]   && export SRAM_BEST_LIB=${SRAM_NAME}_FF_1p1V_0C.lib
    for f in $SRAM_WORST_LIB $SRAM_BEST_LIB; do
        [ -f ${LIBD}/$f ] || { echo "ERRO: nao achei ${LIBD}/$f"; return 1; }
    done
    echo "SRAM .lib worst: $SRAM_WORST_LIB   best: $SRAM_BEST_LIB"

    local TECH_LEF=${TECH_DIR}/gsclib045_svt_v4.7/gsclib045/lef/gsclib045_tech.lef
    local SRC=${SRAM_DIR}/lef/${SRAM_NAME}.lef
    export SRAM_LEF=${SRAM_NAME}_gpdk045.lef
    local M1=""
    if [ -f "$TECH_LEF" ]; then
        M1=$(grep -iE "^[[:space:]]*LAYER[[:space:]]+metal1[[:space:]]*$" $TECH_LEF | head -1 | awk '{print $2}')
    fi
    local PFX=${M1%1}
    if [ -z "$PFX" ]; then
        PFX="Metal"
        echo "AVISO: nao achei a camada metal1 em $TECH_LEF -- usando o prefixo '$PFX'."
        echo "       Confira com: grep -i '^ *LAYER' $TECH_LEF"
    fi
    sed -E "s/LAYER([[:space:]]+)metal([0-9]+)/LAYER\1${PFX}\2/g" $SRC > ${SRAM_DIR}/lef/${SRAM_LEF}
    echo "SRAM LEF: ${SRAM_DIR}/lef/${SRAM_LEF} (camadas metalN -> ${PFX}N)"
    local DB_TECH=$(grep -m1 "DATABASE MICRONS" $TECH_LEF 2>/dev/null | awk '{print $3}')
    local DB_SRAM=$(grep -m1 "DATABASE MICRONS" $SRC | awk '{print $3}')
    if [ -n "$DB_TECH" ] && [ "$DB_TECH" != "$DB_SRAM" ]; then
        echo "AVISO: DATABASE MICRONS da macro ($DB_SRAM) difere do tech LEF ($DB_TECH)."
    fi
    return 0
}

## Run HDL =============================> SIMULATION PRE-SYNTHESIS with XCELIUM
if [[ $OPTION = "pre-synthesis" ]]; then

    check_sim_inputs
    export PRE_WORK=${BACKEND_DIR}/synthesis/work/pre/${MODULE}
    mkdir -p ${PRE_WORK}
    cd ${PRE_WORK}

    GUI_FLAGS="-access +rwc"
    INPUT_FLAG=""
    if [ "$2" == "gui" ]; then
        GUI_FLAGS="-access +rwc -gui"
        INPUT_FLAG="-input ${PRE_SYN_SCRIPT}"
    fi

    TAG="${MODULE} ${RUN_TAG} pre"
    LOG=${PRE_WORK}/${DESIGN}_pre_${RUN_TAG}.log
    echo "MODULE: $MODULE  ${RUN_TAG}  CLK: ${CLK_PERIOD} ns  GUI: ${2:-no}"

    xrun -64bit -sv -timescale 1ns/1ps \
        -incdir ${TB_SRC} \
        ${SIM_EXTRA_FILES} \
        ${MODULE_FILES_FULL} \
        ${TB_SRC}/${HDL_TESTBENCH} \
        -top ${DESIGN}_tb \
        ${SIM_PLUSARGS} \
        ${GUI_FLAGS} \
        ${INPUT_FLAG} \
        -l ${LOG}

    print_result ${LOG} "${TAG}"

## Run netlist ============================> SIMULATION POST-SYNTHESIS with XCELIUM
elif [[ $OPTION = "post-synthesis" ]]; then

    if [[ "$SIM_ONLY" == "yes" ]]; then
        echo "ERRO: MODULE=$MODULE e' so' simulacao RTL (nao tem netlist). Use ./exe.sh pre."
        exit 1
    fi
    check_sim_inputs
    # com SYNTHESIS_WITH_DFT=yes usa a netlist com scan (deliverables/<MODULE>_dft)
    NETLIST=${BACKEND_DIR}/synthesis/deliverables/${OUT_TAG}/${HDL_NAME}_netlist.v
    SDF_PATH=${BACKEND_DIR}/synthesis/deliverables/${OUT_TAG}/${HDL_NAME}_worsts.sdf
    CELL_LIB=${TECH_DIR}/gsclib045_all_v4.7/gsclib045/verilog/${SYNTHESIS_LIBRARY_STRING}

    if [ ! -f "$NETLIST" ]; then
        echo "ERRO: nao achei a netlist $NETLIST -- rode ./exe.sh syn antes."
        exit 1
    fi

    export POST_WORK=${BACKEND_DIR}/synthesis/work/post/${OUT_TAG}
    mkdir -p ${POST_WORK}
    cd ${POST_WORK}
    rm -rf xcelium.d

    # xrun NAO tem "-sdf_max" (isso e' do ModelSim/Questa): a anotacao e'
    # feita pelo $sdf_annotate dentro do testbench, ligado pelas macros
    # POST_SYNTH e SDF_FILE.
    POST_SYN_COMMANDS="+define+POST_SYNTH"
    [[ "$SYNTHESIS_WITH_DFT" == "yes" ]] && POST_SYN_COMMANDS="${POST_SYN_COMMANDS} +define+DFT"
    # SoC: a netlist nao tem parametros; o firmware soc_fw_post forca o modo
    # simulacao e cada macro carrega o seu banco (+SRAM_PRELOAD)
    POST_PLUSARGS="${SIM_PLUSARGS}"
    if [[ "$IS_SOC" == "yes" ]]; then
        if [ ! -f "${FW_HEX}/soc_fw_post_b0.hex" ]; then
            echo "ERRO: falta ${FW_HEX}/soc_fw_post_b0.hex (make -C frontend/firmware hex/soc_fw_post.hex)"
            exit 1
        fi
        POST_PLUSARGS="+SRAM_PRELOAD=${FW_HEX}/soc_fw_post +MAX_MS=${MAX_MS:-1500}"
    fi
    if [[ "$SDF" == "yes" ]]; then
        if [ ! -f "$SDF_PATH" ]; then
            echo "ERRO: nao achei o SDF $SDF_PATH (rode ./exe.sh syn, ou use SDF=no)."
            exit 1
        fi
        POST_SYN_COMMANDS="${POST_SYN_COMMANDS} +define+SDF_FILE=\"${SDF_PATH}\""
    fi

    GUI_FLAGS="-access +rwc"
    if [ "$2" == "gui" ]; then
        GUI_FLAGS="-access +rwc -gui"
    fi

    VCD_COMMANDS=""
    if [[ $GENERATE_VCD == "yes" ]]; then
        mkdir -p ${BACKEND_DIR}/synthesis/work/${MODULE}
        VCD_COMMANDS="-input ${POST_SYN_SCRIPT}"
    fi

    TAG="${OUT_TAG} ${RUN_TAG} post sdf=${SDF}"
    LOG=${POST_WORK}/${DESIGN}_post_${RUN_TAG}.log
    echo "MODULE: $MODULE  (${OUT_TAG})  ${RUN_TAG}  CLK: ${CLK_PERIOD} ns  SDF: $SDF  DFT: ${SYNTHESIS_WITH_DFT}  GUI: ${2:-no}"

    # a macro e' caixa-preta na netlist: entra o modelo comportamental dela
    xrun -64bit -timescale 1ns/1ps \
        -incdir ${TB_SRC} \
        ${CELL_LIB} \
        ${SIM_EXTRA_FILES} \
        ${NETLIST} \
        ${TB_SRC}/${HDL_TESTBENCH} \
        -top ${DESIGN}_tb \
        ${POST_SYN_COMMANDS} \
        ${POST_PLUSARGS} \
        ${VCD_COMMANDS} \
        ${GUI_FLAGS} \
        -l ${LOG}

    print_result ${LOG} "${TAG}"
    if [[ "$SDF" == "yes" ]]; then
        echo "Anotacao SDF: ${POST_WORK}/sdf_annotate.log"
        grep -iE "\*W|\*E" ${LOG} | grep -i sdf | head -5
    fi

# To execute the GENUS ======================= > LOGIC SYNTHESIS with GENUS
elif [[ $OPTION = "synthesis" ]] ; then

    if [[ "$SIM_ONLY" == "yes" ]]; then
        echo "ERRO: MODULE=$MODULE e' so' simulacao (o top com processador+memoria vem na etapa do SoC AXI4)."
        exit 1
    fi
    if [[ "$USE_SRAM_MACRO" == "yes" ]]; then
        prepare_sram_views || exit 1
    fi

    export SYN_WORK=${PROJECT_DIR}/backend/synthesis/work/${OUT_TAG}
    export SYN_DELIVERABLES=${PROJECT_DIR}/backend/synthesis/deliverables/${OUT_TAG}
    export SYN_REPORTS=${PROJECT_DIR}/backend/synthesis/reports/${OUT_TAG}
    mkdir -p ${SYN_WORK} ${SYN_DELIVERABLES} ${SYN_REPORTS}

    echo "MODULE: $MODULE   DESIGN (top): $DESIGN   MODULE_FILES: $MODULE_FILES   CLK: ${CLK_PERIOD} ns"

    cd ${SYN_WORK}

    genus -abort_on_error -lic_startup \
        Genus_Synthesis -lic_startup_options \
        Genus_Physical_Opt -log genus -overwrite \
        -files ${PROJECT_DIR}/backend/synthesis/scripts/synthesis.tcl

    echo "----------------------------------------------------------------------"
    echo "MODULE:       $MODULE   (DFT: $SYNTHESIS_WITH_DFT)"
    echo "WORK:         $SYN_WORK"
    echo "DELIVERABLES: $SYN_DELIVERABLES"
    echo "REPORTS:      $SYN_REPORTS"
    if [ -f "${SYN_REPORTS}/${HDL_NAME}_timing.rpt" ]; then
        echo "Slack (pior caminho, ${CLK_PERIOD} ns):"
        grep -i "slack" ${SYN_REPORTS}/${HDL_NAME}_timing.rpt | head -3
    fi
    if [ -f "${SYN_REPORTS}/${HDL_NAME}_area.rpt" ]; then
        echo "Area:"
        grep -E "^\s*${HDL_NAME}\s" ${SYN_REPORTS}/${HDL_NAME}_area.rpt | head -1
    fi
    echo "----------------------------------------------------------------------"

elif [[ $OPTION = "genus" ]] ; then

    export SYN_WORK=${PROJECT_DIR}/backend/synthesis/work/${MODULE}
    mkdir -p ${SYN_WORK}
    cd ${SYN_WORK}

    genus -abort_on_error -lic_startup \
        Genus_Synthesis -lic_startup_options \
        Genus_Physical_Opt -log genus -overwrite

fi
