add_search_path /pdk/gpdk045/gsclib045_svt_v4.7/gsclib045/timing /pdk/gpdk045/gsclib045_svt_v4.7/gsclib045/lef /prj/ci/workarea/aluno18/projetos/femtorv32/tech/sram/sram_32x1024_freepdk45/lib /prj/ci/workarea/aluno18/projetos/femtorv32/tech/sram/sram_32x1024_freepdk45/lef -library -both
read_library -liberty -both \
    /pdk/gpdk045/gsclib045_svt_v4.7/gsclib045/timing/slow_vdd1v0_basicCells.lib \
    /prj/ci/workarea/aluno18/projetos/femtorv32/tech/sram/sram_32x1024_freepdk45/lib/sram_32x1024_freepdk45_TT_1p0V_25C.lib

