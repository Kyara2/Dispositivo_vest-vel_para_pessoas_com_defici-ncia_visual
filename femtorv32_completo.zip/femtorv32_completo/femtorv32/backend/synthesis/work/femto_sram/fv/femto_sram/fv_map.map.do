
//input ports
add mapped point clk clk -type PI PI
add mapped point sel sel -type PI PI
add mapped point mem_addr[31] mem_addr[31] -type PI PI
add mapped point mem_addr[30] mem_addr[30] -type PI PI
add mapped point mem_addr[29] mem_addr[29] -type PI PI
add mapped point mem_addr[28] mem_addr[28] -type PI PI
add mapped point mem_addr[27] mem_addr[27] -type PI PI
add mapped point mem_addr[26] mem_addr[26] -type PI PI
add mapped point mem_addr[25] mem_addr[25] -type PI PI
add mapped point mem_addr[24] mem_addr[24] -type PI PI
add mapped point mem_addr[23] mem_addr[23] -type PI PI
add mapped point mem_addr[22] mem_addr[22] -type PI PI
add mapped point mem_addr[21] mem_addr[21] -type PI PI
add mapped point mem_addr[20] mem_addr[20] -type PI PI
add mapped point mem_addr[19] mem_addr[19] -type PI PI
add mapped point mem_addr[18] mem_addr[18] -type PI PI
add mapped point mem_addr[17] mem_addr[17] -type PI PI
add mapped point mem_addr[16] mem_addr[16] -type PI PI
add mapped point mem_addr[15] mem_addr[15] -type PI PI
add mapped point mem_addr[14] mem_addr[14] -type PI PI
add mapped point mem_addr[13] mem_addr[13] -type PI PI
add mapped point mem_addr[12] mem_addr[12] -type PI PI
add mapped point mem_addr[11] mem_addr[11] -type PI PI
add mapped point mem_addr[10] mem_addr[10] -type PI PI
add mapped point mem_addr[9] mem_addr[9] -type PI PI
add mapped point mem_addr[8] mem_addr[8] -type PI PI
add mapped point mem_addr[7] mem_addr[7] -type PI PI
add mapped point mem_addr[6] mem_addr[6] -type PI PI
add mapped point mem_addr[5] mem_addr[5] -type PI PI
add mapped point mem_addr[4] mem_addr[4] -type PI PI
add mapped point mem_addr[3] mem_addr[3] -type PI PI
add mapped point mem_addr[2] mem_addr[2] -type PI PI
add mapped point mem_addr[1] mem_addr[1] -type PI PI
add mapped point mem_addr[0] mem_addr[0] -type PI PI
add mapped point mem_wdata[31] mem_wdata[31] -type PI PI
add mapped point mem_wdata[30] mem_wdata[30] -type PI PI
add mapped point mem_wdata[29] mem_wdata[29] -type PI PI
add mapped point mem_wdata[28] mem_wdata[28] -type PI PI
add mapped point mem_wdata[27] mem_wdata[27] -type PI PI
add mapped point mem_wdata[26] mem_wdata[26] -type PI PI
add mapped point mem_wdata[25] mem_wdata[25] -type PI PI
add mapped point mem_wdata[24] mem_wdata[24] -type PI PI
add mapped point mem_wdata[23] mem_wdata[23] -type PI PI
add mapped point mem_wdata[22] mem_wdata[22] -type PI PI
add mapped point mem_wdata[21] mem_wdata[21] -type PI PI
add mapped point mem_wdata[20] mem_wdata[20] -type PI PI
add mapped point mem_wdata[19] mem_wdata[19] -type PI PI
add mapped point mem_wdata[18] mem_wdata[18] -type PI PI
add mapped point mem_wdata[17] mem_wdata[17] -type PI PI
add mapped point mem_wdata[16] mem_wdata[16] -type PI PI
add mapped point mem_wdata[15] mem_wdata[15] -type PI PI
add mapped point mem_wdata[14] mem_wdata[14] -type PI PI
add mapped point mem_wdata[13] mem_wdata[13] -type PI PI
add mapped point mem_wdata[12] mem_wdata[12] -type PI PI
add mapped point mem_wdata[11] mem_wdata[11] -type PI PI
add mapped point mem_wdata[10] mem_wdata[10] -type PI PI
add mapped point mem_wdata[9] mem_wdata[9] -type PI PI
add mapped point mem_wdata[8] mem_wdata[8] -type PI PI
add mapped point mem_wdata[7] mem_wdata[7] -type PI PI
add mapped point mem_wdata[6] mem_wdata[6] -type PI PI
add mapped point mem_wdata[5] mem_wdata[5] -type PI PI
add mapped point mem_wdata[4] mem_wdata[4] -type PI PI
add mapped point mem_wdata[3] mem_wdata[3] -type PI PI
add mapped point mem_wdata[2] mem_wdata[2] -type PI PI
add mapped point mem_wdata[1] mem_wdata[1] -type PI PI
add mapped point mem_wdata[0] mem_wdata[0] -type PI PI
add mapped point mem_wmask[3] mem_wmask[3] -type PI PI
add mapped point mem_wmask[2] mem_wmask[2] -type PI PI
add mapped point mem_wmask[1] mem_wmask[1] -type PI PI
add mapped point mem_wmask[0] mem_wmask[0] -type PI PI
add mapped point mem_rstrb mem_rstrb -type PI PI

//output ports
add mapped point mem_rdata[31] mem_rdata[31] -type PO PO
add mapped point mem_rdata[30] mem_rdata[30] -type PO PO
add mapped point mem_rdata[29] mem_rdata[29] -type PO PO
add mapped point mem_rdata[28] mem_rdata[28] -type PO PO
add mapped point mem_rdata[27] mem_rdata[27] -type PO PO
add mapped point mem_rdata[26] mem_rdata[26] -type PO PO
add mapped point mem_rdata[25] mem_rdata[25] -type PO PO
add mapped point mem_rdata[24] mem_rdata[24] -type PO PO
add mapped point mem_rdata[23] mem_rdata[23] -type PO PO
add mapped point mem_rdata[22] mem_rdata[22] -type PO PO
add mapped point mem_rdata[21] mem_rdata[21] -type PO PO
add mapped point mem_rdata[20] mem_rdata[20] -type PO PO
add mapped point mem_rdata[19] mem_rdata[19] -type PO PO
add mapped point mem_rdata[18] mem_rdata[18] -type PO PO
add mapped point mem_rdata[17] mem_rdata[17] -type PO PO
add mapped point mem_rdata[16] mem_rdata[16] -type PO PO
add mapped point mem_rdata[15] mem_rdata[15] -type PO PO
add mapped point mem_rdata[14] mem_rdata[14] -type PO PO
add mapped point mem_rdata[13] mem_rdata[13] -type PO PO
add mapped point mem_rdata[12] mem_rdata[12] -type PO PO
add mapped point mem_rdata[11] mem_rdata[11] -type PO PO
add mapped point mem_rdata[10] mem_rdata[10] -type PO PO
add mapped point mem_rdata[9] mem_rdata[9] -type PO PO
add mapped point mem_rdata[8] mem_rdata[8] -type PO PO
add mapped point mem_rdata[7] mem_rdata[7] -type PO PO
add mapped point mem_rdata[6] mem_rdata[6] -type PO PO
add mapped point mem_rdata[5] mem_rdata[5] -type PO PO
add mapped point mem_rdata[4] mem_rdata[4] -type PO PO
add mapped point mem_rdata[3] mem_rdata[3] -type PO PO
add mapped point mem_rdata[2] mem_rdata[2] -type PO PO
add mapped point mem_rdata[1] mem_rdata[1] -type PO PO
add mapped point mem_rdata[0] mem_rdata[0] -type PO PO
add mapped point mem_rbusy mem_rbusy -type PO PO
add mapped point mem_wbusy mem_wbusy -type PO PO

//inout ports




//Sequential Pins
add mapped point rd_bank_q[0]/q rd_bank_q_reg[0]/Q -type DFF DFF



//Black Boxes
add mapped point g_bank[0].g_asic.u_sram g_bank[0].g_asic.u_sram -type BBOX BBOX
add mapped point g_bank[1].g_asic.u_sram g_bank[1].g_asic.u_sram -type BBOX BBOX



//Empty Modules as Blackboxes
