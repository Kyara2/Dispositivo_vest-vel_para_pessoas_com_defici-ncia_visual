# Artigo IEEE (conferência): SoC RISC-V + coprocessador de fusão de 8 canais

No Overleaf: New Project → Upload Project → este .zip. Use o compilador pdfLaTeX (padrão); o arquivo principal é `main.tex`.

Todos os dados já estão preenchidos com os resultados finais:
- síntese no Genus, com e sem DFT;
- UVM;
- FPGA (relatórios do Gowin);
- calibração em 6 distâncias;
- números da placa (2.234 e 179 ciclos, 12,5×).

O link do vídeo também já está no artigo, e o QR code é gerado sozinho.

A foto do circuito (`fotos/montagem_circuito.jpg`) e o print do terminal (`fotos/terminal.png`) já estão no artigo.

Os valores ficam no bloco "CAMPOS" no início do `main.tex`, se precisar ajustar algum. Os gráficos estão em `figs/`; o `figs/mk.py` os regenera a partir dos números dos relatórios.
