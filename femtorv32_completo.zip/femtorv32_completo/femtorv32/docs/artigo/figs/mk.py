import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"axes.spines.top":False,"axes.spines.right":False})
NAVY="#16324f"; TEAL="#1f8a8a"; ORANGE="#e07a2e"; GREY="#8a95a1"; LIGHT="#d9e2ea"

def save(fig,name):
    fig.tight_layout(); fig.savefig(name+".pdf"); fig.savefig(name+".png",dpi=220); plt.close(fig)

# 1) area do SoC (sem DFT) por bloco
blocks=[("RAM 16 KB (4 macros)",204288.260),("FemtoRV32 Quark",21928.007),("Coprocessador fusão",12727.225),
        ("HC-SR04",3548.970),("I2C",1736.395),("Ponte AXI",1538.983),("Sysinfo",1056.481),("Crossbar",902.382),("UART",555.002)]
fig,ax=plt.subplots(figsize=(3.5,2.5))
names=[b[0] for b in blocks]; vals=[b[1]/1000 for b in blocks]
cols=[GREY]+[NAVY]+[ORANGE]+[TEAL]*6
ax.barh(names[::-1],vals[::-1],color=cols[::-1])
for i,v in enumerate(vals[::-1]): ax.text(v*1.12,i,f"{v:.1f}",va="center",fontsize=7)
ax.set_xscale("log"); ax.set_xlim(0.4,900); ax.set_xlabel("Área (×10³ µm², escala log)")
ax.tick_params(axis="y",labelsize=7)
save(fig,"fig_area_soc")

# 2) latencia em ciclos
fig,ax=plt.subplots(figsize=(3.5,2.0))
lab=["Software\n(RV32I)","Coprocessador\n(via AXI4-Lite)","Núcleo\nfusion_node"]
cyc=[2234,179,22]
b=ax.bar(lab,cyc,color=[GREY,TEAL,ORANGE],width=0.6)
ax.set_yscale("log"); ax.set_ylabel("Ciclos por fusão (log)")
for r,c,us in zip(b,cyc,[82.7,6.6,0.81]):
    ax.text(r.get_x()+r.get_width()/2,c*1.15,f"{c} ciclos\n{us} µs",ha="center",fontsize=7)
ax.set_ylim(10,9000); ax.tick_params(axis="x",labelsize=7)
save(fig,"fig_latencia")

# 3) DFT: comparacao
fig,axs=plt.subplots(1,3,figsize=(3.5,1.9))
data=[("Área lógica\n(×10³ µm²)",44.75,59.20),("Slack\n(ns)",16.391,16.124),("Potência\n(mW)",1.387,1.393)]
for ax,(t,a,bv) in zip(axs,data):
    ax.bar(["sem","com"],[a,bv],color=[NAVY,ORANGE],width=0.6); ax.set_title(t,fontsize=7.5)
    ax.tick_params(labelsize=7)
    for i,v in enumerate([a,bv]): ax.text(i,v*1.02,(f"{v:.3f}" if v<5 else (f"{v:.2f}" if v<20 else f"{v:.1f}")),ha="center",fontsize=6.5)
    ax.set_ylim(0,max(a,bv)*1.25)
save(fig,"fig_dft")

# 4) memoria: macro x flip-flops
fig,ax=plt.subplots(figsize=(3.5,1.8))
lab=["Flip-flops\n(femto_ram_ff, 1 KB)","Macro OpenRAM\n(femto_sram, 8 KB)"]
perkb=[108557.066/1,101935.823/8]
b=ax.bar(lab,[p/1000 for p in perkb],color=[GREY,TEAL],width=0.55)
for r,p in zip(b,perkb): ax.text(r.get_x()+r.get_width()/2,p/1000+2,f"{p/1000:.1f}",ha="center",fontsize=7)
ax.set_ylabel("Área por KB (×10³ µm²)"); ax.set_ylim(0,125); ax.tick_params(axis="x",labelsize=7)
save(fig,"fig_memoria")

# 5) vies dos sensores a 100 mm
fig,ax=plt.subplots(figsize=(3.5,2.0))
x=[0,1,2.6,3.6]; m=[88.4,95.0,138.2,128.6]; s=[0.5,0.2,1.5,1.7]
c=[NAVY,NAVY,ORANGE,ORANGE]
ax.bar(x,m,yerr=s,color=c,width=0.75,capsize=3)
ax.axhline(100,ls="--",color="#333",lw=1); ax.text(4.25,101.5,"real: 100 mm",fontsize=7,ha="right")
ax.set_xticks(x); ax.set_xticklabels(["US\nsessão 1","US\nsessão 2","ToF\nsessão 1","ToF\nsessão 2"],fontsize=7)
ax.set_ylabel("Média medida (mm)"); ax.set_ylim(60,150)
save(fig,"fig_vies")
print("ok")

# 6) calibracao: erro antes e depois (dados da placa, 100-350 mm)
import numpy as np
d=np.array([100,150,200,250,300,350])
us_b=[3.0,-8.4,-4.9,-3.0,-4.0,-4.7]; us_a=[5.3,-5.5,-1.2,1.3,0.9,1.0]
tof_b=[23.8,33.7,23.2,23.0,28.8,24.2]; tof_a=[-3.3,7.0,-3.1,-3.0,3.2,-1.1]
fig,ax=plt.subplots(figsize=(3.5,2.1))
ax.axhspan(-7.5,7.5,color="#e8f6f6",zorder=0)
ax.plot(d,tof_b,"o--",color=ORANGE,ms=4,lw=1,label="ToF bruto")
ax.plot(d,us_b,"s--",color=NAVY,ms=4,lw=1,label="US bruto")
ax.plot(d,tof_a,"o-",color=ORANGE,ms=4,lw=1.6,label="ToF corrigido")
ax.plot(d,us_a,"s-",color=NAVY,ms=4,lw=1.6,label="US corrigido")
ax.axhline(0,color="#333",lw=0.8)
ax.set_xlabel("Distância real (mm)"); ax.set_ylabel("Erro (mm)")
ax.legend(fontsize=6,ncol=2,loc="upper right",frameon=False); ax.set_ylim(-12,40)
save(fig,"fig_calib")
