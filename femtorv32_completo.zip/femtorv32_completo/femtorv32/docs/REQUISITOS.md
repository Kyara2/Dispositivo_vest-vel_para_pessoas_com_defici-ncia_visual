# Requisitos do projeto e onde cada um é atendido

Este documento cruza as cinco exigências do projeto com o que já existe no repositório, o que ainda falta fazer e onde estão os números para o relatório.

## Resumo

| Exigência | Situação |
|---|---|
| 1. RISC-V + AXI4 + coprocessador + rotina de software + justificativa + mapa de registros | **Feito.** Falta escrever a justificativa no relatório (texto-base abaixo) |
| 2. UVM do coprocessador + métricas de latência e throughput | **UVM feita no projeto `fusion_core`** (gain, channel, variance, node, core). Métricas consolidadas abaixo |
| 3. Protótipo em FPGA + caracterização + vídeos | **Funcionando na Tang Primer 20K.** Faltam juntar os relatórios do Gowin e gravar os vídeos. **Atenção: Gowin não é Xilinx nem Lattice** (ver item 3) |
| 4. Síntese lógica no Genus + análise | **Feito** (`femto_soc`, 27 MHz). Números abaixo |
| 5. Síntese com DFT + caracterização | **Não feito ainda.** Fluxo pronto: `SYNTHESIS_WITH_DFT=yes MODULE=femto_soc ./exe.sh syn` |

## 1. RISC-V, AXI4 e coprocessador

- **Processador:** FemtoRV32 Quark (RV32I), `frontend/src/femtorv32_quark.v`.
- **Barramento:** AXI4-Lite. A ponte `femto_axil_master.v` é o mestre AXI do processador, e a `axil_xbar.v` é a interconexão. O AXI4-Lite é o perfil simplificado da especificação AXI4 da Arm (sem rajadas), adequado a registradores mapeados em memória. Se a disciplina exigir AXI4 completo com rajadas, é preciso combinar com o professor.
- **Coprocessador:** `periph_fusion.v`, um `fusion_node` (filtro de Kalman estático do paper de Conde et al., 2013) como escravo AXI4-Lite.
- **Rotina de software:** `frontend/firmware/soc/fusion.c`. A função `fusion_hw()` envia as medidas e variâncias e lê o resultado; a `fusion_sw()` é a mesma conta em software, bit a bit igual, usada para comparar. O `main.c` lê os sensores, aplica a calibração, chama as duas e compara.

### Justificativa da aceleração em hardware (texto-base)

O dispositivo assistivo precisa fundir as leituras de vários pares de sensores em tempo real, com pouca energia. A fusão exige uma **divisão** (o ganho K) e duas **multiplicações** por amostra. O RV32I não tem multiplicador nem divisor, então em software essas operações viram rotinas da libgcc de dezenas a centenas de ciclos.

Medido na placa, a 27 MHz:
- o software leva **2.239 ciclos** (82,9 µs) por fusão;
- o núcleo em hardware faz a mesma conta em **22 ciclos** (0,81 µs), cerca de **102 vezes** mais rápido;
- visto pelo programa, incluindo o barramento, o coprocessador leva **247 ciclos** (9,1 µs), cerca de **9 vezes** mais rápido.

Além do tempo, o processador fica livre durante a fusão, e o resultado é bit a bit idêntico ao do software. O custo é pequeno: o `fusion_node` ocupa 9.464 µm², menos da metade do processador (21.928 µm²). Isso torna viável replicar o núcleo para os 8 canais do `fusion_core`.

### Mapa de registros (base 0x0040_0400)

| Offset | Nome | Acesso | Descrição |
|---|---|---|---|
| 0x00 | Q1 | RW | medida 1 (ultrassom), mm, 16 bits |
| 0x04 | Q2 | RW | medida 2 (laser ToF), mm, 16 bits |
| 0x08 | SIGMA1_SQ | RW | variância do sensor 1, mm² |
| 0x0C | SIGMA2_SQ | RW | variância do sensor 2, mm² |
| 0x10 | CTRL | W | bit 0 = START (ignorado se ocupado) |
| 0x14 | STATUS | R | bit 0 = busy, bit 1 = done (vai a 1 no resultado; zera no START) |
| 0x18 | K | R | ganho, UQ1.15 (32768 = 1,0) |
| 0x1C | QHAT | R | estimativa fundida, mm |
| 0x20 | SIGMA_NEW | R | variância após a fusão, mm² |
| 0x24 | LAT | R | ciclos do START até o resultado (só o núcleo) |
| 0x28 | ID | R | 0xF0510001 |

Mapa do SoC: RAM em 0x000000 (16 KB), SYSINFO em 0x400000, UART em 0x400100, HC-SR04 em 0x400200, I2C em 0x400300 e FUSION em 0x400400. Os registradores de cada periférico estão no cabeçalho do respectivo `.v` e em `frontend/firmware/soc/soc.h`.

## 2. UVM e métricas

A UVM foi feita no projeto `fusion_core`, com um ambiente por módulo em `frontend/uvm/`: `fusion_gain`, `fusion_channel`, `fusion_variance`, `fusion_node` e `fusion_core`. Cada um tem agente, scoreboard com modelo de referência e cobertura. O `fusion_node` usado aqui é **o mesmo RTL**, sem alteração, então essa verificação vale para o coprocessador do SoC. No relatório, mostre os resultados de PASS e cobertura desses ambientes.

Além da UVM, este repositório tem mais duas verificações do coprocessador integrado:
- o autoteste de 64 vetores, que compara hardware e software a cada boot, na simulação e na placa;
- a simulação de sistema (`MODULE=femto_soc ./exe.sh pre`), com os sensores modelados.

### Latência e throughput

Medidos em simulação (núcleo) e na placa (integração), a 27 MHz:

| Nível | Latência | Throughput |
|---|---|---|
| `fusion_gain` (divisor sequencial) | 18 ciclos | 1 resultado a cada 18 ciclos (1,5 M/s) |
| `fusion_channel` | 4 ciclos | 1 resultado por ciclo |
| `fusion_variance` | 3 ciclos | 1 resultado por ciclo |
| `fusion_node` (ganho, depois canal e variância em paralelo) | 22 ciclos, 0,81 µs | 1 fusão a cada 22 ciclos, **1,23 M fusões/s** |
| Transferência AXI4-Lite (8 acessos: 4 escritas, START, espera, 3 leituras) | ~225 ciclos no total, ~28 por acesso com as instruções da CPU | limitada pela CPU, que faz um acesso por vez |
| Integração, visto pelo software (`fusion_hw`) | 247 ciclos, 9,1 µs | **109 mil fusões/s** |
| Software puro no RV32I (`fusion_sw`) | 2.239 ciclos, 82,9 µs | 12 mil fusões/s |

Com 8 canais no `fusion_core`, os nós trabalham em paralelo e o throughput do núcleo sobe para ~9,8 M fusões/s. O gargalo passa a ser a transferência pelo barramento, que pode ser reduzida empacotando dois valores de 16 bits por palavra.

## 3. Protótipo em FPGA

O SoC completo roda na **Sipeed Tang Primer 20K (Gowin GW2A-18C)**, a 27 MHz. Na placa:
- a RAM é BSRAM com o firmware embutido;
- o ultrassom (HC-SR04) e o laser (VL53L0X) são lidos pelo SoC;
- o resultado aparece na UART a 9600 baud.

Para gerar e gravar: `fpga/README.md`.

**Atenção:** o enunciado diz "podem usar Xilinx ou Lattice", e a Gowin não é nenhuma das duas. Como o enunciado também aceita "FPGA próprio", vale **confirmar com o professor** se a Tang Primer 20K é aceita. Se não for, as alternativas são o labremoto (Xilinx) ou a iCESugar (Lattice iCE40UP5K), na qual o núcleo de fusão já rodou. O RTL do SoC é o mesmo; muda só o top, os pinos e a RAM (BSRAM da iCE40).

**Caracterização** (falta coletar). Depois de `./fpga/tang_primer_20k/build.sh build`, os relatórios ficam em `fpga/tang_primer_20k/femto_soc_tp20k/impl/`:

| Item | Arquivo |
|---|---|
| Recursos (LUT, FF, BSRAM, DSP) | `gwsynthesis/femto_soc_tp20k_syn.rpt.html` e `pnr/femto_soc_tp20k.rpt.txt` |
| Timing (Fmax, slack) | `pnr/femto_soc_tp20k.tr.html` |
| Energia | `pnr/femto_soc_tp20k.power.html` |
| Latência e throughput | os ciclos impressos na UART (tabela do item 2) |

**Vídeos** (falta gravar), sugestão:
1. o build e a gravação;
2. o terminal mostrando o autoteste e as leituras;
3. movendo o obstáculo, com `US`, `ToF`, `q` e `dif` mudando e `ok` em todas as linhas;
4. o LED de teste indicando hardware igual ao software.

## 4. Síntese lógica no Genus

Resultados do `femto_soc` a 27 MHz, GPDK045, corner slow:
- **Timing:** atendido com 16,4 ns de folga. O caminho crítico vai da saída da macro de SRAM (borda de descida) até o registrador de leitura da ponte AXI.
- **Área:** 249.041 µm². A RAM (4 macros) ocupa 82%, o FemtoRV32 8,8%, o coprocessador 5,1% (o `fusion_node` sozinho tem 9.464 µm²) e os demais periféricos menos de 5%.
- **Potência:** ~1,4 mW (estimativa vetorless).
- **DRC:** só max_capacitance nas saídas das macros, um artefato do modelo da OpenRAM documentado em `tech/sram/README.md`.

Os relatórios ficam em `backend/synthesis/reports/femto_soc/`.

## 5. Síntese com DFT (falta fazer)

O fluxo de DFT veio do projeto de referência e está pronto no `synthesis.tcl`. Ele usa scan com multiplexador (`muxed_scan`), cria a porta de shift enable `SE`, verifica as regras de DFT antes e depois da síntese, monta e conecta as cadeias de scan, roda a otimização incremental e gera os relatórios e arquivos de ATPG.

Para rodar, sem sobrescrever a síntese sem DFT:

```bash
SYNTHESIS_WITH_DFT=yes MODULE=femto_soc ./exe.sh syn
```

Os resultados ficam em `backend/synthesis/reports/femto_soc_dft/` e `deliverables/femto_soc_dft/`. Os relatórios de DFT são:
- `_scan_chains.rpt`: cadeias e número de flip-flops;
- `_dft_rules.rpt`: violações;
- `_scan_registers.rpt`;
- `_testability.rpt`.

Os arquivos de ATPG para o Modus ficam em `deliverables/femto_soc_dft/atpg/`.

O que esperar e analisar:
- **Overhead:** os flip-flops viram flip-flops de scan (área maior), e aparecem as portas `SE`, `scan_in` e `scan_out`. Compare área, timing e potência com a síntese sem DFT.
- **Reset:** o único reset assíncrono é o sincronizador de reset, e ele vem direto do pino `rst_n`, que é controlável no teste. Não deve aparecer violação por isso.
- **Macros de SRAM:** são caixas-pretas e não entram nas cadeias. A lógica ao redor delas fica parcialmente não testável; isso deve ser citado como limitação. Em projetos reais as macros têm BIST próprio.
- **Simulação e FPGA:** a netlist com DFT é só para essa análise; o testbench e a FPGA usam o design sem DFT.

Se aparecerem violações no `_dft_rules.rpt`, mande o relatório.
