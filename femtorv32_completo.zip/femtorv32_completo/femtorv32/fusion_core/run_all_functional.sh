#!/bin/bash
# run_all_functional.sh -- roda o testbench funcional (pre-synthesis, sem
# UVM) dos 5 modulos, um atras do outro, em lote (sem GUI), e imprime um
# resumo PASS/FAIL no final. Chame a partir da raiz do projeto:
#
#   ./run_all_functional.sh

set -u
declare -a RESULTS_SUMMARY
TOTAL=0
FAILED=0

for MOD in fusion_channel fusion_variance fusion_gain fusion_core fusion_node; do
    TOTAL=$((TOTAL+1))
    echo "=============================================================="
    echo ">> MODULE=$MOD  (functional / pre-synthesis)"
    echo "=============================================================="
    MODULE=$MOD ./exe.sh pre > /tmp/${MOD}_pre.log 2>&1
    if grep -q "FUNCTIONAL_RESULT: PASS" /tmp/${MOD}_pre.log; then
        RESULTS_SUMMARY+=("PASS  $MOD")
    else
        RESULTS_SUMMARY+=("FAIL  $MOD   (ver /tmp/${MOD}_pre.log)")
        FAILED=$((FAILED+1))
    fi
done

echo
echo "=============================================================="
echo "RESUMO ($((TOTAL-FAILED))/${TOTAL} PASS)"
echo "=============================================================="
for line in "${RESULTS_SUMMARY[@]}"; do
    echo "$line"
done

if [ $FAILED -eq 0 ]; then
    echo; echo "TUDO PASSOU."; exit 0
else
    echo; echo "$FAILED modulo(s) falharam -- confere os logs apontados acima."; exit 1
fi
