#!/bin/bash
# run_all_modules.sh -- roda TODOS os testes UVM dos 5 modulos, um atras do
# outro, e no final imprime um resumo PASS/FAIL de cada um. Chame a partir
# da raiz do projeto (onde esta' o exe.sh):
#
#   ./run_all_modules.sh
#
# Para rodar com cobertura (fica mais lento):
#   COVERAGE=all ./run_all_modules.sh

set -u
declare -A TESTS
TESTS[fusion_channel]="fusion_sanity_test fusion_random_test fusion_factory_test fusion_coverage_test"
TESTS[fusion_variance]="fusion_sanity_test fusion_random_test fusion_factory_test fusion_coverage_test"
TESTS[fusion_gain]="fusion_sanity_test fusion_random_test fusion_factory_test fusion_coverage_test"
TESTS[fusion_core]="fusion_sanity_test fusion_random_test fusion_factory_test fusion_coverage_test fusion_arbitration_test"
TESTS[fusion_node]="fusion_sanity_test fusion_random_test fusion_factory_test fusion_vseq_test fusion_coverage_test"

declare -a RESULTS_SUMMARY
TOTAL=0
FAILED=0

for MOD in fusion_channel fusion_variance fusion_gain fusion_core fusion_node; do
    for T in ${TESTS[$MOD]}; do
        TOTAL=$((TOTAL+1))
        echo "=============================================================="
        echo ">> MODULE=$MOD  TEST=$T"
        echo "=============================================================="
        MODULE=$MOD ./exe.sh uvm "$T" > /tmp/${MOD}_${T}.log 2>&1
        RPT="backend/uvm/${MOD}/reports/${T}_result.txt"
        if [ -f "$RPT" ] && grep -q "FUSION_UVM_RESULT: PASS" "$RPT"; then
            RESULTS_SUMMARY+=("PASS  $MOD / $T")
        else
            RESULTS_SUMMARY+=("FAIL  $MOD / $T   (ver /tmp/${MOD}_${T}.log e $RPT)")
            FAILED=$((FAILED+1))
        fi
    done
done

echo
echo "=============================================================="
echo "RESUMO ($((TOTAL-FAILED))/${TOTAL} PASS)"
echo "=============================================================="
for line in "${RESULTS_SUMMARY[@]}"; do
    echo "$line"
done

if [ $FAILED -eq 0 ]; then
    echo
    echo "TUDO PASSOU."
    exit 0
else
    echo
    echo "$FAILED teste(s) falharam -- confere os logs apontados acima."
    exit 1
fi
