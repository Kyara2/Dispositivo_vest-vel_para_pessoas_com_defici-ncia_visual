# UVM do fusion_core -- guia rapido

Verifica o **canal 0** do `fusion_core` (RTL sem nenhuma alteracao). Os 8
canais do core sao copias independentes do mesmo `fusion_ch` (generate em
`fusion_core.sv`, sem logica compartilhada entre eles) -- provar o canal 0
correto prova os 8. `+define+FUSION_N=8` na linha do xrun (ou `FUSION_N=8`
antes do `./exe.sh`) recompila para os 8 canais, sem mudar nenhum arquivo.

## Rodar um teste (modo lote, sem GUI -- use isso na maior parte do tempo)

A partir da raiz do projeto (onde fica o `exe.sh`):

```bash
./exe.sh uvm fusion_sanity_test
./exe.sh uvm fusion_random_test
```

Variaveis de ambiente opcionais (exportar antes, ou na mesma linha):

```bash
NUM_FRAMES=10000 ./exe.sh uvm fusion_random_test
CALIB_FILE=frontend/uvm/data/calibration_example.txt ./exe.sh uvm fusion_calibrated_test
COVERAGE=all ./exe.sh uvm fusion_coverage_test
```

## Rodar os 9 de uma vez

```bash
./backend/uvm/scripts/run_all.sh
```

## Debugar um teste com GUI (SimVision)

```bash
./exe.sh uvm fusion_random_test gui
```

## Onde ficam os resultados

- `backend/uvm/reports/<teste>.log` -- log completo do xrun/UVM
- `backend/uvm/reports/<teste>_result.txt` -- uma linha: PASS ou FAIL
- `backend/uvm/reports/<teste>_scoreboard.rpt` -- contagens, latencia medida,
  maior erro numerico vs. as eq. (6)/(7) do paper
- `backend/uvm/work/` -- `xcelium.d`, `waves.shm` etc. (artefatos do xrun)

## Os 9 testes

| Teste | O que faz | Conceito (aula) |
|---|---|---|
| `fusion_sanity_test` | ~10 frames dirigidos: entradas iguais, K=0/0.5/1.0, empate de arredondamento | estimulos dirigidos (Aula 6) |
| `fusion_random_test` | N frames aleatorios na faixa normal (200-1600 mm) | estimulos aleatorios/constraints (Aula 6) |
| `fusion_boundary_test` | 500 frames nos extremos via `fusion_item_corner` + `randomize() with` | heranca de sequence_item (Aula 6) |
| `fusion_reset_test` | trafego -> reset de 4 ciclos NO MEIO do pipeline -> trafego de novo | integridade de reset |
| `fusion_factory_test` | mesmos extremos do boundary, mas via **factory override** (`set_type_override`) | factory override (Aula 6) |
| `fusion_arbitration_test` | 2 sequences concorrentes com `set_arbitration(WEIGHTED)` e prioridade no `.start()`, + `grab()`/`ungrab()` furando a fila | arbitragem/acesso exclusivo (Aula 10/11) |
| `fusion_vseq_test` | **virtual sequence** orquestrando sequences dirigida+aleatoria no sequencer real | virtual sequence (Aula 10/11) |
| `fusion_coverage_test` | random+boundary+assimetrica -> fecha a **cobertura funcional** | covergroup/cross (Aula 16) |
| `fusion_calibrated_test` | todo frame com K vindo da calibracao (arquivo ou placeholder); conferido tambem contra a eq.(6) | calibracao de sensores (eq. 11 do paper) |

Todo teste confere, para cada frame: (1) bit-a-bit contra um modelo em
software que repete a conta exata do RTL, (2) contra a eq. (7)/(9) do paper
em aritmetica real (so' quando K esta dentro do "contrato" K<=1.0 -- fora
disso so' a checagem bit-a-bit vale, porque a formula real da eq.7 nao
satura e o RTL satura) e (3) a latencia (tem que ser sempre 3 ciclos). 4
assertions (SVA) em `fusion_if.sv` rodam em paralelo em qualquer teste.

## Calibracao dos sensores (eq. 11 do paper)

`+CALIB_FILE=<arquivo>` liga a leitura de medidas reais para calcular K.
Formato -- uma amostra por linha, sensor parado olhando pra um alvo a
distancia FIXA e conhecida (e' dai que vem o "ruido" = sigma de cada sensor;
o professor pediu 80 linhas assim):

```
# comentario (linha ignorada)
<leitura_us_mm> <leitura_ir_mm>
<leitura_us_mm> <leitura_ir_mm>
...
```

Exemplo (dados FICTICIOS, so' para testar o formato) em
`frontend/uvm/data/calibration_example.txt`. Sem `+CALIB_FILE=` (ou se o
arquivo nao abrir / tiver menos de 2 amostras), cai num sigma PLACEHOLDER e
avisa com `uvm_warning`. Quando tiver as 80 medidas de verdade, so' salvar
nesse mesmo formato e rodar:

```bash
CALIB_FILE=/caminho/para/suas_medidas.txt ./exe.sh uvm fusion_calibrated_test
```

## Cobertura

- **Funcional, numero rapido** (Aula 16): sempre coletada por
  `fusion_coverage` (`uvm_subscriber` + `covergroup`), o `%` sai no log mesmo
  sem nenhuma flag extra (procure por `COV_REPORT`). Serve para conferir
  rapido, mas nao mostra QUAL bin faltou nem cobertura de codigo -- pra isso
  e' o IMC abaixo.

- **De codigo + funcional, com o Cadence IMC** (o que o professor pediu):

  **1) Gerar a base de cobertura de cada teste** (`-covtest` da' um escopo
  separado por teste em `cov_work/scope/<teste>`, dentro de
  `backend/uvm/work/`, para nao se sobrescreverem):
  ```bash
  COVERAGE=all ./exe.sh uvm fusion_random_test
  COVERAGE=all ./exe.sh uvm fusion_boundary_test
  COVERAGE=all ./exe.sh uvm fusion_coverage_test     # random + boundary + assimetrica
  ```
  `COVERAGE=all` liga cobertura de codigo (block/branch/toggle/expression --
  nao ha FSM nesse RTL) E funcional (os covergroups) ao mesmo tempo. Se quiser
  so' uma das duas: `COVERAGE=functional` ou `COVERAGE=block:expr:toggle`.

  **2) Abrir o IMC:**
  ```bash
  cd backend/uvm/work
  imc -gui &
  ```
  Atencao: a versao do IMC tem que bater com a do Xcelium -- aqui e' o
  `VMANAGER2603` (ja esta no `PATH` do `run.sh`; se o `imc` nao abrir, o
  problema e' esse, igual aconteceu antes com o `xrun`).

  **3) Importar uma base isolada** (pra ver um teste por vez): File → Open
  Database → aponta para `cov_work/scope/fusion_coverage_test` (ou o nome do
  teste que quiser). A tela principal (Summary) mostra o % geral de
  cobertura de codigo e funcional lado a lado.

  **4) Mesclar varios testes num unico resultado acumulado** (pra mostrar a
  evolucao, igual o exemplo da ULA da Aula 16 -- random sozinha deixa o cross
  baixo, + boundary melhora, + assimetrica fecha): File → Merge Databases →
  selecionar as 3 pastas (`fusion_random_test`, `fusion_boundary_test`,
  `fusion_coverage_test`) → dar um nome pro merge (ex.: `merged_all`) → Merge.
  O resultado mesclado some os bins batidos por qualquer um dos 3 testes.

  **5) O que vale a pena capturar pros slides:**
  - A tela **Summary** (% geral de cobertura de codigo e funcional) de cada
    base isolada e da mesclada -- pra mostrar a evolucao numerica.
  - Dentro de **Groups** (cobertura funcional) → `cg_fusion` → o cross
    `x_diff_k`: abre a tabela de bins e mostra quais combinacoes (diferenca
    extrema x ganho extremo) ainda faltavam SO' com `fusion_random_test`, e
    como ficam cobertas depois do merge com `fusion_coverage_test` (que inclui
    a `fusion_asym_seq`, pensada exatamente pra fechar esse cross).
  - Dentro de **Code Coverage** → Toggle: como o DUT so' tem ~110 registros
    (canal 0 do `fusion_ch`), esperado chegar perto de 100% de toggle rapido;
    se sobrar algo descoberto, e' um bom candidato pra UNR (analise de codigo
    nao alcancavel) -- o IMC marca isso na propria tela.
