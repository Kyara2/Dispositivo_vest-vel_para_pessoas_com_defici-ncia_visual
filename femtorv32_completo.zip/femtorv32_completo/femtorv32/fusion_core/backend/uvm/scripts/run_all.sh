#!/bin/bash
# ============================================================================
# run_all.sh -- roda os 9 testes UVM do fusion_core em sequencia, em modo
# LOTE (sem GUI), e imprime um resumo PASS/FAIL de cada um.
#
# Uso (a partir da raiz do projeto, onde fica o exe.sh):
#   ./backend/uvm/scripts/run_all.sh
#
# Variaveis de ambiente aceitas (ver run.sh): NUM_FRAMES, FUSION_N,
# CALIB_FILE, COVERAGE. Ex.:
#   CALIB_FILE=frontend/uvm/data/calibration_example.txt ./backend/uvm/scripts/run_all.sh
# ============================================================================
set -u
cd "$(dirname "$0")/../../.."   # volta para a raiz do projeto (onde esta o exe.sh)

TESTS="fusion_sanity_test fusion_random_test fusion_boundary_test fusion_reset_test fusion_factory_test fusion_arbitration_test fusion_vseq_test fusion_coverage_test fusion_calibrated_test"
RPT_DIR="backend/uvm/reports"

echo "===================== REGRESSAO UVM - fusion_core ====================="
for T in $TESTS; do
    echo ">> Rodando $T ..."
    ./exe.sh uvm $T > /tmp/${T}.exe.log 2>&1
    R=$(grep -m1 "FUSION_UVM_RESULT" ${RPT_DIR}/${T}_result.txt 2>/dev/null)
    if [ -z "$R" ]; then
        echo "   $T -> SEM RESULTADO (confira /tmp/${T}.exe.log e ${RPT_DIR}/${T}.log)"
    else
        echo "   $T -> $R"
    fi
done
echo "========================================================================"
echo "Logs completos em:       ${RPT_DIR}/<teste>.log"
echo "Resumo do scoreboard em: ${RPT_DIR}/<teste>_scoreboard.rpt"
