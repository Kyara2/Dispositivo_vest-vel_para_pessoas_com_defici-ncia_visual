set PROJECT_DIR $env(PROJECT_DIR)
# database -open waves -vcd -into ${PROJECT_DIR}/backend/synthesis/work/vcd_file.vcd
# probe -create [scope -top] -all -depth all
# run;


