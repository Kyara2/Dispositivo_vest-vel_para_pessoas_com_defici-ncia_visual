# Last update: 2026/05/09
# Author: Kyara Esteves de Sousa
#-----------------------------------------------------------------------------
# General Comments
#-----------------------------------------------------------------------------
puts "Loading synthesis.tcl into Genus"

#-----------------------------------------------------------------------------
# Main Custom Variables Design Dependent (set local)
#-----------------------------------------------------------------------------
set PROJECT_DIR $env(PROJECT_DIR)
set TECH_DIR $env(TECH_DIR)
set DESIGN $env(DESIGN)
set HDL_NAME $env(HDL_NAME)
set HDL_LIBS $env(HDL_LIBS)
set HDL_SRC $env(HDL_SRC)
set TECH_DIR $env(TECH_DIR)
set HDL_TYPE $env(HDL_TYPE)
set GENERATE_VCD $env(GENERATE_VCD)
set SYNTHESIS_WITH_DFT $env(SYNTHESIS_WITH_DFT)
set LIBRARY_SPEED $env(LIBRARY_SPEED)
set CLK_PERIOD $env(CLK_PERIOD)
set WORST_LIB_NAME $env(WORST_LIB_NAME)
set BEST_LIB_NAME $env(BEST_LIB_NAME)
set HDL_LIBS $env(HDL_LIBS)
set HDL_EXTENSION $env(HDL_EXTENSION) 
set SYNTHESIS_LIBRARY $env(SYNTHESIS_LIBRARY)

set HDL_SRC $env(HDL_SRC)

set FRONTEND_DIR $env(FRONTEND_DIR)

set DFT_STRING $env(DFT_STRING)
set HDL_EXTENSION $env(HDL_EXTENSION)

# set PERIOD_FROM_SYNTHESIS $env(PERIOD_FROM_SYNTHESIS)

set INTERCONNECT_MODE ple ; #verificar ; # ple <=> Physical Layout Estimation

#-----------------------------------------------------------------------------
# MAIN Custom Variables to be used in SDC (constraints file)
#-----------------------------------------------------------------------------
set MAIN_CLOCK_NAME clk
set MAIN_RST_NAME rst_n ; # fusion_core/fusion_ch reset port name (era "resetn", nome do picorv32 -- bug)
#set MAIN_RST_NAME resetn ; # picorv32 reset port name (projeto anterior)
set BEST_LIB_OPERATING_CONDITION PVT_1P32V_0C
set WORST_LIB_OPERATING_CONDITION PVT_0P9V_125C

# Some possible frequencies and equivalent interval periods
# frequency = 50.00 Mhz  <=> period_clk = 20 ns
# frequency = 100.00 MHz <=> period_clk = 10 ns
# frequency = 133.00 MHz <=> period_clk = 7.5 ns
# frequency = 200.00 Mhz <=> period_clk = 5 ns
# frequency = 250.00 Mhz <=> period_clk = 4 ns
# frequency = 500.00 MHz <=> period_clk = 2 ns
# frequency = 500.00 MHz <=> period_clk = 2.5 ns
# frequency = 1.00 GHz   <=> period_clk = 1 ns

set clk_period $env(CLK_PERIOD) ; 
set clk_uncertainty 0.05 ;#0.25 ;# ns (?a guess?)
set clk_latency 0.10 ;#0.35 ;# ns (?a guess?)
set in_delay 0.30 ;#1 ;# ns
set out_delay 0.30 ;#2.958 ;#ns 
set out_load 0.045 ;#pF 
set slew "146 164 264 252" ;#minimum rise, minimum fall, maximum rise and maximum fall 
set slew_min_rise 0.146 ;# ns
set slew_min_fall 0.164 ;# ns
set slew_max_rise 0.264 ;# ns
set slew_max_fall 0.252 ;# ns
#
set WORST_LIST $env(WORST_LIST)
set BEST_LIST $env(BEST_LIST)
set LEF_LIST {gsclib045_tech.lef gsclib045_macro.lef}
set WORST_CAP_LIST ${TECH_DIR}/gpdk045_v_6_0/soce/gpdk045.basic.CapTbl
set QRC_LIST ${TECH_DIR}/gpdk045_v_6_0/qrc/rcworst/qrcTechFile

#-----------------------------------------------------------------------------
# Load Path File
#-----------------------------------------------------------------------------
source ${PROJECT_DIR}/backend/synthesis/scripts/common/path.tcl

#-----------------------------------------------------------------------------
# Load Tech File
#-----------------------------------------------------------------------------
source ${SCRIPT_DIR}/common/tech.tcl

#-----------------------------------------------------------------------------
# Analyze RTL source (manually set; file_list.tcl is not covered in ELC1054)
#-----------------------------------------------------------------------------
set_db init_hdl_search_path "${DEV_DIR} ${FRONTEND_DIR} ${HDL_SRC}"

# MODULE_FILES vem do run.sh (lista de .sv SO' do modulo que MODULE pede --
# ex: "fusion_channel.sv fusion_core.sv" para fusion_core, so'
# "fusion_gain.sv" para fusion_gain). Antes isso era um glob pegando TODOS
# os .sv de frontend/src/, o que sintetizava sempre o mesmo top (bug:
# sintetizar fusion_channel acabava incluindo/promovendo fusion_core).
set MODULE_FILES $env(MODULE_FILES)
set RTL_FILES {}
foreach f $MODULE_FILES {
    lappend RTL_FILES ${HDL_SRC}/${f}
}

puts "List of RTL files: $RTL_FILES";

if {$HDL_TYPE eq "vhdl"} {
    # In the vhdl the order of the modules is important
    set RTL_FILES [list \
        ${HDL_SRC}/fpupack.vhd \
        ${HDL_SRC}/addsubfsm_v6.vhd \
        ${HDL_SRC}/multiplierfsm_v2.vhd \
        ${HDL_SRC}/cnn_conv4.vhd \
    ]

    puts "List of RTL files: $RTL_FILES"
	read_hdl -language vhdl $RTL_FILES

} elseif {$HDL_TYPE eq "verilog" } {

	puts "List of RTL files: $RTL_FILES"
	read_hdl -language v2001 $RTL_FILES
	
} elseif {$HDL_TYPE eq "system_verilog" } {

    puts "List of RTL files: $RTL_FILES"
    read_hdl -language sv $RTL_FILES    
    
}

# Generate SystemVerilog wrapper for the vhdl post synthesis simulation
#::legacy::set_attribute hdl_sv_module_wrapper true

#-----------------------------------------------------------------------------
# Elaborate Design
#-----------------------------------------------------------------------------
elaborate ${HDL_NAME}
set_top_module ${HDL_NAME}
check_design -unresolved ${HDL_NAME}
get_db current_design
check_library

#-----------------------------------------------------------------------------
# Constraints
#-----------------------------------------------------------------------------
# Read Synopsys Design Constraints file
read_sdc ${BACKEND_DIR}/synthesis/constraints/design_constraints.sdc
#read_sdc ${BACKEND_DIR}/synthesis/constraints/${HDL_NAME}.sdc

# DFT section -----------------------------------------------------------------
if { $SYNTHESIS_WITH_DFT eq "yes" } {
	# ===== DFT CONFIGURATION =====
	puts "Configuring DFT..."

	# Habilitar rastreamento de linha/coluna para violações DFT
	set_db hdl_track_filename_row_col true

	# Escolher estilo muxed_scan (padrão)
	# muxed_scan: usa multiplexador + FF (mais comum, menor overhead)
	# clocked_scan: usa lógica síncrona (menos comum)
	set_db dft_scan_style muxed_scan

	# Prefixo para células DFT
	# Todas as células DFT adicionadas terão prefixo "dft_"
	# Ex: dft_scan_cell_0, dft_scan_cell_1, ...
	set_db dft_prefix dft_
	
	# ---- Definir sinal de test mode (OPCIONAL) ----
	# test_mode ativa o modo de teste (quando alto)
	# Durante teste: os FFs funcionam normalmente
	# Durante scan: os FFs funcionam como registrador de deslocamento
	# define_test_mode -name TM -active high -create_port TM
	# puts "  Test Mode: TM (active high)"

	# OBRIGATÓRIO: Definir sinal Shift Enable
	# shift_enable habilita o deslocamento dos dados pela scan chain
	# Este é o sinal OBRIGATÓRIO para scan
	define_shift_enable -name SE -active high -create_port SE

	puts "DFT configuration complete"
}
# End of DFT section ----------------------------------------------------------

report timing -lint

# Open Graphic Interface of the Cadence
gui_show

#-----------------------------------------------------------------------------
# Pos "Elaborate" Attributes (manually set)
#-----------------------------------------------------------------------------
set_db auto_ungroup none ;# (none|both) ungrouping will not be performed

# DFT section -----------------------------------------------------------------
if { $SYNTHESIS_WITH_DFT eq "yes" } {
	# Verificar regras DFT antes de síntese
	puts "Checking DFT rules (before synthesis)..."
	check_dft_rules
	
	# Se houver violações, podem ser corrigidas automaticamente
	# (Opcional - Genus pode tentar corrigir)
	# fix_dft_violations

}
# End of DFT section ----------------------------------------------------------

#-----------------------------------------------------------------------------
# Synthesis Effort
#-----------------------------------------------------------------------------
# Efforts levels: low, medium, high
set_db syn_generic_effort medium ;#medium 
set_db syn_map_effort medium ;#medium
set_db syn_opt_effort medium ;#medium

#-----------------------------------------------------------------------------
# Synthesizing to Generic  (technology independent)
#-----------------------------------------------------------------------------
syn_generic ${HDL_NAME} 

#-----------------------------------------------------------------------------
# Synthesizing to gates of the library - mapping to the library
#-----------------------------------------------------------------------------
syn_map ${HDL_NAME} 

#-----------------------------------------------------------------------------
# Incremental Optimization of the netlist (area, timing, power) 
#-----------------------------------------------------------------------------

# syn_opt ${HDL_NAME} ; # --- without optimizations -----------------------------------
syn_opt ${HDL_NAME} ; # --- with optimizations -----------------------------------


# DFT section -----------------------------------------------------------------
if { $SYNTHESIS_WITH_DFT eq "yes" } {
	# Verificar regras DFT após síntese
	puts "Checking DFT rules (after synthesis)..."
	check_dft_rules

	# Configurar scan chains
	puts "Configuring scan chains..."
	set_db design:${HDL_NAME} .dft_min_number_of_scan_chains 1

	# OPCIONAL - Para customizar a chain manualmente, mas connect_scan_chains torna ele redundante
	#define_scan_chain -name top_chain \
    #-sdi scan_in \
    #-sdo scan_out \
    #-shift_enable SE \
    #-create_ports

	connect_scan_chains -auto_create_chains

	# Otimização incremental pós-DFT
	puts "Running incremental optimization..."
	syn_opt -incremental

	# Mostrar scan chains criadas
	report_scan_chains
} 


# End of DFT section ----------------------------------------------------------

get_db insts .base_cell.name -u ;# List all cell names used in the current design.

#----------------------------------------------------------
# load and read vcd file from simulation from the netlist
#----------------------------------------------------------
if { $GENERATE_VCD eq "yes" } {
    read_stimulus -format vcd -allow_n_nets vcd_file.vcd
}

#-----------------------------------------------------------------------------
# Preparing and generating output data (reports, verilog netlist) --> REPORTS, NEhLIST
#-----------------------------------------------------------------------------


report_design_rules    > ${RPT_DIR}/${HDL_NAME}_drc.rpt

report_gates           > ${RPT_DIR}/${HDL_NAME}_gates.rpt

report_timing          > ${RPT_DIR}/${HDL_NAME}_timing.rpt

report_power           > ${RPT_DIR}/${HDL_NAME}_power.rpt

report_area            > ${RPT_DIR}/${HDL_NAME}_area.rpt

report_qor             > ${RPT_DIR}/${HDL_NAME}_qor.rpt

report_hierarchy       > ${RPT_DIR}/${HDL_NAME}_hierarchy.rpt


write_hdl \
    -language v2001 \
    ${HDL_NAME} > ${DEV_DIR}/${HDL_NAME}_netlist.v
    

# Generate SystemVerilog wrapper for the vhdl post synthesis simulation
#write_sv_wrapper \
#    ${HDL_NAME} > ${DEV_DIR}/${HDL_NAME}_wrapper.sv
    

# Generate SDF(Standard Dealy Format) file for the post-synthesis simulation with real delays
write_sdf -edge check_edge -setuphold merge_always -nonegchecks -recrem split -version 3.0 -design ${HDL_NAME} > ${DEV_DIR}/${HDL_NAME}_worsts.sdf

# DFT section -----------------------------------------------------------------
if { $SYNTHESIS_WITH_DFT eq "yes" } {
	    
	    write_sdc > ${DEV_DIR}/${HDL_NAME}_constraints.sdc
	    
	    # define_scan_chain -analyze
	    
	    # write_scandef > ${DEV_DIR}/${HDL_NAME}_scanDEF.scandef
	    
	    write_dft_atpg -library ${LIB_DIR}/${SYNTHESIS_LIBRARY}.v

}    
# End of DFT section ---------------------------------------------------------- 

# Write synthesis specifications ---------------------------------

set fp [open "${RPT_DIR}/${HDL_NAME}_specifications.rpt" w+]

puts $fp "DESIGN:             $DESIGN"
puts $fp "HDL_NAME:           $HDL_NAME"
puts $fp "CLK_PERIOD:         $CLK_PERIOD"
puts $fp "TECH_DIR:           $TECH_DIR"
puts $fp "HDL_TYPE:           $HDL_TYPE"
puts $fp "SYNTHESIS_WITH_DFT: $SYNTHESIS_WITH_DFT"
puts $fp "LIBRARY_SPEED:      $LIBRARY_SPEED"
puts $fp "SYNTHESIS_LIBRARY:  $SYNTHESIS_LIBRARY"

puts $fp "clk_uncertainty:    $clk_uncertainty "
puts $fp "clk_latency:        $clk_latency "
puts $fp "in_delay:           $in_delay "
puts $fp "out_delay:          $out_delay "
puts $fp "out_load:           $out_load "
puts $fp "slew:               $slew " 
puts $fp "slew_min_rise:      $slew_min_rise "
puts $fp "slew_min_fall:      $slew_min_fall "
puts $fp "slew_max_rise:      $slew_max_rise "
puts $fp "slew_max_fall:      $slew_max_fall "

#puts $fp "WORST_LIB_NAME:     $WORST_LIB_NAME"
#puts $fp "BEST_LIB_NAME:      $BEST_LIB_NAME"
#puts $fp "GENERATE_VCD:       $GENERATE_VCD"
#puts $fp "HDL_LIBS:           $HDL_LIBS"
#puts $fp "HDL_EXTENSION:      $HDL_EXTENSION"

close $fp

# End of write synthesis specifications ----------------------------

# Save snapshot of the schematic view -----------------------------------------

gui_sv_load ${HDL_NAME}
update
gui_snapshot_sv -png -overwrite "${HDL_NAME}" 



# End of save snapshot of the schematic view ---------------------------------

# Find and save the critical path report
report_timing -max_paths 1 -nworst 1  > ${RPT_DIR}/${HDL_NAME}_critical_path_timing.rpt

# Show and save the schematic for the critical path
gui_show
update
# redirect picorv32_path_detail.rpt {source report_path_detail.tcl} 
# gui_snapshot_sv -png -overwrite "${RPT_DIR}/critical_path_schematic"

#set_load -pin_load 0.05 [get_ports mem_wstrb[0]]
#set_load -pin_load 0.2 [get_ports mem_wstrb[1]]


#report_timing -to [get_ports mem_wstrb[0]] > ${RPT_DIR}/Q0.rpt
#report_timing -to [get_ports mem_wstrb[1]] > ${RPT_DIR}/Q1.rpt

#report_design_rules > ${RPT_DIR}/picorv32_drc_sem_opt.rpt
