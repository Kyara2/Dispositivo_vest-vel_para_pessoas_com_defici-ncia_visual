#!/bin/bash

export CLK_PERIOD=5   ; # Clock Period in ns

# PROJECT_NAME e' o nome REAL da pasta do projeto no disco (o checkout se
# chama "fusion_core" mesmo quando voce esta compilando outro modulo) --
# isso NUNCA muda. MODULE e' QUAL dos 5 modulos voce quer rodar agora, e
# controla DESIGN (o nome usado pelo xrun/Genus como top-level) e a lista
# de fontes RTL. Defina MODULE=<nome> ANTES de chamar ./exe.sh; sem isso,
# cai em fusion_core (igual sempre foi):
#   MODULE=fusion_channel  ./exe.sh syn
#   MODULE=fusion_gain     ./exe.sh pre
export PROJECT_NAME="fusion_core"
export MODULE=${MODULE:-fusion_core}
export DESIGN="${MODULE}" ;# nome do design/top sendo compilado AGORA
export USER=aluno18 ;# put here YOUR user name at this machine
#export PROJECT_DIR=/home/${USER}/projetos/${PROJECT_NAME}
export PROJECT_DIR=/prj/ci/workarea/${USER}/projetos/${PROJECT_NAME}
export BACKEND_DIR=${PROJECT_DIR}/backend
export FRONTEND_DIR=${PROJECT_DIR}/frontend
export HDL_SRC=${FRONTEND_DIR}/src
export TB_SRC=${FRONTEND_DIR}/testbench

# Lista de fontes RTL de cada modulo (os mesmos .sv ja testados no fluxo
# yosys/iverilog, em frontend/src/) -- usada pelo pre/post-synthesis E pelo
# synthesis.tcl (via MODULE_FILES) E pelo uvm, entao fica definida uma vez
# so', aqui em cima:
case "$MODULE" in
    fusion_channel)
        export MODULE_FILES="fusion_channel.sv" ;;
    fusion_variance)
        export MODULE_FILES="fusion_variance.sv" ;;
    fusion_gain)
        export MODULE_FILES="fusion_gain.sv" ;;
    fusion_core)
        export MODULE_FILES="fusion_gain.sv fusion_channel.sv fusion_variance.sv fusion_node.sv fusion_core.sv" ;;
    fusion_node)
        export MODULE_FILES="fusion_channel.sv fusion_gain.sv fusion_variance.sv fusion_node.sv" ;;
    *)
        echo "ERRO: MODULE='$MODULE' desconhecido. Use fusion_channel, fusion_variance, fusion_gain, fusion_core ou fusion_node."
        exit 1 ;;
esac
# versao com caminho completo, pronta pra passar pro xrun:
export MODULE_FILES_FULL=""
for f in $MODULE_FILES; do MODULE_FILES_FULL="$MODULE_FILES_FULL ${HDL_SRC}/${f}"; done
#export TECH_DIR=/opt/GPDK045 ; # technology dependent
export TECH_DIR=/pdk/gpdk045 ;  # technology dependent
export HDL_NAME=${DESIGN}
export HDL_TYPE="system_verilog"         ; # vhdl or verilog or system_verilog
export GENERATE_VCD="no"        ; # no or yes
export SYNTHESIS_WITH_DFT="no"  ; # no or yes 
export LIBRARY_SPEED="slow"     ; # The options are slow or fast


# The standard slow is: "slow_vdd1v0_basicCells.lib"
export WORST_LIB_NAME="slow_vdd1v0_basicCells"
export WORST_LIST="${WORST_LIB_NAME}.lib"  ; # This is the slow lib
# The standard fast is: fast_vdd1v2_basicCells.lib
export BEST_LIB_NAME="fast_vdd1v2_basicCells"
export BEST_LIST="${BEST_LIB_NAME}.lib"   ; # This is the fast lib

echo "BEST_LIST: $BEST_LIST, WORST_LIST: $WORST_LIST"

export PRE_SYN_SCRIPT=${PROJECT_DIR}/backend/synthesis/scripts/pre_syn.tcl
export POST_SYN_SCRIPT=${PROJECT_DIR}/backend/synthesis/scripts/post_syn.tcl

# ATUALIZADO (Out/2026): o /tools/cadence do servidor trocou de versao (o
# XCELIUM2309 antigo nao existe mais -> virou XCELIUM2603, DDI221 -> DDI261,
# etc). As versoes novas vao PRIMEIRO; as antigas ficam depois so' de
# seguranca (um diretorio que nao existe mais e' simplesmente ignorado pelo
# PATH, nao da erro). Se "which xrun" ou "which genus" continuar vazio depois
# desta mudanca, rode:  find /tools/cadence -maxdepth 4 -iname "xrun" -o -iname "genus"
# e me mande o caminho certo para eu ajustar de vez.
# DDI221/GENUS221 vai ANTES do DDI261/GENUS261 de proposito: o genus do
# DDI261 da' "error while loading shared libraries: libxcb-icccm.so.4" nesse
# servidor (falta uma lib do sistema, nao e' bug do projeto); o DDI221 e' o
# mesmo genus que ja sintetizou esse projeto com sucesso antes (os relatorios
# em backend/synthesis/reports/ vieram dele), entao fica na frente.
export PATH=/tools/cadence/XCELIUM2603/tools/bin/64bit:/tools/cadence/XCELIUM2603/tools/bin:/tools/cadence/XCELIUM2603/bin:/tools/cadence/VMANAGER2603/bin:/tools/cadence/VMANAGER2603/tools/bin:/tools/cadence/DDI221/bin:/tools/cadence/DDI221/tools/bin:/tools/cadence/DDI261/bin:/tools/cadence/DDI261/tools/bin:/tools/cadence/CONFRML261/bin:/tools/cadence/CONFRML261/tools/bin:/tools/cadence/MODUS261/bin:/tools/cadence/MODUS261/tools/bin:/tools/cadence/PEGASUS261/bin:/tools/cadence/PEGASUS261/tools/bin:/tools/cadence/PVS251/bin:/tools/cadence/PVS251/tools/bin:/tools/cadence/QUANTUS261/bin:/tools/cadence/QUANTUS261/tools/bin:/tools/cadence/SPECTRE251/bin:/tools/cadence/SPECTRE251/tools/bin:/tools/cadence/SSV261/bin:/tools/cadence/SSV261/tools/bin:/tools/cadence/IC618/bin:/tools/cadence/IC618/tools/bin:/tools/bin:/tools/cadence/QUANTUS221/bin:/tools/cadence/QUANTUS221/tools/bin:/tools/cadence/PEGASUS231/bin:/tools/cadence/PEGASUS231/tools/bin:/tools/cadence/SSV231/bin:/tools/cadence/SSV231/tools/bin:/tools/cadence/XCELIUM2309/tools/bin/64bit:/tools/cadence/XCELIUM2309/tools/bin:/tools/cadence/MODUS231/bin:/tools/cadence/MODUS231/tools/bin:/tools/cadence/CONFRML232/bin:/tools/cadence/CONFRML232/tools/bin:/tools/cadence/DDI221/bin:/tools/cadence/DDI221/tools/bin:/tools/cadence/PVS231/bin:/tools/cadence/PVS231/tools/bin:/tools/cadence/INCISIVE152/bin:/tools/cadence/SPECTRE231/bin:/tools/cadence/SPECTRE231/tools/bin:/tools/cadence/ICADVM201/bin:/tools/cadence/ICADVM201/tools/bin:/tools/cadence/ICADVM201/tools/dFII/bin:/pdk/TSMC/CLN12FFC+/TSMCHOME/sram/Compiler/MC2/MC2_2013.12.00.g/bin/Linux-64:/home/aluno9/.local/bin:/home/aluno9/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin

echo  "The name of this script is $0, the first argument is $1, the second arguments is $2"

echo "HDL_TYPE: $HDL_TYPE"

export HDL_LIBS=""

if [[ "$HDL_TYPE" == "vhdl" ]]; then
    export HDL_EXTENSION="vhd"
    # HDL_LIBS+="Util_package.vhd"
    HDL_LIBS+="fpupack.vhd"
    
elif [[ "$HDL_TYPE" == "system_verilog" ]]; then
    export HDL_EXTENSION="sv"
    HDL_LIBS+=""
    
else 
    export HDL_EXTENSION="v"
    HDL_LIBS+=""
    
fi

export HDL_TESTBENCH=${HDL_NAME}_tb.${HDL_EXTENSION}


if [[ "$SYNTHESIS_WITH_DFT" == "yes" ]]; then
    export DFT_STRING="POST_DFT"
else
    export DFT_STRING="PRE_DFT"
fi


if [[ "$LIBRARY_SPEED" == "slow" ]]; then

    export SYNTHESIS_LIBRARY=$WORST_LIST
    export SYNTHESIS_LIBRARY_STRING="$WORST_LIB_NAME.v"
    
elif [[ "$LIBRARY_SPEED" == "fast" ]]; then

    export SYNTHESIS_LIBRARY=$BEST_LIST
    export SYNTHESIS_LIBRARY_STRING="$BEST_LIB_NAME.v"
fi

echo "HDL string: $HDL_EXTENSION, HDL libs: $HDL_LIBS,  DFT: $DFT_STRING, SYNTHESIS_LIBRARY: $SYNTHESIS_LIBRARY"
echo "HDL_SRC: $HDL_SRC"

if [ "$1" == "pre-synthesis" ] || [ "$1" == "pre" ]; then
    export OPTION="pre-synthesis";
elif [ "$1" == "post-synthesis" ] || [ "$1" == "post" ]; then
    export OPTION="post-synthesis";
elif [ "$1" == "synthesis" ] || [ "$1" == "syn" ] ; then
    export OPTION="synthesis";
elif [ "$1" == "genus" ] || [ "$1" == "g" ] ; then
    export OPTION="genus";
elif [ "$1" == "uvm" ] || [ "$1" == "u" ] ; then
    export OPTION="uvm";
fi        
        
echo "OPTION: $OPTION"

## Run HDL =============================> SIMULATION PRE-SYNTHESIS with XCELIUM
if [[ $OPTION = "pre-synthesis" ]]; then

	# $2 = "gui" para abrir o SimVision interativo (default: roda em lote,
	# sem GUI -- bom pra checar rapido se passou, sem travar esperando voce
	# fechar uma janela). QUAL MODULO: a variavel MODULE, igual no uvm --
	#   MODULE=fusion_channel ./exe.sh pre
	#   MODULE=fusion_gain    ./exe.sh pre gui
	export PRE_WORK=${BACKEND_DIR}/synthesis/work/pre/${MODULE}
	mkdir -p ${PRE_WORK}
	cd ${PRE_WORK}

	GUI_FLAGS="-access +rwc"
	INPUT_FLAG=""
	if [ "$2" == "gui" ]; then
		GUI_FLAGS="-access +rwc -gui"
		INPUT_FLAG="-input ${PRE_SYN_SCRIPT}"
	fi

	if [ ! -f "${TB_SRC}/${HDL_TESTBENCH}" ]; then
		echo "ERRO: nao achei ${TB_SRC}/${HDL_TESTBENCH} -- confira MODULE='$MODULE'."
		exit 1
	fi

	echo "MODULE: $MODULE   DESIGN: $DESIGN   TESTBENCH: ${TB_SRC}/${HDL_TESTBENCH}   GUI: ${2:-no}"

	xrun  -64bit -sv -timescale 1ns/1ps \
	    ${HDL_LIBS} \
	    ${MODULE_FILES_FULL} \
	    ${TB_SRC}/${HDL_TESTBENCH} \
	    -top ${DESIGN}_tb \
	    ${GUI_FLAGS} \
	    ${INPUT_FLAG} \
	    -l ${PRE_WORK}/${DESIGN}_pre.log

	echo "----------------------------------------------------------------------"
	echo "LOG: ${PRE_WORK}/${DESIGN}_pre.log"
	if grep -q "RESULT: PASS" ${PRE_WORK}/${DESIGN}_pre.log 2>/dev/null; then
	    echo "FUNCTIONAL_RESULT: PASS   [$MODULE]"
	elif grep -q "RESULT: FAIL" ${PRE_WORK}/${DESIGN}_pre.log 2>/dev/null; then
	    echo "FUNCTIONAL_RESULT: FAIL   [$MODULE] -- ver o log acima"
	else
	    echo "FUNCTIONAL_RESULT: INDEFINIDO -- o testbench nao imprimiu RESULT: PASS/FAIL, confere o log"
	fi
	echo "----------------------------------------------------------------------"

## Run netlist ============================> SIMULATION POST-SYNTHESIS with XCELIUM
elif [[ $OPTION = "post-synthesis" ]]; then
	
	## Enter frontend folder
	cd ${HDL_SRC}

	rm -rf xcelium.d xrun.log xrun.history waves.shm
    
    # IMPORTANTE: xrun/Xcelium NAO tem opcao de linha de comando "-sdf_max"
    # (essa e' sintaxe do ModelSim/Questa). No Xcelium a anotacao do SDF e
    # feita pela system task $sdf_annotate() dentro do testbench. Aqui so
    # definimos a macro POST_SYNTH para ativar esse bloco no picorv32_tb.sv.
    export POST_SYN_COMMANDS="+define+POST_SYNTH"

    if [[ $GENERATE_VCD == "yes" ]]; then
        VCD_COMMANDS=" -input ${POST_SYN_SCRIPT} "
    else
        VCD_COMMANDS=""
    fi

	xrun -64bit -v200x -v93 \
        ${TECH_DIR}/gsclib045_all_v4.7/gsclib045/verilog/${SYNTHESIS_LIBRARY_STRING} \
        ${HDL_LIBS} \
        ${PROJECT_DIR}/backend/synthesis/deliverables/${MODULE}/${HDL_NAME}_netlist.v \
        ${TB_SRC}/${HDL_TESTBENCH} \
        -top ${DESIGN}_tb \
        ${POST_SYN_COMMANDS} \
        ${VCD_COMMANDS} \
        -access +rwc -gui 


# To execute the GENUS ======================= > LOGIC SYNTHESIS with GENUS
elif [[ $OPTION = "synthesis" ]] ; then

	# QUAL MODULO: a variavel MODULE (ja' resolvida no topo deste arquivo) --
	#   MODULE=fusion_channel ./exe.sh syn
	# Cada modulo sintetiza na sua PROPRIA subpasta de work/deliverables/
	# reports, entao sintetizar um nao apaga o resultado do outro.
	export SYN_WORK=${PROJECT_DIR}/backend/synthesis/work/${MODULE}
	export SYN_DELIVERABLES=${PROJECT_DIR}/backend/synthesis/deliverables/${MODULE}
	export SYN_REPORTS=${PROJECT_DIR}/backend/synthesis/reports/${MODULE}
	mkdir -p ${SYN_WORK} ${SYN_DELIVERABLES} ${SYN_REPORTS}

	echo "MODULE: $MODULE   DESIGN (top): $DESIGN   MODULE_FILES: $MODULE_FILES"

	# Enter work folder
	cd ${SYN_WORK}
	
	## Program and load the script for the automated synthesis
	genus -abort_on_error -lic_startup \
	    Genus_Synthesis -lic_startup_options \
        Genus_Physical_Opt -log genus -overwrite \
        -files ${PROJECT_DIR}/backend/synthesis/scripts/synthesis.tcl 

	echo "----------------------------------------------------------------------"
	echo "MODULE:       $MODULE"
	echo "WORK:         $SYN_WORK"
	echo "DELIVERABLES: $SYN_DELIVERABLES"
	echo "REPORTS:      $SYN_REPORTS"
	echo "----------------------------------------------------------------------"

	
elif [[ $OPTION = "genus" ]] ; then

	export SYN_WORK=${PROJECT_DIR}/backend/synthesis/work/${MODULE}
	mkdir -p ${SYN_WORK}

	# Enter work folder
	cd ${SYN_WORK}
	
	# To execute ONLY Genus without load the the automated synthesis file
	genus -abort_on_error -lic_startup \
        Genus_Synthesis -lic_startup_options \
        Genus_Physical_Opt -log genus -overwrite

## Run the UVM testbench ======================> FUNCTIONAL VERIFICATION with XCELIUM + UVM
elif [[ $OPTION = "uvm" ]]; then

	# $2 = nome do teste UVM (default: fusion_sanity_test -- existe em todos
	#      os 5 modulos), OU "all" para rodar TODOS os testes que existem
	#      para esse MODULE, um atras do outro, com um resumo no final.
	# $3 = "gui" para abrir o SimVision interativo (ignorado quando $2=all --
	#      nao faz sentido abrir GUI pra varios testes em sequencia).
	#
	# QUAL MODULO RODAR: ja' resolvido no topo deste arquivo (variavel MODULE,
	# exportada ANTES de chamar ./exe.sh -- nao precisa renomear pasta nem
	# editar nada aqui):
	#   MODULE=fusion_channel   ./exe.sh uvm fusion_sanity_test
	#   MODULE=fusion_gain      ./exe.sh uvm all
	HDL_FILES="$MODULE_FILES_FULL"

	# testes que existem em CADA modulo (os 4 comuns + os especificos de
	# fusion_core/fusion_node) -- e' essa lista que "all" percorre.
	case "$MODULE" in
	    fusion_core)
	        ALL_TESTS="fusion_sanity_test fusion_random_test fusion_factory_test fusion_coverage_test fusion_arbitration_test" ;;
	    fusion_node)
	        ALL_TESTS="fusion_sanity_test fusion_random_test fusion_factory_test fusion_vseq_test fusion_coverage_test" ;;
	    *)
	        ALL_TESTS="fusion_sanity_test fusion_random_test fusion_factory_test fusion_coverage_test" ;;
	esac

	# Variaveis de ambiente opcionais (exportar ANTES de chamar ./exe.sh):
	#   NUM_FRAMES=<n>     numero de frames/requisicoes dos testes random/coverage (default 2000)
	#   FUSION_N=<n>       so' vale para MODULE=fusion_core: canais simulados (default 1 = canal 0)
	#   COVERAGE=<spec>    liga cobertura no Xcelium: "functional", "all", ou
	#                      "block:expr:fsm:toggle" (so' codigo). Sem isso, nenhuma
	#                      cobertura e' coletada (fica so' o numero que o proprio
	#                      fusion_coverage imprime no log, via get_inst_coverage()).
	export FUSION_N=${FUSION_N:-1}
	export NUM_FRAMES=${NUM_FRAMES:-2000}

	export UVM_SRC=${FRONTEND_DIR}/uvm/${MODULE}/src
	export UVM_WORK=${BACKEND_DIR}/uvm/${MODULE}/work
	export UVM_RPT=${BACKEND_DIR}/uvm/${MODULE}/reports

	if [ ! -d "$UVM_SRC" ]; then
		echo "ERRO: $UVM_SRC nao existe -- confira o nome de MODULE."
		exit 1
	fi

	mkdir -p ${UVM_WORK} ${UVM_RPT}
	cd ${UVM_WORK}

	# $2 = "imc": junta TODAS as bases de cobertura que ja existirem em
	# cov_work/scope/ (de rodadas anteriores com COVERAGE=...) numa unica
	# "merged_all", e abre direto no IMC -- os dois comandos que antes
	# tinham que ser digitados a mao:
	#   MODULE=fusion_channel ./exe.sh uvm imc
	# Isso NAO roda nenhum teste novo -- se cov_work/scope/ estiver vazia
	# ou nao existir, roda primeiro com COVERAGE=all (./exe.sh uvm all,
	# por exemplo) antes de pedir "imc".
	if [ "$2" == "imc" ]; then
		if [ ! -d "cov_work/scope" ] || [ -z "$(ls -A cov_work/scope 2>/dev/null)" ]; then
			echo "ERRO: ${UVM_WORK}/cov_work/scope nao existe ou esta vazia."
			echo "Roda os testes com COVERAGE=all primeiro, por exemplo:"
			echo "   MODULE=${MODULE} COVERAGE=all ./exe.sh uvm all"
			exit 1
		fi
		echo "Juntando as bases de cobertura de $MODULE em cov_work/scope/merged_all ..."
		imc -execcmd "merge cov_work/scope/* -out merged_all -overwrite"
		if [ ! -d "cov_work/scope/merged_all" ]; then
			echo "ERRO: o merge nao gerou cov_work/scope/merged_all -- confere a saida do 'imc' acima."
			exit 1
		fi
		echo "Abrindo o IMC com a base combinada (merged_all) de $MODULE ..."
		imc -load merged_all -gui &
		exit 0
	fi

	# Roda UM teste UVM (um xrun) e mostra o resultado -- usada tanto pro
	# caso normal (um teste so') quanto, em loop, pelo "all" logo abaixo.
	run_one_uvm_test () {
		local TEST_NAME=$1
		local GUI_FLAG=$2

		local GUI_FLAGS=""
		if [ "$GUI_FLAG" == "gui" ]; then
			GUI_FLAGS="-access +rwc -gui"
		fi

		local COV_FLAGS=""
		if [ -n "$COVERAGE" ]; then
			# -covtest da' a cada teste seu PROPRIO escopo dentro de
			# cov_work/scope/, em vez de todos caírem em
			# "cov_work/scope/test" e se sobrescreverem -- assim da' pra
			# abrir cada um separado no IMC, ou dar merge dos varios.
			COV_FLAGS="-coverage ${COVERAGE} -covoverwrite -covdut ${MODULE} -covtest ${TEST_NAME}"
		fi

		echo "MODULE: $MODULE   UVM_TEST: $TEST_NAME   FUSION_N: $FUSION_N   NUM_FRAMES: $NUM_FRAMES   COVERAGE: ${COVERAGE:-off}   GUI: ${GUI_FLAG:-no}"

		# APAGA o result.txt/scoreboard.rpt ANTES de rodar. Sem isso, se o
		# xrun falhar na elaboracao (ou morrer por qualquer outro motivo
		# antes do testbench chegar no report_phase), o arquivo de uma
		# rodada ANTERIOR bem-sucedida continua ali -- e o "cat" no final
		# desta funcao mostraria aquele PASS antigo, de uma simulacao que
		# nao tem nada a ver com a que acabou de rodar. Isso ja aconteceu
		# de verdade (COVERAGE=all travando na elaboracao por um erro de
		# sintaxe de covergroup, e o script mostrando PASS de uma rodada
		# anterior sem cobertura). Apagando antes, um resultado que falte
		# so' pode significar "essa rodada nao terminou", nunca "deixa eu
		# te mostrar o que rolou da ultima vez".
		rm -f ${UVM_RPT}/${TEST_NAME}_result.txt ${UVM_RPT}/${TEST_NAME}_scoreboard.rpt

		xrun -64bit -sv -uvm \
		    -timescale 1ns/1ps \
		    +define+FUSION_N=${FUSION_N} \
		    +UVM_TESTNAME=${TEST_NAME} \
		    +NUM_FRAMES=${NUM_FRAMES} \
		    +CLK_NS=${CLK_PERIOD} \
		    +RESULTS_DIR=${UVM_RPT} \
		    ${COV_FLAGS} \
		    -incdir ${UVM_SRC} \
		    ${HDL_FILES} \
		    ${UVM_SRC}/fusion_if.sv \
		    ${UVM_SRC}/fusion_pkg.sv \
		    ${UVM_SRC}/tb_top.sv \
		    -top tb_top \
		    ${GUI_FLAGS} \
		    -l ${UVM_RPT}/${TEST_NAME}.log
		local XRUN_EXIT=$?

		echo "----------------------------------------------------------------------"
		echo "MODULE:     $MODULE"
		echo "LOG:        ${UVM_RPT}/${TEST_NAME}.log"
		echo "RESULT:     ${UVM_RPT}/${TEST_NAME}_result.txt"
		echo "SCOREBOARD: ${UVM_RPT}/${TEST_NAME}_scoreboard.rpt"
		echo "----------------------------------------------------------------------"

		if [ $XRUN_EXIT -ne 0 ]; then
			echo "FUSION_UVM_RESULT: FAIL (xrun exited with status $XRUN_EXIT -- it did not finish the test; see the *E,/*F, lines in ${UVM_RPT}/${TEST_NAME}.log)   [$TEST_NAME]"
		elif [ ! -f "${UVM_RPT}/${TEST_NAME}_result.txt" ]; then
			echo "FUSION_UVM_RESULT: FAIL (no result file was produced -- the test never reached report_phase; see ${UVM_RPT}/${TEST_NAME}.log)   [$TEST_NAME]"
		else
			cat ${UVM_RPT}/${TEST_NAME}_result.txt
		fi
	}

	if [ "$2" == "all" ]; then
		echo "Rodando TODOS os testes de $MODULE: $ALL_TESTS"
		declare -a SUMMARY
		FAILED=0
		for T in $ALL_TESTS; do
			echo "=============================================================="
			echo ">> $MODULE / $T"
			echo "=============================================================="
			run_one_uvm_test "$T" ""
			if grep -q "FUSION_UVM_RESULT: PASS" "${UVM_RPT}/${T}_result.txt" 2>/dev/null; then
				SUMMARY+=("PASS  $MODULE / $T")
			else
				SUMMARY+=("FAIL  $MODULE / $T   (ver ${UVM_RPT}/${T}.log)")
				FAILED=$((FAILED+1))
			fi
		done
		echo
		echo "=============================================================="
		NTOTAL=$(echo $ALL_TESTS | wc -w)
		echo "RESUMO $MODULE: $((NTOTAL-FAILED))/${NTOTAL} PASS"
		echo "=============================================================="
		for line in "${SUMMARY[@]}"; do echo "$line"; done
	else
		export UVM_TEST=${2:-fusion_sanity_test}
		run_one_uvm_test "$UVM_TEST" "$3"
	fi

fi







