
#-----------------------------------------------------------------------------
# Common path variables (directory structure dependent)
#-----------------------------------------------------------------------------
set BACKEND_DIR              ${PROJECT_DIR}/backend
set SYNT_DIR                 ${BACKEND_DIR}/synthesis
set SCRIPT_DIR                ${SYNT_DIR}/scripts
# MODULE (fusion_channel/fusion_variance/fusion_gain/fusion_core/fusion_node)
# separa os relatorios/deliverables de cada modulo em subpastas -- assim
# sintetizar um nao sobrescreve o resultado do outro.
set MODULE                   $env(MODULE)
set RPT_DIR                  ${SYNT_DIR}/reports/${MODULE}
set DEV_DIR                  ${SYNT_DIR}/deliverables/${MODULE}
set LAYOUT_DIR               ${BACKEND_DIR}/layout
file mkdir ${RPT_DIR}
file mkdir ${DEV_DIR}

#-----------------------------------------------------------------------------
# Setting rtl search directories
#-----------------------------------------------------------------------------
set FRONTEND_DIR ${PROJECT_DIR}/frontend
set OTHERS ""
lappend FRONTEND_DIR $OTHERS

#-----------------------------------------------------------------------------
# Setting technology directories
#-----------------------------------------------------------------------------
set LIB_DIR ${TECH_DIR}/gsclib045_svt_v4.7/gsclib045/timing
#lappend LIB_DIR ${TECH_DIR}/io

set LEF_DIR ${TECH_DIR}/gsclib045_svt_v4.7/gsclib045/lef
#lappend LEF_DIR ${TECH_DIR}/giolib045_v3.3/lef



