// ============================================================================
// fusion_core: N independent fusion_node instances in parallel (N=8 for the
// tactile ring -- one full Kalman fusion per contact point).
//
// REDESIGNED (was: N x fusion_channel with K computed externally and fed
// in). Each channel now has its OWN fusion_gain, so each contact point
// gets its own gain K, fused estimate q_hat AND updated variance
// sigma_new_sq -- not just a position estimate with a pre-computed gain.
//
// Flat buses: channel i occupies bits [i*W +: W] of every N*W-wide port.
//
// Protocol is "fire and wait", inherited unchanged from fusion_node (the
// bottleneck is fusion_gain's serial divider, ~FRAC+1 cycles, identical
// for every channel since the iteration count does not depend on the
// data): assert in_valid for one cycle, busy stays high, out_valid pulses
// once with all N channels' k / q_hat / sigma_new_sq valid together.
//
// busy/out_valid are taken from channel 0 only (same simplifying
// convention the previous fusion_core used for its single out_valid).
// This is safe as long as every channel actually starts a real division
// (iterates all FRAC cycles) -- the ONE case where a channel finishes
// early is sigma1_sq==0 && sigma2_sq==0 for THAT channel (fusion_gain's
// explicit short-circuit, see fusion_gain.sv), which completes in 1 cycle
// instead of ~FRAC+1. If some contact points can legitimately have both
// variances at exactly zero while others do not in the same request, that
// channel's result would already be sitting in its own node's output
// register, held stable, by the time channel 0 (used for the shared
// out_valid) finishes -- so no data is lost, but this is worth flagging:
// a fully independent per-channel busy/out_valid (N-bit vectors instead
// of shared single bits) would remove the assumption entirely, at the
// cost of a wider control interface. Not done here to keep the interface
// matching fusion_node's shape; revisit if the all-zero-variance case is
// expected in practice.
// ============================================================================
module fusion_core #(
    parameter N = 8, parameter W = 16, parameter FRAC = 15
)(
    input  wire            clk, rst_n, in_valid,
    input  wire [N*W-1:0]  q1, q2, sigma1_sq, sigma2_sq,
    output wire            busy,
    output wire            out_valid,
    output wire [N*W-1:0]  k,
    output wire [N*W-1:0]  q_hat,
    output wire [N*W-1:0]  sigma_new_sq
);
    wire [N-1:0] v;
    wire [N-1:0] b;
    genvar i;
    generate for (i = 0; i < N; i = i + 1) begin : node
        fusion_node #(.W(W), .FRAC(FRAC)) u (
            .clk(clk), .rst_n(rst_n), .in_valid(in_valid),
            .q1(q1[i*W +: W]), .q2(q2[i*W +: W]),
            .sigma1_sq(sigma1_sq[i*W +: W]), .sigma2_sq(sigma2_sq[i*W +: W]),
            .busy(b[i]), .out_valid(v[i]),
            .k(k[i*W +: W]), .q_hat(q_hat[i*W +: W]), .sigma_new_sq(sigma_new_sq[i*W +: W])
        );
    end endgenerate
    assign busy      = b[0];
    assign out_valid = v[0];
endmodule
