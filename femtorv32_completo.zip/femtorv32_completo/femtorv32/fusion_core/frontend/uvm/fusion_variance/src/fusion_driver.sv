class fusion_driver extends uvm_driver #(fusion_item);
  `uvm_component_utils(fusion_driver)
  fusion_vif_t vif; fusion_cfg cfg;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(fusion_vif_t)::get(this, "", "vif", vif)) `uvm_fatal("NOVIF", "no vif")
    if (!uvm_config_db#(fusion_cfg)::get(this, "", "cfg", cfg)) `uvm_fatal("NOCFG", "no cfg")
  endfunction
  task run_phase(uvm_phase phase);
    fusion_item req;
    drive_idle(); wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.cb);
      seq_item_port.try_next_item(req);
      if (req == null) drive_idle();
      else begin
        repeat (req.gap) begin drive_idle(); @(vif.cb); end
        drive_frame(req);
        seq_item_port.item_done();
      end
    end
  endtask
  task drive_idle();
    vif.cb.in_valid <= 1'b0; vif.cb.sigma1_sq <= $urandom; vif.cb.k <= $urandom;
  endtask
  task drive_frame(fusion_item req);
    vif.cb.in_valid <= 1'b1; vif.cb.sigma1_sq <= req.sigma1_sq; vif.cb.k <= req.k;
  endtask
endclass
