function automatic logic [FW-1:0] fusion_golden_sigma_new(
    input logic [FW-1:0] a_sigma1_sq, input logic [FW-1:0] a_k);
  logic [2*FW-1:0]      prod, rnd;
  logic signed [2*FW:0] diff;
  begin
    prod = a_sigma1_sq * a_k;
    rnd  = (prod + (1 <<< (FFRAC-1))) >> FFRAC;
    diff = $signed({{(FW+1){1'b0}}, a_sigma1_sq}) - $signed({1'b0, rnd});
    if (diff[2*FW])                                           fusion_golden_sigma_new = '0;
    else if (diff > $signed({{(FW+1){1'b0}}, {FW{1'b1}}}))   fusion_golden_sigma_new = '1;
    else                                                      fusion_golden_sigma_new = diff[FW-1:0];
  end
endfunction
