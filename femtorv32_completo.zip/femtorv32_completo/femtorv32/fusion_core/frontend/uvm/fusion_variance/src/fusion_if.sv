// fusion_if.sv -- interface for fusion_variance, with clocking block +
// modport (Aula 3). See fusion_channel/uvm/src/fusion_if.sv for the full
// rationale; same pattern, adapted port list.
interface fusion_if #(parameter W = 16, parameter FRAC = 15) (input logic clk);
  logic           rst_n;
  logic           in_valid;
  logic [W-1:0]   sigma1_sq, k;
  logic           out_valid;
  logic [W-1:0]   sigma_new_sq;

  int unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  initial begin rst_n = 1'b0; in_valid = 1'b0; sigma1_sq = '0; k = '0; end

  task automatic do_reset(input int unsigned n_cycles);
    @(negedge clk); rst_n = 1'b0; repeat (n_cycles) @(negedge clk); rst_n = 1'b1;
  endtask

  clocking cb @(posedge clk);
    default input #1step output #2;
    output in_valid, sigma1_sq, k;
    input  out_valid, sigma_new_sq;
  endclocking
  modport TB (clocking cb, output rst_n, import do_reset);

  a_latency : assert property (@(posedge clk) disable iff (!rst_n)
      in_valid |-> ##2 out_valid)
    else $error("SVA a_latency: out_valid did not rise 2 cycles after in_valid");
  a_no_spurious : assert property (@(posedge clk) disable iff (!rst_n)
      out_valid |-> $past(in_valid, 2))
    else $error("SVA a_no_spurious: out_valid with no in_valid 2 cycles earlier");
  a_reset_clears : assert property (@(posedge clk) !rst_n |=> !out_valid)
    else $error("SVA a_reset_clears: out_valid still active right after reset");
  a_no_x : assert property (@(posedge clk) disable iff (!rst_n)
      out_valid |-> !$isunknown(sigma_new_sq))
    else $error("SVA a_no_x: sigma_new_sq has X/Z while out_valid=1");
endinterface
