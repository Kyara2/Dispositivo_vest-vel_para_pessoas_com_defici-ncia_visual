class fusion_cfg extends uvm_object;
  `uvm_object_utils(fusion_cfg)
  fusion_vif_t vif;
  int unsigned exp_latency = 2;
  int unsigned num_frames  = 2000;
  string       results_dir = ".";
  string       test_name   = "fusion_test";
  function new(string name = "fusion_cfg"); super.new(name); endfunction
endclass
