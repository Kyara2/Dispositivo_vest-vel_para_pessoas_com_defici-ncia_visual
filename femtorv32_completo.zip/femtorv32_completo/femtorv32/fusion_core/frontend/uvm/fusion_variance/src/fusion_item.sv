class fusion_item extends uvm_sequence_item;
  rand bit [FW-1:0] sigma1_sq, k;
  rand int unsigned gap;
  bit [FW-1:0] sigma_new_sq;
  int unsigned cyc;
  `uvm_object_utils(fusion_item)
  function new(string name = "fusion_item"); super.new(name); endfunction
  constraint c_gap { gap dist {0 := 70, 1 := 15, [2:6] :/ 15}; }
  constraint c_rng { sigma1_sq inside {[0:65535]}; }
  constraint c_k   { k inside {[0:32768]}; }
  function string convert2string();
    return $sformatf("sigma1_sq=%0d k=%0d gap=%0d cyc=%0d sigma_new_sq=%0d",
                      sigma1_sq, k, gap, cyc, sigma_new_sq);
  endfunction
endclass

class fusion_item_corner extends fusion_item;
  `uvm_object_utils(fusion_item_corner)
  constraint c_corner { sigma1_sq inside {0, 1, 65534, 65535}; k inside {0, 1, 16384, 32767, 32768, 49152, 65535}; }
  function new(string name = "fusion_item_corner");
    super.new(name); c_rng.constraint_mode(0); c_k.constraint_mode(0);
  endfunction
endclass
