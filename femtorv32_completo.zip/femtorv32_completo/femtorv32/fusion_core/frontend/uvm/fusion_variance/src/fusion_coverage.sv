class fusion_coverage extends uvm_subscriber #(fusion_item);
  `uvm_component_utils(fusion_coverage)
  int unsigned s_sigma1_sq, s_k;
  covergroup cg_fusion;
    option.per_instance = 1;
    cp_sigma1 : coverpoint s_sigma1_sq {
      bins zero={0}; bins low={[1:199]}; bins mid[4]={[200:60000]};
      bins high={[60001:65534]}; bins maxv={65535};
    }
    cp_k : coverpoint s_k {
      bins k0={0}; bins low={[1:8191]}; bins mid={[8192:24575]};
      bins high={[24576:32767]}; bins k1={32768}; bins oob={[32769:65535]};
    }
    x_sigma_k : cross cp_sigma1, cp_k;
  endgroup
  function new(string name, uvm_component parent); super.new(name, parent); cg_fusion = new(); endfunction
  function void write(fusion_item t);
    s_sigma1_sq = t.sigma1_sq; s_k = t.k; cg_fusion.sample();
  endfunction
  function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("COV_REPORT", $sformatf("functional coverage (cg_fusion) = %0.2f%%",
              cg_fusion.get_inst_coverage()), UVM_NONE)
  endfunction
endclass
