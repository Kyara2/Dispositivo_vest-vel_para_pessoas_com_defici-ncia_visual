class fusion_out_monitor extends uvm_monitor;
  `uvm_component_utils(fusion_out_monitor)
  uvm_analysis_port #(fusion_item) ap;
  fusion_vif_t vif;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase); ap = new("ap", this);
    if (!uvm_config_db#(fusion_vif_t)::get(this, "", "vif", vif)) `uvm_fatal("NOVIF", "no vif")
  endfunction
  task run_phase(uvm_phase phase);
    forever begin
      @(posedge vif.clk);
      if (vif.out_valid === 1'b1) begin
        fusion_item it = fusion_item::type_id::create("out_item");
        if ($isunknown(vif.sigma_new_sq)) `uvm_error("OUT_X", "sigma_new_sq has X/Z")
        it.sigma_new_sq = vif.sigma_new_sq; it.cyc = vif.cyc;
        ap.write(it);
      end
    end
  endtask
endclass
