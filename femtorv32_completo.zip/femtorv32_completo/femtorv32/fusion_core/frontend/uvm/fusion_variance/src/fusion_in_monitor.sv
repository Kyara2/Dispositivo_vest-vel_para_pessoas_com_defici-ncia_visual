class fusion_in_monitor extends uvm_monitor;
  `uvm_component_utils(fusion_in_monitor)
  uvm_analysis_port #(fusion_item) ap;
  fusion_vif_t vif;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase); ap = new("ap", this);
    if (!uvm_config_db#(fusion_vif_t)::get(this, "", "vif", vif)) `uvm_fatal("NOVIF", "no vif")
  endfunction
  task run_phase(uvm_phase phase);
    forever begin
      @(posedge vif.clk);
      if (vif.rst_n === 1'b1 && vif.in_valid === 1'b1) begin
        fusion_item it = fusion_item::type_id::create("in_item");
        it.sigma1_sq = vif.sigma1_sq; it.k = vif.k; it.cyc = vif.cyc;
        ap.write(it);
      end
    end
  endtask
endclass
