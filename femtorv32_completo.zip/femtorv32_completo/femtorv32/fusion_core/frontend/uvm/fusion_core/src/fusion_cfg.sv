class fusion_cfg extends uvm_object;
  `uvm_object_utils(fusion_cfg)
  fusion_vif_t vif;
  // latency is no longer a fixed constant (it was 3, for the old
  // fixed-pipeline fusion_channel array): fusion_node's gain divider
  // takes ~FFRAC+1 cycles plus 4 more through channel+output register,
  // EXCEPT the sigma1_sq==sigma2_sq==0 short-circuit corner (~5 total).
  // Kept here for reference/logging; the scoreboard checks a RANGE,
  // not an exact value -- see fusion_scoreboard.sv.
  int unsigned exp_latency_typ = FFRAC + 5;
  int unsigned exp_latency_min = 5;
  int unsigned num_frames  = 2000;
  string       results_dir = ".";
  string       test_name   = "fusion_test";
  function new(string name = "fusion_cfg"); super.new(name); endfunction
endclass
