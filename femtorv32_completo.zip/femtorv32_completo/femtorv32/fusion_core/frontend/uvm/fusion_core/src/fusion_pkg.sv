// fusion_pkg.sv -- UVM package for the REDESIGNED fusion_core: FN full
// fusion_node instances (gain+channel+variance each), not FN x
// fusion_channel with K fed in externally. This env drives/checks ALL FN
// channels of every transaction (not just channel 0, unlike the previous
// fusion_core env), since K/q_hat/sigma_new_sq now differ per channel
// based on each channel's own sigma1_sq/sigma2_sq.
`include "uvm_macros.svh"
package fusion_pkg;
  import uvm_pkg::*;
  `ifndef FUSION_N
    `define FUSION_N 8
  `endif
  parameter int FN    = `FUSION_N;
  parameter int FW    = 16;
  parameter int FFRAC = 15;
  typedef virtual fusion_if #(FN, FW, FFRAC) fusion_vif_t;

  // Arbitration mode used by fusion_arbitration_test (Aula 10/11). The
  // IEEE-1800.2 name is UVM_SEQ_ARB_WEIGHTED; some sites' default -uvm
  // (pre-1800.2 UVM-1.1d) only has the unprefixed SEQ_ARB_WEIGHTED -- if
  // xrun reports "UVM_SEQ_ARB_WEIGHTED: undeclared identifier", change
  // ONLY the line below to SEQ_ARB_WEIGHTED and nothing else needs to change.
  // CONFIRMADO em 21/Out/2026: este servidor usa uvmhome CDNS-1.1d (UVM
  // pre-1800.2) -- ver o log do xrun: "using uvmhome location
  // .../UVM/CDNS-1.1d". Essa versao so' tem o nome SEM o prefixo "UVM_".
  localparam uvm_sequencer_arb_mode SEQ_ARB_MODE = SEQ_ARB_WEIGHTED;

  `include "fusion_model.sv"
  `include "fusion_cfg.sv"
  `include "fusion_item.sv"
  `include "fusion_sequencer.sv"
  `include "fusion_driver.sv"
  `include "fusion_in_monitor.sv"
  `include "fusion_out_monitor.sv"
  `include "fusion_in_agent.sv"
  `include "fusion_out_agent.sv"
  `include "fusion_coverage.sv"
  `include "fusion_scoreboard.sv"
  `include "fusion_env.sv"
  `include "fusion_seq_lib.sv"
  `include "fusion_test_lib.sv"
endpackage
