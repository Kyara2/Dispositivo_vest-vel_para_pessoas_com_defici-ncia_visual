class fusion_base_test extends uvm_test;
  `uvm_component_utils(fusion_base_test)
  fusion_env   env;
  fusion_cfg   cfg;
  fusion_vif_t vif;
  function new(string name = "fusion_base_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    cfg = fusion_cfg::type_id::create("cfg");
    if (!uvm_config_db#(fusion_vif_t)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "virtual interface not found")
    cfg.vif       = vif;
    cfg.test_name = get_type_name();
    void'($value$plusargs("NUM_FRAMES=%d",  cfg.num_frames));
    void'($value$plusargs("RESULTS_DIR=%s", cfg.results_dir));
    uvm_config_db#(fusion_cfg)::set(this, "*", "cfg", cfg);
    uvm_root::get().set_timeout(500ms, 0);   // was 200ms -- fire-and-wait
                                              // requests take longer per
                                              // frame now (~FFRAC+5 cycles
                                              // vs. the old fixed 3), so
                                              // the same frame count needs
                                              // more wall-clock budget
    env = fusion_env::type_id::create("env", this);
  endfunction
  function void end_of_elaboration_phase(uvm_phase phase);
    super.end_of_elaboration_phase(phase);
    uvm_root::get().print_topology();
  endfunction
  task run_phase(uvm_phase phase);
    phase.raise_objection(this, "test running");
    vif.do_reset(4);
    repeat (2) @(vif.cb);
    run_body();
    repeat (cfg.exp_latency_typ + 60) @(vif.cb);   // generous drain --
                                                     // covers fusion_arbitration_test's
                                                     // delayed crit_seq as well
    phase.drop_objection(this, "test done");
  endtask
  virtual task run_body(); endtask
  task run_seq(fusion_base_seq s, int unsigned n = 0);
    if (n != 0) s.num = n;
    s.start(env.in_agent.sqr);
  endtask
  function void report_phase(uvm_phase phase);
    uvm_report_server srv; int unsigned nerr; string verdict; int fd;
    super.report_phase(phase);
    srv = uvm_report_server::get_server();
    nerr = srv.get_severity_count(UVM_ERROR) + srv.get_severity_count(UVM_FATAL);
    verdict = (nerr == 0) ? "FUSION_UVM_RESULT: PASS" : $sformatf("FUSION_UVM_RESULT: FAIL (%0d)", nerr);
    `uvm_info("RESULT", $sformatf("%s   [%s]", verdict, cfg.test_name), UVM_NONE)
    fd = $fopen({cfg.results_dir, "/", cfg.test_name, "_result.txt"}, "w");
    if (fd != 0) begin $fdisplay(fd, "%s   [%s]", verdict, cfg.test_name); $fclose(fd); end
  endfunction
endclass

class fusion_sanity_test extends fusion_base_test;
  `uvm_component_utils(fusion_sanity_test)
  function new(string name = "fusion_sanity_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  task run_body();
    fusion_directed_seq s = fusion_directed_seq::type_id::create("directed");
    run_seq(s);
  endtask
endclass

class fusion_random_test extends fusion_base_test;
  `uvm_component_utils(fusion_random_test)
  function new(string name = "fusion_random_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  task run_body();
    fusion_random_seq s = fusion_random_seq::type_id::create("random");
    run_seq(s, cfg.num_frames);
  endtask
endclass

class fusion_factory_test extends fusion_base_test;
  `uvm_component_utils(fusion_factory_test)
  function new(string name = "fusion_factory_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  task run_body();
    fusion_factory_seq s = fusion_factory_seq::type_id::create("factory");
    run_seq(s, 500);
  endtask
endclass

class fusion_coverage_test extends fusion_base_test;
  `uvm_component_utils(fusion_coverage_test)
  function new(string name = "fusion_coverage_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  task run_body();
    fusion_random_seq  r = fusion_random_seq::type_id::create("r");
    fusion_factory_seq b = fusion_factory_seq::type_id::create("b");
    fusion_asym_seq    a = fusion_asym_seq::type_id::create("a");
    run_seq(r, cfg.num_frames);
    run_seq(b, 300);
    run_seq(a);
  endtask
endclass

// Two concurrent sequences competing for the driver with different
// weights (set_arbitration), plus a third that grab()s the sequencer
// mid-run to jump the queue (Aula 10/11). Unchanged in spirit from the
// previous fusion_core -- the sequencer-arbitration mechanism being
// tested here doesn't care what's inside each channel.
class fusion_arbitration_test extends fusion_base_test;
  `uvm_component_utils(fusion_arbitration_test)
  function new(string name = "fusion_arbitration_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  task run_body();
    fusion_random_seq   normal_seq   = fusion_random_seq::type_id::create("normal_seq");
    fusion_factory_seq  weighted_seq = fusion_factory_seq::type_id::create("weighted_seq");
    fusion_critical_seq crit_seq     = fusion_critical_seq::type_id::create("crit_seq");
    normal_seq.num = 100; weighted_seq.num = 50;   // fewer than before --
                                                     // each frame now costs
                                                     // ~FFRAC+5 cycles, not 1
    env.in_agent.sqr.set_arbitration(SEQ_ARB_MODE);
    fork
      normal_seq.start(env.in_agent.sqr, null, 100);
      weighted_seq.start(env.in_agent.sqr, null, 200);
      begin repeat (40) @(vif.cb); crit_seq.start(env.in_agent.sqr); end
    join
  endtask
endclass
