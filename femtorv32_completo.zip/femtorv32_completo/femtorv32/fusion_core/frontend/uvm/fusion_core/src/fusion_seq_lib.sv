class fusion_base_seq extends uvm_sequence #(fusion_item);
  `uvm_object_utils(fusion_base_seq)
  int unsigned num = 100;
  function new(string name = "fusion_base_seq"); super.new(name); endfunction

  // same q1/q2/sigma1_sq/sigma2_sq on all FN channels -- for directed
  // cases where only the SHAPE of the request matters
  task send_same(input int unsigned a_q1, input int unsigned a_q2,
                 input int unsigned a_s1, input int unsigned a_s2,
                 input int unsigned gap_v = 0);
    fusion_item r = fusion_item::type_id::create("r");
    start_item(r);
    for (int i = 0; i < FN; i++) begin
      r.q1[i] = a_q1; r.q2[i] = a_q2; r.sigma1_sq[i] = a_s1; r.sigma2_sq[i] = a_s2;
    end
    r.gap = gap_v;
    finish_item(r);
  endtask

  // a DIFFERENT (q1,q2,s1,s2) per channel in the SAME request -- proves
  // the FN fusion_node copies don't interfere with each other
  task send_distinct(input int unsigned a_q1[FN], input int unsigned a_q2[FN],
                     input int unsigned a_s1[FN], input int unsigned a_s2[FN]);
    fusion_item r = fusion_item::type_id::create("r");
    start_item(r);
    for (int i = 0; i < FN; i++) begin
      r.q1[i] = a_q1[i]; r.q2[i] = a_q2[i]; r.sigma1_sq[i] = a_s1[i]; r.sigma2_sq[i] = a_s2[i];
    end
    finish_item(r);
  endtask
endclass

class fusion_directed_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_directed_seq)
  function new(string name = "fusion_directed_seq"); super.new(name); endfunction
  task body();
    int unsigned dq1[FN], dq2[FN], ds1[FN], ds2[FN];
    // same intents as the old K-driven directed cases, re-derived through
    // sigma1_sq/sigma2_sq: s1=0 -> K=0; s1==s2 -> K~0.5; s2=0 -> K~1.0
    send_same(800, 800, 0, 100);      // K=0   -> q_hat must equal q1 (==q2 here anyway)
    send_same(800, 800, 100, 100);    // K~0.5
    send_same(800, 800, 100, 0);      // K~1.0 -> q_hat must equal q2 (==q1 here anyway)
    send_same(200, 1600, 100, 100);   // max disagreement in-range, K~0.5
    send_same(1600, 200, 100, 100);   // same, reversed
    send_same(500, 1500, 0, 100);     // K=0   -> q_hat must equal q1
    send_same(500, 1500, 100, 0);     // K~1.0 -> q_hat must equal q2
    send_same(1000, 1001, 100, 100);  // rounding tie (K~0.5, diff=+1) -- exercises half-up
    send_same(1001, 1000, 100, 100);
    send_same(700, 900, 100, 100, 3); // with idle gap before firing
    send_same(900, 700, 100, 100, 7);
    // one request where every one of the FN channels gets a DIFFERENT
    // set of values, to prove channel independence directly
    for (int i = 0; i < FN; i++) begin
      dq1[i] = 100 * (i+1); dq2[i] = 100 * (i+1) + 50;
      ds1[i] = 10  * (i+1); ds2[i] = 20  * (i+1);
    end
    send_distinct(dq1, dq2, ds1, ds2);
  endtask
endclass

class fusion_random_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_random_seq)
  function new(string name = "fusion_random_seq"); super.new(name); endfunction
  task body();
    fusion_item r;
    repeat (num) begin
      r = fusion_item::type_id::create("r");
      start_item(r);
      if (!r.randomize()) `uvm_fatal("RAND", "randomize() failed")
      finish_item(r);
    end
  endtask
endclass

// factory override (Aula 6): same stimulus body as random, but every
// fusion_item created resolves to fusion_item_corner instead.
class fusion_factory_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_factory_seq)
  function new(string name = "fusion_factory_seq"); super.new(name); endfunction
  task body();
    fusion_item r;
    `uvm_info("FACTORY", "override: fusion_item -> fusion_item_corner", UVM_LOW)
    fusion_item::type_id::set_type_override(fusion_item_corner::get_type());
    repeat (num) begin
      r = fusion_item::type_id::create("r");
      start_item(r);
      if (!r.randomize()) `uvm_fatal("RAND", "randomize() failed")
      finish_item(r);
    end
    fusion_item::type_id::set_type_override(fusion_item::get_type());
  endtask
endclass

// closes the functional-coverage cross (diff extreme x sigma-ratio
// extreme) that random+factory alone rarely hit together (Aula 16).
// sigma pairs chosen to land K near 0, ~0.5 and ~1.0 (K is a RESULT now,
// so this walks the INPUT space that produces those K regions, instead
// of setting K directly like the old fusion_asym_seq did).
class fusion_asym_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_asym_seq)
  function new(string name = "fusion_asym_seq"); super.new(name); endfunction
  task body();
    int          diffs[]  = '{1500, 50, -1500, -50};
    int unsigned s1s[]     = '{0, 100, 100, 65535};
    int unsigned s2s[]     = '{100, 100, 0, 1};   // paired with s1s: K~0, ~0.5, ~1.0, ~max
    int unsigned base = 800;
    foreach (diffs[i]) foreach (s1s[j]) begin
      int q2v = int'(base) + diffs[i];
      if (q2v < 0) q2v = 0; if (q2v > 65535) q2v = 65535;
      send_same(base, q2v, s1s[j], s2s[j]);
    end
  endtask
endclass

// grab()-based exclusive access (Aula 10/11): simulates an emergency
// "obstacle very close" reading that must jump the arbitration queue --
// equal variances (K~0.5) on a very short, consistent distance.
class fusion_critical_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_critical_seq)
  function new(string name = "fusion_critical_seq"); super.new(name); endfunction
  task body();
    grab();
    send_same(210, 210, 100, 100);
    send_same(205, 215, 100, 100);
    ungrab();
  endtask
endclass
