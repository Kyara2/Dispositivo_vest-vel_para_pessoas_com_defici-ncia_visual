// ============================================================================
// fusion_if.sv -- interface for the REDESIGNED fusion_core (N=FN full
// fusion_node instances, not N x fusion_channel with K fed in externally).
//
// Port list changed vs. the previous fusion_core: K is no longer a
// stimulus input -- it's computed INSIDE each channel from sigma1_sq/
// sigma2_sq, same as fusion_node. So this env now drives q1,q2,sigma1_sq,
// sigma2_sq and reads back k,q_hat,sigma_new_sq (plus busy/out_valid),
// instead of driving q1,q2,k and reading q_hat only.
//
// Protocol also changed: the old fusion_channel array was a simple
// fixed-3-cycle PIPELINE (always ready, one frame in flight per cycle).
// fusion_node is "fire and wait" (bottlenecked by its own gain divider,
// ~FRAC+1 cycles), and fusion_core inherits that unchanged -- busy stays
// high from an accepted in_valid until the aligned out_valid, and a new
// in_valid is ignored while busy. The driver below reflects this.
//
// Clocking block + modport (Aula 3), same pattern as the rest of the
// project. NOTE (unchanged from the previous fusion_if.sv): neither
// Icarus Verilog nor Verilator implement clocking blocks/modport-clocking
// locally, so this construct could not be compiled outside Xcelium -- if
// xrun reports a syntax error on it, send the exact message.
// ============================================================================
interface fusion_if #(parameter N = 8, parameter W = 16, parameter FRAC = 15) (input logic clk);
  logic             rst_n;
  logic             in_valid;
  logic [N*W-1:0]   q1, q2, sigma1_sq, sigma2_sq;
  logic             busy, out_valid;
  logic [N*W-1:0]   k, q_hat, sigma_new_sq;

  int unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  initial begin
    rst_n = 1'b0; in_valid = 1'b0;
    q1 = '0; q2 = '0; sigma1_sq = '0; sigma2_sq = '0;
  end

  task automatic do_reset(input int unsigned n_cycles);
    @(negedge clk);
    rst_n = 1'b0;
    repeat (n_cycles) @(negedge clk);
    rst_n = 1'b1;
  endtask

  clocking cb @(posedge clk);
    default input #1step output #2;
    output in_valid, q1, q2, sigma1_sq, sigma2_sq;
    input  busy, out_valid, k, q_hat, sigma_new_sq;
  endclocking

  modport TB (clocking cb, output rst_n, import do_reset);

  // -------------------------------------------------------------------
  // SVA -- adapted for the busy/out_valid handshake (the old a_latency/
  // a_no_spurious pair assumed a FIXED 3-cycle pipe with no busy signal;
  // fusion_node's own latency is data-dependent -- short-circuits to 1
  // cycle only in the sigma1_sq==sigma2_sq==0 corner, ~FRAC+1 otherwise
  // -- so these check the HANDSHAKE shape instead of a fixed cycle count).
  // -------------------------------------------------------------------
  a_busy_on_start : assert property (@(posedge clk) disable iff (!rst_n)
      (in_valid && !busy) |=> busy)
    else $error("SVA a_busy_on_start: busy did not rise the cycle after in_valid was accepted");

  a_no_spurious_valid : assert property (@(posedge clk) disable iff (!rst_n)
      out_valid |-> $past(busy))
    else $error("SVA a_no_spurious_valid: out_valid rose without busy having been high the cycle before");

  a_reset_clears : assert property (@(posedge clk)
      !rst_n |=> (!busy && !out_valid))
    else $error("SVA a_reset_clears: busy/out_valid still active right after reset");

  a_no_x : assert property (@(posedge clk) disable iff (!rst_n)
      out_valid |-> (!$isunknown(k) && !$isunknown(q_hat) && !$isunknown(sigma_new_sq)))
    else $error("SVA a_no_x: an output has X/Z while out_valid=1 (any channel)");

endinterface
