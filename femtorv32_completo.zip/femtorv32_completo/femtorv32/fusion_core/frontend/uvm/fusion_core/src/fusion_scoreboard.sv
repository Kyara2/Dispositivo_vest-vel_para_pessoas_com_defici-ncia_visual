// TLM (Aula 12/13): input via uvm_tlm_analysis_fifo (blocking get), output
// via a plain uvm_analysis_imp (non-blocking write) -- same side-by-side
// comparison style as the project's earlier UVM work. Checks all FN
// channels of every paired in/out transaction, against both the
// bit-exact golden model and the paper's real-valued eq.7/eq.10.
`uvm_analysis_imp_decl(_out)
class fusion_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(fusion_scoreboard)
  uvm_tlm_analysis_fifo #(fusion_item)                    in_fifo;
  uvm_analysis_imp_out  #(fusion_item, fusion_scoreboard) out_export;
  fusion_cfg  cfg;
  fusion_item exp_q[$];
  int unsigned n_in, n_out, n_unexp;
  int unsigned n_err_k, n_err_qhat, n_err_sigma, n_err_eq7, n_err_eq10, n_lat_oob;
  int unsigned lat_min = 32'hFFFF_FFFF, lat_max;
  real max_err7, max_err10;

  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    in_fifo    = new("in_fifo", this);
    out_export = new("out_export", this);
    if (!uvm_config_db#(fusion_cfg)::get(this, "", "cfg", cfg))
      `uvm_fatal("NOCFG", "fusion_cfg not found")
  endfunction

  task run_phase(uvm_phase phase);
    fusion_item t;
    forever begin
      in_fifo.get(t);
      exp_q.push_back(t);
      n_in++;
    end
  endtask

  function real abs_r(input real x); return (x<0.0) ? -x : x; endfunction

  function void write_out(fusion_item o);
    fusion_item inp;
    int unsigned lat;
    logic [FW-1:0] gk, gq, gs;
    real r7, r10, e7, e10;
    n_out++;
    if (exp_q.size() == 0) begin
      n_unexp++; `uvm_error("SB_UNEXP", "out_valid with no pending input") return;
    end
    inp = exp_q.pop_front();
    lat = o.cyc - inp.cyc;
    if (lat < lat_min) lat_min = lat;
    if (lat > lat_max) lat_max = lat;
    // RANGE check, not exact equality: latency is data-dependent now
    // (the sigma1_sq==sigma2_sq==0 corner finishes early in the gain
    // divider -- see fusion_cfg.sv) -- anything wildly outside the sane
    // envelope is still a real bug (e.g. the handshake getting stuck).
    if (lat < cfg.exp_latency_min || lat > cfg.exp_latency_typ + 4) begin
      n_lat_oob++;
      `uvm_error("SB_LAT", $sformatf("latency %0d outside expected [%0d, %0d]",
                 lat, cfg.exp_latency_min, cfg.exp_latency_typ + 4))
    end
    for (int i = 0; i < FN; i++) begin
      gk = fusion_golden_k(inp.sigma1_sq[i], inp.sigma2_sq[i]);
      gq = fusion_golden_q_hat(inp.q1[i], inp.q2[i], gk);
      gs = fusion_golden_sigma_new(inp.sigma1_sq[i], gk);
      if (o.k[i] !== gk) begin
        n_err_k++; `uvm_error("SB_K", $sformatf("ch%0d sigma1_sq=%0d sigma2_sq=%0d -> expected k=%0d got=%0d",
                   i, inp.sigma1_sq[i], inp.sigma2_sq[i], gk, o.k[i]))
      end
      if (o.q_hat[i] !== gq) begin
        n_err_qhat++; `uvm_error("SB_QHAT", $sformatf("ch%0d q1=%0d q2=%0d k=%0d -> expected q_hat=%0d got=%0d",
                   i, inp.q1[i], inp.q2[i], gk, gq, o.q_hat[i]))
      end
      if (o.sigma_new_sq[i] !== gs) begin
        n_err_sigma++; `uvm_error("SB_SIGMA", $sformatf("ch%0d sigma1_sq=%0d k=%0d -> expected=%0d got=%0d",
                   i, inp.sigma1_sq[i], gk, gs, o.sigma_new_sq[i]))
      end
      // real-valued cross-check against the paper's own equations
      r7  = fusion_eq7(inp.q1[i], inp.q2[i], gk);
      e7  = abs_r(real'(o.q_hat[i]) - r7);
      if (e7 > max_err7) max_err7 = e7;
      if (e7 > 0.500001) begin
        n_err_eq7++; `uvm_error("SB_EQ7", $sformatf("ch%0d eq.7=%f got=%0d err=%f", i, r7, o.q_hat[i], e7))
      end
      r10 = fusion_eq10(inp.sigma1_sq[i], gk);
      e10 = abs_r(real'(o.sigma_new_sq[i]) - r10);
      if (e10 > max_err10) max_err10 = e10;
      if (e10 > 0.500001) begin
        n_err_eq10++; `uvm_error("SB_EQ10", $sformatf("ch%0d eq.10=%f got=%0d err=%f", i, r10, o.sigma_new_sq[i], e10))
      end
    end
  endfunction

  function void check_phase(uvm_phase phase);
    super.check_phase(phase);
    if (exp_q.size() != 0) `uvm_error("SB_LOST", $sformatf("%0d frame(s) never produced output", exp_q.size()))
    if (n_in == 0) `uvm_error("SB_EMPTY", "no frames applied")
  endfunction

  function void report_phase(uvm_phase phase);
    string rpt; int fd;
    super.report_phase(phase);
    rpt = $sformatf("\n=== %s scoreboard ===\nframes in/out=%0d/%0d (x%0d ch = %0d checks)\nk-err=%0d q_hat-err=%0d sigma-err=%0d eq7-err=%0d eq10-err=%0d\nmax|eq7 err|=%f max|eq10 err|=%f lat-oob=%0d lat(min/max)=%0d/%0d\n",
            cfg.test_name, n_in, n_out, FN, n_in*FN, n_err_k, n_err_qhat, n_err_sigma, n_err_eq7, n_err_eq10,
            max_err7, max_err10, n_lat_oob, lat_min, lat_max);
    `uvm_info("SB_REPORT", rpt, UVM_NONE)
    fd = $fopen({cfg.results_dir, "/", cfg.test_name, "_scoreboard.rpt"}, "w");
    if (fd != 0) begin $fdisplay(fd, "%s", rpt); $fclose(fd); end
  endfunction
endclass
