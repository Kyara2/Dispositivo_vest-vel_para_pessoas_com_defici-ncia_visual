// driver -- FIRE AND WAIT (changed from the old fusion_core driver, which
// streamed one frame per cycle through a fixed pipeline). fusion_node is
// bottlenecked by its own gain divider, and fusion_core inherits that:
// busy stays high from an accepted in_valid until out_valid, and a new
// in_valid is ignored meanwhile -- there is only ever ONE request in
// flight. `gap` still inserts idle cycles BEFORE firing the next request
// (back-pressure variety), it just can no longer overlap with the
// previous request still draining, because there is no draining to
// overlap with anymore.
class fusion_driver extends uvm_driver #(fusion_item);
  `uvm_component_utils(fusion_driver)
  fusion_vif_t vif;
  fusion_cfg   cfg;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(fusion_vif_t)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "virtual interface not found")
    if (!uvm_config_db#(fusion_cfg)::get(this, "", "cfg", cfg))
      `uvm_fatal("NOCFG", "fusion_cfg not found")
  endfunction

  task run_phase(uvm_phase phase);
    fusion_item req;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.cb);
      seq_item_port.try_next_item(req);
      if (req == null) begin
        drive_idle();
      end else begin
        repeat (req.gap) begin
          drive_idle();
          @(vif.cb);
        end
        drive_frame(req);
        @(vif.cb);
        drive_idle();                 // in_valid is a 1-cycle pulse
        while (!vif.cb.out_valid) @(vif.cb);
        for (int i = 0; i < FN; i++) begin
          req.k[i]            = vif.cb.k[i*FW +: FW];
          req.q_hat[i]        = vif.cb.q_hat[i*FW +: FW];
          req.sigma_new_sq[i] = vif.cb.sigma_new_sq[i*FW +: FW];
        end
        seq_item_port.item_done();
      end
    end
  endtask

  task drive_idle();
    vif.cb.in_valid <= 1'b0;
  endtask

  task drive_frame(fusion_item req);
    vif.cb.in_valid <= 1'b1;
    for (int i = 0; i < FN; i++) begin
      vif.cb.q1[i*FW +: FW]        <= req.q1[i];
      vif.cb.q2[i*FW +: FW]        <= req.q2[i];
      vif.cb.sigma1_sq[i*FW +: FW] <= req.sigma1_sq[i];
      vif.cb.sigma2_sq[i*FW +: FW] <= req.sigma2_sq[i];
    end
  endtask
endclass
