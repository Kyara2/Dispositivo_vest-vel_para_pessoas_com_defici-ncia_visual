// fusion_item.sv -- one transaction drives/checks ALL N channels at once.
// q1/q2/sigma1_sq/sigma2_sq go IN (per channel); k/q_hat/sigma_new_sq come
// OUT (per channel) -- K is no longer a stimulus field, it's a RESULT now.
class fusion_item extends uvm_sequence_item;
  rand bit [FW-1:0] q1[FN], q2[FN], sigma1_sq[FN], sigma2_sq[FN];
  rand int unsigned gap;
  bit [FW-1:0] k[FN], q_hat[FN], sigma_new_sq[FN];
  int unsigned cyc;
  `uvm_object_utils(fusion_item)
  function new(string name = "fusion_item"); super.new(name); endfunction

  constraint c_gap { gap dist {0 := 70, 1 := 15, [2:6] :/ 15}; }
  constraint c_dist {
    foreach (q1[i])        q1[i]        inside {[200:1600]};
    foreach (q2[i])        q2[i]        inside {[200:1600]};
    foreach (sigma1_sq[i]) sigma1_sq[i] inside {[1:65535]};
    foreach (sigma2_sq[i]) sigma2_sq[i] inside {[1:65535]};
  }

  function string convert2string();
    string s; s = $sformatf("gap=%0d cyc=%0d", gap, cyc);
    for (int i = 0; i < FN; i++)
      s = {s, $sformatf("\n  ch%0d: q1=%0d q2=%0d s1=%0d s2=%0d -> k=%0d q_hat=%0d sigma_new=%0d",
                         i, q1[i], q2[i], sigma1_sq[i], sigma2_sq[i], k[i], q_hat[i], sigma_new_sq[i])};
    return s;
  endfunction
endclass

// specialization by INHERITANCE (Aula 6) -- corner-case ranges per channel.
// NOTE: the old fusion_item_corner also exercised K > 1.0 (out-of-contract,
// e.g. 49152 = 1.5x) to probe q_hat's saturation path with an impossible
// gain. That corner cannot be reached through sigma1_sq/sigma2_sq anymore
// -- K = sigma1_sq/(sigma1_sq+sigma2_sq) is mathematically bounded to
// [0,1] for any non-negative variances, so fusion_gain can never hand
// fusion_channel a K above 1.0x in this architecture. That's a genuine
// robustness improvement (an entire invalid-K class is now unreachable by
// construction), but it does mean q_hat's saturation branch for K>1.0 is
// only exercised at the fusion_channel level (where K is still a direct
// stimulus input), not here anymore.
class fusion_item_corner extends fusion_item;
  `uvm_object_utils(fusion_item_corner)
  constraint c_corner_vals {
    foreach (q1[i])        q1[i]        inside {0, 1, 200, 1600, 65534, 65535};
    foreach (q2[i])        q2[i]        inside {0, 1, 200, 1600, 65534, 65535};
    foreach (sigma1_sq[i]) sigma1_sq[i] inside {0, 1, 65534, 65535};
    foreach (sigma2_sq[i]) sigma2_sq[i] inside {0, 1, 65534, 65535};
  }
  function new(string name = "fusion_item_corner");
    super.new(name);
    c_dist.constraint_mode(0);
  endfunction
endclass
