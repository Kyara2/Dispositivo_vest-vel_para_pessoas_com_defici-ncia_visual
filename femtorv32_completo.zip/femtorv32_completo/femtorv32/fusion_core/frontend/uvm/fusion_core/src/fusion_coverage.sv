// functional coverage (Aula 16) -- uvm_subscriber + covergroup. Sampled on
// the INPUT monitor's items (sigma1_sq/sigma2_sq/diff), not output, since
// K is now a computed RESULT, not a stimulus dimension to cover -- the
// cross that matters is which sigma1 x sigma2 combinations were driven,
// because THAT determines which K region gets exercised. Sampled once per
// channel per transaction (FN samples/txn), same pattern used when this
// cross was first adapted for the per-channel fusion_node case.
class fusion_coverage extends uvm_subscriber #(fusion_item);
  `uvm_component_utils(fusion_coverage)
  int unsigned s_s1, s_s2; int s_diff; int s_ch;
  covergroup cg_fusion;
    option.per_instance = 1;
    cp_ch : coverpoint s_ch { bins ch[] = {[0:FN-1]}; }
    cp_s1 : coverpoint s_s1 {
      bins zero={0}; bins low={[1:199]}; bins mid[3]={[200:60000]}; bins high={[60001:65535]};
    }
    cp_s2 : coverpoint s_s2 {
      bins zero={0}; bins low={[1:199]}; bins mid[3]={[200:60000]}; bins high={[60001:65535]};
    }
    cp_diff : coverpoint s_diff {
      bins neg_big={[-65535:-1000]}; bins neg_mid={[-999:-21]}; bins neg_near={[-20:-1]};
      bins zero={0}; bins pos_near={[1:20]}; bins pos_mid={[21:999]}; bins pos_big={[1000:65535]};
    }
    x_s1_s2 : cross cp_s1, cp_s2;
  endgroup
  function new(string name, uvm_component parent);
    super.new(name, parent); cg_fusion = new();
  endfunction
  function void write(fusion_item t);
    for (int i = 0; i < FN; i++) begin
      s_ch = i; s_s1 = t.sigma1_sq[i]; s_s2 = t.sigma2_sq[i];
      s_diff = int'(t.q2[i]) - int'(t.q1[i]);
      cg_fusion.sample();
    end
  endfunction
  function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("COV_REPORT", $sformatf("functional coverage (cg_fusion, %0d channels/txn) = %0.2f%%",
              FN, cg_fusion.get_inst_coverage()), UVM_NONE)
  endfunction
endclass
