class fusion_in_monitor extends uvm_monitor;
  `uvm_component_utils(fusion_in_monitor)
  uvm_analysis_port #(fusion_item) ap;
  fusion_vif_t vif;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(fusion_vif_t)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "virtual interface not found")
  endfunction
  task run_phase(uvm_phase phase);
    forever begin
      @(posedge vif.clk);
      if (vif.rst_n === 1'b1 && vif.in_valid === 1'b1) begin
        fusion_item it = fusion_item::type_id::create("in_item");
        for (int i = 0; i < FN; i++) begin
          it.q1[i] = vif.q1[i*FW +: FW]; it.q2[i] = vif.q2[i*FW +: FW];
          it.sigma1_sq[i] = vif.sigma1_sq[i*FW +: FW]; it.sigma2_sq[i] = vif.sigma2_sq[i*FW +: FW];
        end
        it.cyc = vif.cyc;
        ap.write(it);
      end
    end
  endtask
endclass
