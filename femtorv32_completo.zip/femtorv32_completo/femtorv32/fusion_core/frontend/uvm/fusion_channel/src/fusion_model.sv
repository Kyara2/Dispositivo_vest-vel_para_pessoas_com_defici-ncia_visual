// golden models -- same bit-accurate + eq.7 functions validated earlier
function automatic logic [FW-1:0] fusion_golden_q_hat(
    input logic [FW-1:0] a_q1, input logic [FW-1:0] a_q2, input logic [FW-1:0] a_k);
  logic signed [FW:0]       diff;
  logic signed [2*FW+1:0]   prod, rnd, sum;
  begin
    diff = $signed({1'b0, a_q2}) - $signed({1'b0, a_q1});
    prod = diff * $signed({1'b0, a_k});
    rnd  = (prod + (1 <<< (FFRAC-1))) >>> FFRAC;
    sum  = $signed({{(FW+2){1'b0}}, a_q1}) + rnd;
    if (sum[2*FW+1])                                          fusion_golden_q_hat = '0;
    else if (sum > $signed({{(FW+2){1'b0}}, {FW{1'b1}}}))     fusion_golden_q_hat = '1;
    else                                                      fusion_golden_q_hat = sum[FW-1:0];
  end
endfunction

function automatic real fusion_eq7(input logic [FW-1:0] a_q1, input logic [FW-1:0] a_q2,
                                   input logic [FW-1:0] a_k);
  real kr;
  kr = real'(a_k) / real'(1 << FFRAC);
  return real'(a_q1) + kr * (real'(a_q2) - real'(a_q1));
endfunction
