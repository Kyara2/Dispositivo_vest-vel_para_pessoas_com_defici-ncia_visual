// functional coverage (Aula 16) -- uvm_subscriber + covergroup
class fusion_coverage extends uvm_subscriber #(fusion_item);
  `uvm_component_utils(fusion_coverage)
  int unsigned s_q1, s_k;
  int          s_diff;
  covergroup cg_fusion;
    option.per_instance = 1;
    cp_q1 : coverpoint s_q1 {
      bins zero={0}; bins low={[1:199]}; bins mid[4]={[200:1600]};
      bins high={[1601:65534]}; bins maxv={65535};
    }
    cp_diff : coverpoint s_diff {
      bins neg_big={[-65535:-1000]}; bins neg_mid={[-999:-21]}; bins neg_near={[-20:-1]};
      bins zero={0}; bins pos_near={[1:20]}; bins pos_mid={[21:999]}; bins pos_big={[1000:65535]};
    }
    cp_k : coverpoint s_k {
      bins k0={0}; bins low={[1:8191]}; bins mid={[8192:24575]};
      bins high={[24576:32767]}; bins k1={32768}; bins oob={[32769:65535]};
    }
    x_diff_k : cross cp_diff, cp_k;
  endgroup
  function new(string name, uvm_component parent);
    super.new(name, parent); cg_fusion = new();
  endfunction
  function void write(fusion_item t);
    s_q1 = t.q1; s_k = t.k; s_diff = int'(t.q2) - int'(t.q1);
    cg_fusion.sample();
  endfunction
  function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("COV_REPORT", $sformatf("functional coverage (cg_fusion) = %0.2f%%",
              cg_fusion.get_inst_coverage()), UVM_NONE)
  endfunction
endclass
