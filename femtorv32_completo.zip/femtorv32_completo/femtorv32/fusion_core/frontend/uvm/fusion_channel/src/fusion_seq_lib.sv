class fusion_base_seq extends uvm_sequence #(fusion_item);
  `uvm_object_utils(fusion_base_seq)
  int unsigned num = 100;
  function new(string name = "fusion_base_seq"); super.new(name); endfunction
  task send_vals(input int unsigned a_q1, input int unsigned a_q2,
                 input int unsigned a_k, input int unsigned gap_v = 0);
    fusion_item r = fusion_item::type_id::create("r");
    start_item(r);
    r.q1 = a_q1; r.q2 = a_q2; r.k = a_k; r.gap = gap_v;
    finish_item(r);
  endtask
endclass

class fusion_directed_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_directed_seq)
  function new(string name = "fusion_directed_seq"); super.new(name); endfunction
  task body();
    send_vals(800, 800, 0);     send_vals(800, 800, 16384);  send_vals(800, 800, 32768);
    send_vals(200, 1600, 16384); send_vals(1600, 200, 16384);
    send_vals(500, 1500, 0);     send_vals(500, 1500, 32768);
    send_vals(1000, 1001, 16384); send_vals(1001, 1000, 16384);
    send_vals(700, 900, 16384, 3); send_vals(900, 700, 16384, 7);
  endtask
endclass

class fusion_random_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_random_seq)
  function new(string name = "fusion_random_seq"); super.new(name); endfunction
  task body();
    fusion_item r;
    repeat (num) begin
      r = fusion_item::type_id::create("r");
      start_item(r);
      if (!r.randomize()) `uvm_fatal("RAND", "randomize() failed")
      finish_item(r);
    end
  endtask
endclass

// factory override (Aula 6): same stimulus body as random, but every
// fusion_item created resolves to fusion_item_corner instead -- the
// override, not the sequence code, is what reaches the boundary values.
class fusion_factory_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_factory_seq)
  function new(string name = "fusion_factory_seq"); super.new(name); endfunction
  task body();
    fusion_item r;
    `uvm_info("FACTORY", "override: fusion_item -> fusion_item_corner", UVM_LOW)
    fusion_item::type_id::set_type_override(fusion_item_corner::get_type());
    repeat (num) begin
      r = fusion_item::type_id::create("r");
      start_item(r);
      if (!r.randomize()) `uvm_fatal("RAND", "randomize() failed")
      finish_item(r);
    end
    fusion_item::type_id::set_type_override(fusion_item::get_type());
  endtask
endclass

// closes the functional-coverage cross (diff extreme x K extreme) that
// random+factory alone rarely hit together (Aula 16)
class fusion_asym_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_asym_seq)
  function new(string name = "fusion_asym_seq"); super.new(name); endfunction
  task body();
    int          diffs[] = '{1500, 50, -1500, -50};
    int unsigned ks[]    = '{0, 1, 32767, 32768};
    int unsigned base = 800;
    foreach (diffs[i]) foreach (ks[j]) begin
      int q2v = int'(base) + diffs[i];
      if (q2v < 0) q2v = 0; if (q2v > 65535) q2v = 65535;
      send_vals(base, q2v, ks[j]);
    end
  endtask
endclass
