class fusion_env extends uvm_env;
  `uvm_component_utils(fusion_env)
  fusion_in_agent   in_agent;
  fusion_out_agent  out_agent;
  fusion_scoreboard sb;
  fusion_coverage   cov;
  fusion_cfg        cfg;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(fusion_cfg)::get(this, "", "cfg", cfg))
      `uvm_fatal("NOCFG", "fusion_cfg not found")
    in_agent  = fusion_in_agent ::type_id::create("in_agent",  this);
    out_agent = fusion_out_agent::type_id::create("out_agent", this);
    sb        = fusion_scoreboard::type_id::create("sb", this);
    cov       = fusion_coverage::type_id::create("cov", this);
  endfunction
  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    in_agent.mon.ap.connect(sb.in_fifo.analysis_export);
    in_agent.mon.ap.connect(cov.analysis_export);
    out_agent.mon.ap.connect(sb.out_export);
  endfunction
endclass
