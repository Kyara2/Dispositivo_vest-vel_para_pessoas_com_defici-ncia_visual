class fusion_sequencer extends uvm_sequencer #(fusion_item);
  `uvm_component_utils(fusion_sequencer)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
endclass
