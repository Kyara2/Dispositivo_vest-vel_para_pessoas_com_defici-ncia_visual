class fusion_in_agent extends uvm_agent;
  `uvm_component_utils(fusion_in_agent)
  fusion_sequencer  sqr;
  fusion_driver     drv;
  fusion_in_monitor mon;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    mon = fusion_in_monitor::type_id::create("mon", this);
    if (get_is_active() == UVM_ACTIVE) begin
      sqr = fusion_sequencer::type_id::create("sqr", this);
      drv = fusion_driver::type_id::create("drv", this);
    end
  endfunction
  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    if (get_is_active() == UVM_ACTIVE) drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
