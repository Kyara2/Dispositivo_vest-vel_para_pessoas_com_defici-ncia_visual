class fusion_item extends uvm_sequence_item;
  rand bit [FW-1:0] q1, q2, k;
  rand int unsigned gap;
  bit [FW-1:0] q_hat;
  int unsigned cyc;
  `uvm_object_utils(fusion_item)
  function new(string name = "fusion_item"); super.new(name); endfunction

  constraint c_gap  { gap dist {0 := 70, 1 := 15, [2:6] :/ 15}; }
  constraint c_dist { q1 inside {[200:1600]}; q2 inside {[200:1600]}; }
  constraint c_k    { k inside {[0:32768]}; }

  function string convert2string();
    return $sformatf("q1=%0d q2=%0d k=%0d gap=%0d cyc=%0d q_hat=%0d", q1, q2, k, gap, cyc, q_hat);
  endfunction
endclass

// specialization by INHERITANCE (Aula 6) -- corner-case ranges, including
// K>1.0 out of contract; disables the base class's "normal range" constraints
class fusion_item_corner extends fusion_item;
  `uvm_object_utils(fusion_item_corner)
  constraint c_corner_vals {
    q1 inside {0, 1, 200, 1600, 65534, 65535};
    q2 inside {0, 1, 200, 1600, 65534, 65535};
    k  inside {0, 1, 16384, 32767, 32768, 49152, 65535};
  }
  function new(string name = "fusion_item_corner");
    super.new(name);
    c_dist.constraint_mode(0);
    c_k.constraint_mode(0);
  endfunction
endclass
