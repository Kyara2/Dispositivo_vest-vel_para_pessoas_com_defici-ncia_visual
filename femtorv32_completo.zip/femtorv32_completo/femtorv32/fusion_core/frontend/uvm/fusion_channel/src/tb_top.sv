module tb_top;
  import uvm_pkg::*;
  import fusion_pkg::*;
  `include "uvm_macros.svh"
  logic clk = 1'b0;
  always #2.5 clk = ~clk;   // 5ns period, 200MHz

  fusion_if #(FW, FFRAC) vif (.clk(clk));
  fusion_channel #(.W(FW), .FRAC(FFRAC)) dut (
    .clk(clk), .rst_n(vif.rst_n), .in_valid(vif.in_valid),
    .q1(vif.q1), .q2(vif.q2), .k(vif.k),
    .out_valid(vif.out_valid), .q_hat(vif.q_hat));

  initial begin
    uvm_config_db#(fusion_vif_t)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule
