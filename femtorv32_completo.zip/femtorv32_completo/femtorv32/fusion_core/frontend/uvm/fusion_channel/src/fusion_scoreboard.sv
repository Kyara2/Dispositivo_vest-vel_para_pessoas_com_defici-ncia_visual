// TLM (Aula 12/13): input via uvm_tlm_analysis_fifo (blocking get), output
// via a plain uvm_analysis_imp (non-blocking write) -- same side-by-side
// comparison as the project's earlier UVM work.
`uvm_analysis_imp_decl(_out)
class fusion_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(fusion_scoreboard)
  uvm_tlm_analysis_fifo #(fusion_item)                    in_fifo;
  uvm_analysis_imp_out  #(fusion_item, fusion_scoreboard) out_export;
  fusion_cfg  cfg;
  fusion_item exp_q[$];
  int unsigned n_in, n_out, n_unexp, n_exact_err, n_paper_err, n_lat_err;
  int unsigned lat_min = 32'hFFFF_FFFF, lat_max;
  real max_err;

  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    in_fifo    = new("in_fifo", this);
    out_export = new("out_export", this);
    if (!uvm_config_db#(fusion_cfg)::get(this, "", "cfg", cfg))
      `uvm_fatal("NOCFG", "fusion_cfg not found")
  endfunction

  task run_phase(uvm_phase phase);
    fusion_item t;
    forever begin
      in_fifo.get(t);
      exp_q.push_back(t);
      n_in++;
    end
  endtask

  function real abs_r(input real x); return (x<0.0) ? -x : x; endfunction

  function void write_out(fusion_item o);
    fusion_item inp; int unsigned lat; logic [FW-1:0] golden; real ref_r, err;
    n_out++;
    if (exp_q.size() == 0) begin
      n_unexp++; `uvm_error("SB_UNEXP", "out_valid with no pending input") return;
    end
    inp = exp_q.pop_front();
    lat = o.cyc - inp.cyc;
    if (lat < lat_min) lat_min = lat;
    if (lat > lat_max) lat_max = lat;
    if (lat != cfg.exp_latency) begin
      n_lat_err++; `uvm_error("SB_LAT", $sformatf("latency %0d (expected %0d)", lat, cfg.exp_latency))
    end
    golden = fusion_golden_q_hat(inp.q1, inp.q2, inp.k);
    if (o.q_hat !== golden) begin
      n_exact_err++;
      `uvm_error("SB_EXACT", $sformatf("q1=%0d q2=%0d k=%0d -> expected=%0d got=%0d",
                 inp.q1, inp.q2, inp.k, golden, o.q_hat))
    end
    if (inp.k <= (1<<FFRAC)) begin
      ref_r = fusion_eq7(inp.q1, inp.q2, inp.k);
      err = abs_r(real'(o.q_hat) - ref_r);
      if (err > max_err) max_err = err;
      if (err > 0.500001) begin
        n_paper_err++;
        `uvm_error("SB_EQ7", $sformatf("eq.7=%f got=%0d err=%f", ref_r, o.q_hat, err))
      end
    end
  endfunction

  function void check_phase(uvm_phase phase);
    super.check_phase(phase);
    if (exp_q.size() != 0) `uvm_error("SB_LOST", $sformatf("%0d frame(s) never produced output", exp_q.size()))
    if (n_in == 0) `uvm_error("SB_EMPTY", "no frames applied")
  endfunction

  function void report_phase(uvm_phase phase);
    string rpt; int fd;
    super.report_phase(phase);
    rpt = $sformatf("\n=== %s scoreboard ===\nframes in/out=%0d/%0d bit-exact-err=%0d eq7-err=%0d max|err|=%f lat-err=%0d lat(min/max)=%0d/%0d\n",
            cfg.test_name, n_in, n_out, n_exact_err, n_paper_err, max_err, n_lat_err, lat_min, lat_max);
    `uvm_info("SB_REPORT", rpt, UVM_NONE)
    fd = $fopen({cfg.results_dir, "/", cfg.test_name, "_scoreboard.rpt"}, "w");
    if (fd != 0) begin $fdisplay(fd, "%s", rpt); $fclose(fd); end
  endfunction
endclass
