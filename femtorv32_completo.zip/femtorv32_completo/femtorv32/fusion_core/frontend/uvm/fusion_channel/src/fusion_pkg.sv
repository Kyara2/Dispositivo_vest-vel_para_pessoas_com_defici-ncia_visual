// fusion_pkg.sv -- UVM package for fusion_channel (single channel)
`include "uvm_macros.svh"
package fusion_pkg;
  import uvm_pkg::*;
  parameter int FW    = 16;
  parameter int FFRAC = 15;
  typedef virtual fusion_if #(FW, FFRAC) fusion_vif_t;

  `include "fusion_model.sv"
  `include "fusion_cfg.sv"
  `include "fusion_item.sv"
  `include "fusion_sequencer.sv"
  `include "fusion_driver.sv"
  `include "fusion_in_monitor.sv"
  `include "fusion_out_monitor.sv"
  `include "fusion_in_agent.sv"
  `include "fusion_out_agent.sv"
  `include "fusion_coverage.sv"
  `include "fusion_scoreboard.sv"
  `include "fusion_env.sv"
  `include "fusion_seq_lib.sv"
  `include "fusion_test_lib.sv"
endpackage
