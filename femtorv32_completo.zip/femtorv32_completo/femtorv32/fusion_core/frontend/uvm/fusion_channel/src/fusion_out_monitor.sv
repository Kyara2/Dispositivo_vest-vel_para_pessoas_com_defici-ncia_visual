class fusion_out_monitor extends uvm_monitor;
  `uvm_component_utils(fusion_out_monitor)
  uvm_analysis_port #(fusion_item) ap;
  fusion_vif_t vif;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(fusion_vif_t)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "virtual interface not found")
  endfunction
  task run_phase(uvm_phase phase);
    forever begin
      @(posedge vif.clk);
      if (vif.out_valid === 1'b1) begin
        fusion_item it = fusion_item::type_id::create("out_item");
        if ($isunknown(vif.q_hat)) `uvm_error("OUT_X", "q_hat has X/Z while out_valid=1")
        it.q_hat = vif.q_hat; it.cyc = vif.cyc;
        ap.write(it);
      end
    end
  endtask
endclass
