// ============================================================================
// fusion_if.sv -- interface for fusion_channel, WITH a clocking block +
// modports (Aula 3: Clocking Blocks / Interfaces / ModPorts / Virtual
// Interfaces) instead of the manual "#DRV_DLY after the edge" trick used
// in the project's earlier UVM work. The clocking block's output skew
// drives stimulus safely after the edge and its input skew samples DUT
// outputs safely before the edge, so driver and monitor can share ONE
// virtual interface handle with no race between them and the DUT.
//
// NOTE: written to plain IEEE 1800-2017 clocking-block syntax for Xcelium.
// Neither Icarus Verilog nor Verilator (the two simulators available while
// building this locally) implement clocking blocks/modport-clocking, so
// this one construct could not be compiled here the way everything else in
// this project was -- if xrun reports a syntax error on it, send the exact
// message and it's a quick fix (the rest of the environment, which IS
// locally validated, will not be affected).
// ============================================================================
interface fusion_if #(parameter W = 16, parameter FRAC = 15) (input logic clk);

  logic           rst_n;
  logic           in_valid;
  logic [W-1:0]   q1, q2, k;
  logic           out_valid;
  logic [W-1:0]   q_hat;

  int unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  initial begin
    rst_n = 1'b0; in_valid = 1'b0; q1 = '0; q2 = '0; k = '0;
  end

  task automatic do_reset(input int unsigned n_cycles);
    @(negedge clk);
    rst_n = 1'b0;
    repeat (n_cycles) @(negedge clk);
    rst_n = 1'b1;
  endtask

  // -------------------------------------------------------------------
  // Clocking block: default input skew #1step (sample the value settled
  // at the END of the previous time step -- the Postponed region value,
  // guaranteed stable), default output skew #2 (drive shortly AFTER the
  // edge, same spirit as the old #DRV_DLY but now declared, not ad hoc).
  // -------------------------------------------------------------------
  clocking cb @(posedge clk);
    default input #1step output #2;
    output in_valid, q1, q2, k;
    input  out_valid, q_hat;
  endclocking

  // NOTE: monitors read the raw interface signals directly (at
  // @(posedge clk), same as this project's proven pre-clocking-block
  // pattern), not through `cb` -- a clocking block's `output` clockvars
  // (in_valid/q1/q2/k here) cannot legally be READ back (IEEE 1800 14.3),
  // which is exactly what the monitors need to do. Only the driver uses
  // `cb`. (A second, read-only clocking block for the monitors was tried
  // here and compiled, but its runtime behavior could not be verified
  // against the real Xcelium, so this sticks with the pattern already
  // proven there.)
  modport TB (clocking cb, output rst_n, import do_reset);

  // -------------------------------------------------------------------
  // SVA -- same four checks as before, still sampled directly off the
  // raw interface signals (assertions are a design-side construct, they
  // don't go through the testbench's clocking block).
  // -------------------------------------------------------------------
  a_latency : assert property (@(posedge clk) disable iff (!rst_n)
      in_valid |-> ##3 out_valid)
    else $error("SVA a_latency: out_valid did not rise 3 cycles after in_valid");

  a_no_spurious : assert property (@(posedge clk) disable iff (!rst_n)
      out_valid |-> $past(in_valid, 3))
    else $error("SVA a_no_spurious: out_valid with no in_valid 3 cycles earlier");

  a_reset_clears : assert property (@(posedge clk)
      !rst_n |=> !out_valid)
    else $error("SVA a_reset_clears: out_valid still active right after reset");

  a_no_x : assert property (@(posedge clk) disable iff (!rst_n)
      out_valid |-> !$isunknown(q_hat))
    else $error("SVA a_no_x: q_hat has X/Z while out_valid=1");

endinterface
