// driver -- request/response (fusion_node is bottlenecked by the gain
// divider inside it, same style as fusion_gain's driver).
//
// NOTE: drives the raw interface signals directly, NOT through `cb` --
// see the matching note in fusion_gain/src/fusion_driver.sv for why the
// busy-wait-via-clocking-block version was dropped (it hung under local
// testing, likely a tooling limitation, not confirmed safe on real
// Xcelium so not worth the risk here).
class fusion_driver extends uvm_driver #(fusion_item);
  `uvm_component_utils(fusion_driver)
  fusion_vif_t vif; fusion_cfg cfg;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(fusion_vif_t)::get(this, "", "vif", vif)) `uvm_fatal("NOVIF", "no vif")
    if (!uvm_config_db#(fusion_cfg)::get(this, "", "cfg", cfg)) `uvm_fatal("NOCFG", "no cfg")
  endfunction
  task run_phase(uvm_phase phase);
    fusion_item req;
    vif.in_valid = 1'b0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(posedge vif.clk); #1;
      seq_item_port.try_next_item(req);
      if (req != null) begin
        vif.in_valid   = 1'b1;
        vif.q1         = req.q1;
        vif.q2         = req.q2;
        vif.sigma1_sq  = req.sigma1_sq;
        vif.sigma2_sq  = req.sigma2_sq;
        @(posedge vif.clk); #1;
        vif.in_valid = 1'b0;
        while (!vif.out_valid) @(posedge vif.clk);
        req.k            = vif.k;
        req.q_hat        = vif.q_hat;
        req.sigma_new_sq = vif.sigma_new_sq;
        seq_item_port.item_done();
      end
    end
  endtask
endclass
