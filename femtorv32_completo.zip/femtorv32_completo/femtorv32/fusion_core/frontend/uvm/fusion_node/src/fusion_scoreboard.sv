// checks all THREE outputs together against three independently-validated
// golden models (Aula 17: scoreboards) -- same pattern already proven in
// fusion_node_rtl_tb.sv, now wrapped as a UVM subscriber.
class fusion_scoreboard extends uvm_subscriber #(fusion_item);
  `uvm_component_utils(fusion_scoreboard)
  fusion_cfg cfg;
  int unsigned n_checked, n_err_k, n_err_qhat, n_err_sigma;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(fusion_cfg)::get(this, "", "cfg", cfg)) `uvm_fatal("NOCFG", "no cfg")
  endfunction
  function void write(fusion_item t);
    logic [FW-1:0] gk, gq, gs;
    n_checked++;
    gk = fusion_golden_k(t.sigma1_sq, t.sigma2_sq);
    gq = fusion_golden_q_hat(t.q1, t.q2, gk);
    gs = fusion_golden_sigma_new(t.sigma1_sq, gk);
    if (t.k !== gk) begin
      n_err_k++; `uvm_error("SB_K", $sformatf("sigma1_sq=%0d sigma2_sq=%0d -> expected k=%0d got=%0d",
                 t.sigma1_sq, t.sigma2_sq, gk, t.k))
    end
    if (t.q_hat !== gq) begin
      n_err_qhat++; `uvm_error("SB_QHAT", $sformatf("q1=%0d q2=%0d k=%0d -> expected q_hat=%0d got=%0d",
                 t.q1, t.q2, gk, gq, t.q_hat))
    end
    if (t.sigma_new_sq !== gs) begin
      n_err_sigma++; `uvm_error("SB_SIGMA", $sformatf("sigma1_sq=%0d k=%0d -> expected=%0d got=%0d",
                 t.sigma1_sq, gk, gs, t.sigma_new_sq))
    end
  endfunction
  function void check_phase(uvm_phase phase);
    super.check_phase(phase);
    if (n_checked == 0) `uvm_error("SB_EMPTY", "no requests checked")
  endfunction
  function void report_phase(uvm_phase phase);
    string rpt; int fd;
    super.report_phase(phase);
    rpt = $sformatf("\n=== %s scoreboard ===\nrequests=%0d  k-err=%0d  q_hat-err=%0d  sigma-err=%0d\n",
            cfg.test_name, n_checked, n_err_k, n_err_qhat, n_err_sigma);
    `uvm_info("SB_REPORT", rpt, UVM_NONE)
    fd = $fopen({cfg.results_dir, "/", cfg.test_name, "_scoreboard.rpt"}, "w");
    if (fd != 0) begin $fdisplay(fd, "%s", rpt); $fclose(fd); end
  endfunction
endclass
