class fusion_coverage extends uvm_subscriber #(fusion_item);
  `uvm_component_utils(fusion_coverage)
  int unsigned s_s1, s_s2; int s_diff;
  covergroup cg_node;
    option.per_instance = 1;
    cp_s1 : coverpoint s_s1 {
      bins zero={0}; bins low={[1:199]}; bins mid[3]={[200:60000]}; bins high={[60001:65535]};
    }
    cp_s2 : coverpoint s_s2 {
      bins zero={0}; bins low={[1:199]}; bins mid[3]={[200:60000]}; bins high={[60001:65535]};
    }
    cp_diff : coverpoint s_diff {
      bins neg={[-65535:-1]}; bins zero={0}; bins pos={[1:65535]};
    }
    x_s1_s2 : cross cp_s1, cp_s2;
  endgroup
  function new(string name, uvm_component parent); super.new(name, parent); cg_node = new(); endfunction
  function void write(fusion_item t);
    s_s1 = t.sigma1_sq; s_s2 = t.sigma2_sq; s_diff = int'(t.q2) - int'(t.q1);
    cg_node.sample();
  endfunction
  function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("COV_REPORT", $sformatf("functional coverage (cg_node) = %0.2f%%",
              cg_node.get_inst_coverage()), UVM_NONE)
  endfunction
endclass
