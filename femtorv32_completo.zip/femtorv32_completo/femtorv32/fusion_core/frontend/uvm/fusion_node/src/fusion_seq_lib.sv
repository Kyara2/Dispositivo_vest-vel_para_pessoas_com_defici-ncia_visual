class fusion_base_seq extends uvm_sequence #(fusion_item);
  `uvm_object_utils(fusion_base_seq)
  int unsigned num = 20;
  function new(string name = "fusion_base_seq"); super.new(name); endfunction
  task send_vals(input int unsigned a_q1, input int unsigned a_q2,
                 input int unsigned a_s1, input int unsigned a_s2);
    fusion_item r = fusion_item::type_id::create("r");
    start_item(r); r.q1 = a_q1; r.q2 = a_q2; r.sigma1_sq = a_s1; r.sigma2_sq = a_s2;
    finish_item(r);
  endtask
endclass

class fusion_directed_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_directed_seq)
  function new(string name = "fusion_directed_seq"); super.new(name); endfunction
  task body();
    send_vals(800, 820, 64, 9);     send_vals(500, 1500, 100, 100);
    send_vals(500, 1500, 100, 0);   send_vals(500, 1500, 0, 100);
    send_vals(800, 800, 0, 0);      send_vals(0, 65535, 65535, 65535);
  endtask
endclass

class fusion_random_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_random_seq)
  function new(string name = "fusion_random_seq"); super.new(name); endfunction
  task body();
    fusion_item r;
    repeat (num) begin
      r = fusion_item::type_id::create("r"); start_item(r);
      if (!r.randomize()) `uvm_fatal("RAND", "randomize() failed")
      finish_item(r);
    end
  endtask
endclass

class fusion_factory_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_factory_seq)
  function new(string name = "fusion_factory_seq"); super.new(name); endfunction
  task body();
    fusion_item r;
    fusion_item::type_id::set_type_override(fusion_item_corner::get_type());
    repeat (num) begin
      r = fusion_item::type_id::create("r"); start_item(r);
      if (!r.randomize()) `uvm_fatal("RAND", "randomize() failed")
      finish_item(r);
    end
    fusion_item::type_id::set_type_override(fusion_item::get_type());
  endtask
endclass

// virtual sequence (Aula 10/11): coordinates a defined order -- a short
// random warm-up batch, THEN a corner-case closing batch -- against the
// node's sequencer via p_sequencer, instead of a test launching both
// child sequences ad hoc.
class fusion_vseq extends uvm_sequence;
  `uvm_object_utils(fusion_vseq)
  `uvm_declare_p_sequencer(fusion_virtual_sequencer)
  int unsigned num_random = 20;
  int unsigned num_corner = 20;
  function new(string name = "fusion_vseq"); super.new(name); endfunction
  task body();
    fusion_random_seq  r = fusion_random_seq::type_id::create("r");
    fusion_factory_seq f = fusion_factory_seq::type_id::create("f");
    r.num = num_random; f.num = num_corner;
    `uvm_info("VSEQ", "phase 1/2: random warm-up batch", UVM_LOW)
    r.start(p_sequencer.node_sqr);
    `uvm_info("VSEQ", "phase 2/2: corner-case closing batch", UVM_LOW)
    f.start(p_sequencer.node_sqr);
  endtask
endclass
