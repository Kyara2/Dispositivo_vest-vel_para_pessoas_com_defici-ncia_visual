// fusion_if.sv -- interface for fusion_node (gain -> channel + variance,
// end to end). Not pipelined (bottlenecked by the gain divider inside it,
// same "fire and wait" style as fusion_gain). Clocking block + modport
// (Aula 3), same pattern as the other 4 modules.
interface fusion_if #(parameter W = 16, parameter FRAC = 15) (input logic clk);
  logic           rst_n;
  logic           in_valid;
  logic [W-1:0]   q1, q2, sigma1_sq, sigma2_sq;
  logic           busy, out_valid;
  logic [W-1:0]   k, q_hat, sigma_new_sq;

  initial begin
    rst_n = 1'b0; in_valid = 1'b0; q1 = '0; q2 = '0; sigma1_sq = '0; sigma2_sq = '0;
  end

  task automatic do_reset(input int unsigned n_cycles);
    @(negedge clk); rst_n = 1'b0; repeat (n_cycles) @(negedge clk); rst_n = 1'b1;
  endtask

  clocking cb @(posedge clk);
    default input #1step output #2;
    output in_valid, q1, q2, sigma1_sq, sigma2_sq;
    input  busy, out_valid, k, q_hat, sigma_new_sq;
  endclocking
  modport TB (clocking cb, output rst_n, import do_reset);

  a_busy_on_start : assert property (@(posedge clk) disable iff (!rst_n)
      (in_valid && !busy) |=> busy)
    else $error("SVA a_busy_on_start: busy did not rise the cycle after in_valid was accepted");
  a_no_spurious_valid : assert property (@(posedge clk) disable iff (!rst_n)
      out_valid |-> $past(busy))
    else $error("SVA a_no_spurious_valid: out_valid rose without busy having been high the cycle before");
  a_reset_clears : assert property (@(posedge clk) !rst_n |=> (!busy && !out_valid))
    else $error("SVA a_reset_clears: busy/out_valid still active right after reset");
  a_no_x : assert property (@(posedge clk) disable iff (!rst_n)
      out_valid |-> (!$isunknown(k) && !$isunknown(q_hat) && !$isunknown(sigma_new_sq)))
    else $error("SVA a_no_x: an output has X/Z while out_valid=1");
endinterface
