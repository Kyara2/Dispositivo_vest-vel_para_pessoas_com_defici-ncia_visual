class fusion_monitor extends uvm_monitor;
  `uvm_component_utils(fusion_monitor)
  uvm_analysis_port #(fusion_item) ap;
  fusion_vif_t vif;
  bit [FW-1:0] last_q1, last_q2, last_s1, last_s2;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase); ap = new("ap", this);
    if (!uvm_config_db#(fusion_vif_t)::get(this, "", "vif", vif)) `uvm_fatal("NOVIF", "no vif")
  endfunction
  task run_phase(uvm_phase phase);
    forever begin
      @(posedge vif.clk);
      if (vif.rst_n === 1'b1 && vif.in_valid === 1'b1) begin
        last_q1 = vif.q1; last_q2 = vif.q2;
        last_s1 = vif.sigma1_sq; last_s2 = vif.sigma2_sq;
      end
      if (vif.out_valid === 1'b1) begin
        fusion_item it = fusion_item::type_id::create("it");
        it.q1 = last_q1; it.q2 = last_q2; it.sigma1_sq = last_s1; it.sigma2_sq = last_s2;
        it.k = vif.k; it.q_hat = vif.q_hat; it.sigma_new_sq = vif.sigma_new_sq;
        ap.write(it);
      end
    end
  endtask
endclass
