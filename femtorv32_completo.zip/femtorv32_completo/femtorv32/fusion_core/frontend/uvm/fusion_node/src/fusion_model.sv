// combined golden models -- same three algorithms already validated
// standalone for fusion_gain/fusion_channel/fusion_variance, reused here
// to check the end-to-end result.
function automatic logic [FW-1:0] fusion_golden_k(
    input logic [FW-1:0] a_s1, input logic [FW-1:0] a_s2);
  integer den, r, i;
  logic [FFRAC-1:0] q;
  begin
    den = a_s1 + a_s2;
    if (den == 0) fusion_golden_k = '0;
    else begin
      r = a_s1; q = '0;
      for (i = 0; i < FFRAC; i = i + 1) begin
        r = r << 1;
        if (r >= den) begin r = r - den; q = {q[FFRAC-2:0], 1'b1}; end
        else            q = {q[FFRAC-2:0], 1'b0};
      end
      if (2*r >= den) fusion_golden_k = {1'b0, q} + 1'b1;
      else             fusion_golden_k = {1'b0, q};
    end
  end
endfunction

function automatic logic [FW-1:0] fusion_golden_q_hat(
    input logic [FW-1:0] a_q1, input logic [FW-1:0] a_q2, input logic [FW-1:0] a_k);
  logic signed [FW:0]       diff;
  logic signed [2*FW+1:0]   prod, rnd, sum;
  begin
    diff = $signed({1'b0, a_q2}) - $signed({1'b0, a_q1});
    prod = diff * $signed({1'b0, a_k});
    rnd  = (prod + (1 <<< (FFRAC-1))) >>> FFRAC;
    sum  = $signed({{(FW+2){1'b0}}, a_q1}) + rnd;
    if (sum[2*FW+1])                                      fusion_golden_q_hat = '0;
    else if (sum > $signed({{(FW+2){1'b0}}, {FW{1'b1}}})) fusion_golden_q_hat = '1;
    else                                                  fusion_golden_q_hat = sum[FW-1:0];
  end
endfunction

function automatic logic [FW-1:0] fusion_golden_sigma_new(
    input logic [FW-1:0] a_sigma1_sq, input logic [FW-1:0] a_k);
  logic [2*FW-1:0]      prod, rnd;
  logic signed [2*FW:0] diff;
  begin
    prod = a_sigma1_sq * a_k;
    rnd  = (prod + (1 <<< (FFRAC-1))) >> FFRAC;
    diff = $signed({{(FW+1){1'b0}}, a_sigma1_sq}) - $signed({1'b0, rnd});
    if (diff[2*FW])                                          fusion_golden_sigma_new = '0;
    else if (diff > $signed({{(FW+1){1'b0}}, {FW{1'b1}}}))  fusion_golden_sigma_new = '1;
    else                                                     fusion_golden_sigma_new = diff[FW-1:0];
  end
endfunction
