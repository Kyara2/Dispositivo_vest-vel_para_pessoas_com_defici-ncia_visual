class fusion_sequencer extends uvm_sequencer #(fusion_item);
  `uvm_component_utils(fusion_sequencer)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
endclass

// virtual sequencer (Aula 10/11): fusion_node is a single-port module, so
// this wraps the one real sequencer -- it exists to show the
// uvm_declare_p_sequencer / virtual-sequence plumbing (fusion_vseq below),
// the same pattern used for coordinating multiple agents, applied here to
// coordinate multiple SEQUENCES against the one sequencer in a defined
// order instead of launching them ad hoc from a test.
class fusion_virtual_sequencer extends uvm_sequencer;
  `uvm_component_utils(fusion_virtual_sequencer)
  fusion_sequencer node_sqr;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
endclass
