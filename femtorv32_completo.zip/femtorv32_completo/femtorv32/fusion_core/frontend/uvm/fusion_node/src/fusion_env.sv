class fusion_env extends uvm_env;
  `uvm_component_utils(fusion_env)
  fusion_agent agent;
  fusion_virtual_sequencer vseqr;
  fusion_scoreboard sb;
  fusion_coverage cov;
  fusion_cfg cfg;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(fusion_cfg)::get(this, "", "cfg", cfg)) `uvm_fatal("NOCFG", "no cfg")
    agent = fusion_agent::type_id::create("agent", this);
    vseqr = fusion_virtual_sequencer::type_id::create("vseqr", this);
    sb    = fusion_scoreboard::type_id::create("sb", this);
    cov   = fusion_coverage::type_id::create("cov", this);
  endfunction
  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    agent.mon.ap.connect(sb.analysis_export);
    agent.mon.ap.connect(cov.analysis_export);
    vseqr.node_sqr = agent.sqr;
  endfunction
endclass
