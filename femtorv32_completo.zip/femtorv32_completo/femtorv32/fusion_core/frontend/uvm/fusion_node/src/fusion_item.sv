class fusion_item extends uvm_sequence_item;
  rand bit [FW-1:0] q1, q2, sigma1_sq, sigma2_sq;
  bit [FW-1:0] k, q_hat, sigma_new_sq;
  `uvm_object_utils(fusion_item)
  function new(string name = "fusion_item"); super.new(name); endfunction
  constraint c_rng { q1 inside {[0:65535]}; q2 inside {[0:65535]};
                     sigma1_sq inside {[0:65535]}; sigma2_sq inside {[0:65535]}; }
  function string convert2string();
    return $sformatf("q1=%0d q2=%0d sigma1_sq=%0d sigma2_sq=%0d -> k=%0d q_hat=%0d sigma_new_sq=%0d",
                      q1, q2, sigma1_sq, sigma2_sq, k, q_hat, sigma_new_sq);
  endfunction
endclass

// specialization by inheritance (Aula 6): boundary-heavy values
class fusion_item_corner extends fusion_item;
  `uvm_object_utils(fusion_item_corner)
  constraint c_corner {
    q1 inside {0, 1, 200, 1600, 65534, 65535};
    q2 inside {0, 1, 200, 1600, 65534, 65535};
    sigma1_sq inside {0, 1, 65534, 65535};
    sigma2_sq inside {0, 1, 65534, 65535};
  }
  function new(string name = "fusion_item_corner");
    super.new(name); c_rng.constraint_mode(0);
  endfunction
endclass
