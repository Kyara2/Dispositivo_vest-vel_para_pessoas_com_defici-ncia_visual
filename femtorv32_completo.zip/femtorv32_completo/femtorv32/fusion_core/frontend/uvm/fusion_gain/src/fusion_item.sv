class fusion_item extends uvm_sequence_item;
  rand bit [FW-1:0] sigma1_sq, sigma2_sq;
  bit [FW-1:0] k;
  `uvm_object_utils(fusion_item)
  function new(string name = "fusion_item"); super.new(name); endfunction
  constraint c_rng { sigma1_sq inside {[0:65535]}; sigma2_sq inside {[0:65535]}; }
  function string convert2string();
    return $sformatf("sigma1_sq=%0d sigma2_sq=%0d k=%0d", sigma1_sq, sigma2_sq, k);
  endfunction
endclass

// specialization by inheritance (Aula 6): boundary-heavy values
class fusion_item_corner extends fusion_item;
  `uvm_object_utils(fusion_item_corner)
  constraint c_corner { sigma1_sq inside {0, 1, 65534, 65535}; sigma2_sq inside {0, 1, 65534, 65535}; }
  function new(string name = "fusion_item_corner");
    super.new(name); c_rng.constraint_mode(0);
  endfunction
endclass
