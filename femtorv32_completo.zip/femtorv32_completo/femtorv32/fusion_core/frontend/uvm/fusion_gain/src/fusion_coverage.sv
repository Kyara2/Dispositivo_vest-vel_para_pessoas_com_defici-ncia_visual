class fusion_coverage extends uvm_subscriber #(fusion_item);
  `uvm_component_utils(fusion_coverage)
  int unsigned s_s1, s_s2;
  covergroup cg_gain;
    option.per_instance = 1;
    cp_s1 : coverpoint s_s1 {
      bins zero={0}; bins low={[1:199]}; bins mid[4]={[200:60000]};
      bins high={[60001:65534]}; bins maxv={65535};
    }
    cp_s2 : coverpoint s_s2 {
      bins zero={0}; bins low={[1:199]}; bins mid[4]={[200:60000]};
      bins high={[60001:65534]}; bins maxv={65535};
    }
    x_s1_s2 : cross cp_s1, cp_s2;
  endgroup
  function new(string name, uvm_component parent); super.new(name, parent); cg_gain = new(); endfunction
  function void write(fusion_item t);
    s_s1 = t.sigma1_sq; s_s2 = t.sigma2_sq; cg_gain.sample();
  endfunction
  function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("COV_REPORT", $sformatf("functional coverage (cg_gain) = %0.2f%%",
              cg_gain.get_inst_coverage()), UVM_NONE)
  endfunction
endclass
