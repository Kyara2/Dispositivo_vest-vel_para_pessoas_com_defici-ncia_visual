// golden K: the exact restoring-division algorithm validated in Python
// against 50000+ cases before fusion_gain.sv was written (see project
// history); this is a direct transcription.
function automatic logic [FW-1:0] fusion_golden_k(
    input logic [FW-1:0] a_s1, input logic [FW-1:0] a_s2);
  integer den, r, i;
  logic [FFRAC-1:0] q;
  begin
    den = a_s1 + a_s2;
    if (den == 0) fusion_golden_k = '0;
    else begin
      r = a_s1; q = '0;
      for (i = 0; i < FFRAC; i = i + 1) begin
        r = r << 1;
        if (r >= den) begin r = r - den; q = {q[FFRAC-2:0], 1'b1}; end
        else            q = {q[FFRAC-2:0], 1'b0};
      end
      if (2*r >= den) fusion_golden_k = {1'b0, q} + 1'b1;
      else             fusion_golden_k = {1'b0, q};
    end
  end
endfunction
