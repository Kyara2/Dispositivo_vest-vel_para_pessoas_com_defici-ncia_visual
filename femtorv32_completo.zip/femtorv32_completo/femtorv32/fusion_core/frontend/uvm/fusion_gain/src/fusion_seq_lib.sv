class fusion_base_seq extends uvm_sequence #(fusion_item);
  `uvm_object_utils(fusion_base_seq)
  int unsigned num = 50;
  function new(string name = "fusion_base_seq"); super.new(name); endfunction
  task send_vals(input int unsigned s1, input int unsigned s2);
    fusion_item r = fusion_item::type_id::create("r");
    start_item(r); r.sigma1_sq = s1; r.sigma2_sq = s2; finish_item(r);
  endtask
endclass

class fusion_directed_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_directed_seq)
  function new(string name = "fusion_directed_seq"); super.new(name); endfunction
  task body();
    send_vals(100, 100); send_vals(100, 0); send_vals(0, 100); send_vals(0, 0);
    send_vals(65535, 65535); send_vals(1, 65535); send_vals(65535, 1);
    send_vals(64, 9); send_vals(9, 64);
  endtask
endclass

class fusion_random_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_random_seq)
  function new(string name = "fusion_random_seq"); super.new(name); endfunction
  task body();
    fusion_item r;
    repeat (num) begin
      r = fusion_item::type_id::create("r"); start_item(r);
      if (!r.randomize()) `uvm_fatal("RAND", "randomize() failed")
      finish_item(r);
    end
  endtask
endclass

class fusion_factory_seq extends fusion_base_seq;
  `uvm_object_utils(fusion_factory_seq)
  function new(string name = "fusion_factory_seq"); super.new(name); endfunction
  task body();
    fusion_item r;
    fusion_item::type_id::set_type_override(fusion_item_corner::get_type());
    repeat (num) begin
      r = fusion_item::type_id::create("r"); start_item(r);
      if (!r.randomize()) `uvm_fatal("RAND", "randomize() failed")
      finish_item(r);
    end
    fusion_item::type_id::set_type_override(fusion_item::get_type());
  endtask
endclass
