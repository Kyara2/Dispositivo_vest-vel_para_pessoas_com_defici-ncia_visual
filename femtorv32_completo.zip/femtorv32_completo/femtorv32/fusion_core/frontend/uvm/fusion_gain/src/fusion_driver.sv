// driver -- request/response, one at a time (fusion_gain is not pipelined):
// pull one item, drive it, wait for out_valid, THEN pull the next one.
//
// NOTE: drives the raw interface signals directly (small delay after the
// edge, blocking assignment -- the same race-free idiom this project used
// everywhere before clocking blocks were introduced), NOT through `cb`.
// A `while (!vif.cb.out_valid) @(vif.cb);` busy-wait loop reading a
// clocking-block input variable was tried here and compiled, but hung
// (zero output, had to be killed) under local testing -- almost certainly
// a tooling limitation, not a real SystemVerilog problem, but since it
// could not be verified against the real Xcelium it was not worth the
// risk. `cb` is still declared in fusion_if.sv and is fine to use for a
// plain one-shot drive (as fusion_channel/fusion_variance/fusion_core's
// drivers do); it's specifically this loop-and-poll pattern that caused
// trouble here.
class fusion_driver extends uvm_driver #(fusion_item);
  `uvm_component_utils(fusion_driver)
  fusion_vif_t vif; fusion_cfg cfg;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(fusion_vif_t)::get(this, "", "vif", vif)) `uvm_fatal("NOVIF", "no vif")
    if (!uvm_config_db#(fusion_cfg)::get(this, "", "cfg", cfg)) `uvm_fatal("NOCFG", "no cfg")
  endfunction
  task run_phase(uvm_phase phase);
    fusion_item req;
    vif.in_valid = 1'b0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(posedge vif.clk); #1;
      seq_item_port.try_next_item(req);
      if (req != null) begin
        vif.in_valid   = 1'b1;
        vif.sigma1_sq  = req.sigma1_sq;
        vif.sigma2_sq  = req.sigma2_sq;
        @(posedge vif.clk); #1;
        vif.in_valid = 1'b0;
        while (!vif.out_valid) @(posedge vif.clk);
        req.k = vif.k;
        seq_item_port.item_done();
      end
    end
  endtask
endclass
