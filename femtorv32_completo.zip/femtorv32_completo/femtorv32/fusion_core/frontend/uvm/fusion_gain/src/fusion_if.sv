// fusion_if.sv -- interface for fusion_gain. NOT pipelined (see
// fusion_gain.sv): in_valid starts one computation, busy stays high,
// out_valid pulses once with k. Clocking block + modport (Aula 3), same
// pattern as the other 4 modules' UVM environments.
interface fusion_if #(parameter W = 16, parameter FRAC = 15) (input logic clk);
  logic           rst_n;
  logic           in_valid;
  logic [W-1:0]   sigma1_sq, sigma2_sq;
  logic           busy, out_valid;
  logic [W-1:0]   k;

  initial begin rst_n = 1'b0; in_valid = 1'b0; sigma1_sq = '0; sigma2_sq = '0; end

  task automatic do_reset(input int unsigned n_cycles);
    @(negedge clk); rst_n = 1'b0; repeat (n_cycles) @(negedge clk); rst_n = 1'b1;
  endtask

  clocking cb @(posedge clk);
    default input #1step output #2;
    output in_valid, sigma1_sq, sigma2_sq;
    input  busy, out_valid, k;
  endclocking
  modport TB (clocking cb, output rst_n, import do_reset);

  // SVA: busy must be high throughout a computation and out_valid must not
  // fire while idle; no fixed-cycle latency assertion here (fusion_gain's
  // own latency IS fixed -- FRAC+2 cycles, empirically confirmed in the
  // functional testbench -- but that belongs in the scoreboard/model, not
  // hard-coded into an assertion that would need editing if FRAC changes).
  // Excludes the sigma1_sq=sigma2_sq=0 degenerate case (see
  // a_no_spurious_valid above): that one path answers immediately and
  // never asserts busy at all, by design.
  a_busy_on_start : assert property (@(posedge clk) disable iff (!rst_n)
      (in_valid && !busy && !(sigma1_sq == '0 && sigma2_sq == '0)) |=> busy)
    else $error("SVA a_busy_on_start: busy did not rise the cycle after in_valid was accepted");
  // NOTE: the RTL deliberately drops busy in the SAME cycle it raises
  // out_valid (so the "done" signal and the "ready for next" signal land
  // together) -- so the check is against $past(busy), not busy itself.
  // The sigma1_sq=sigma2_sq=0 degenerate case is also legitimate: it
  // answers in the SAME cycle in_valid is accepted (K=0 by definition,
  // see fusion_gain.sv) and never asserts busy at all -- so $past(in_valid)
  // is the other allowed cause of out_valid rising.
  a_no_spurious_valid : assert property (@(posedge clk) disable iff (!rst_n)
      out_valid |-> ($past(busy) || $past(in_valid)))
    else $error("SVA a_no_spurious_valid: out_valid rose with neither busy nor in_valid the cycle before");
  a_reset_clears : assert property (@(posedge clk) !rst_n |=> (!busy && !out_valid))
    else $error("SVA a_reset_clears: busy/out_valid still active right after reset");
  a_no_x : assert property (@(posedge clk) disable iff (!rst_n)
      out_valid |-> !$isunknown(k))
    else $error("SVA a_no_x: k has X/Z while out_valid=1");
endinterface
