// TLM (Aula 12/13): ONE analysis_imp here -- fusion_gain has only one
// (request/response) monitor, so there's no separate "in" vs "out" TLM
// path to compare (see fusion_channel/uvm's scoreboard for that pattern).
class fusion_scoreboard extends uvm_subscriber #(fusion_item);
  `uvm_component_utils(fusion_scoreboard)
  fusion_cfg cfg;
  int unsigned n_checked, n_err;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(fusion_cfg)::get(this, "", "cfg", cfg)) `uvm_fatal("NOCFG", "no cfg")
  endfunction
  function void write(fusion_item t);
    logic [FW-1:0] golden;
    n_checked++;
    golden = fusion_golden_k(t.sigma1_sq, t.sigma2_sq);
    if (t.k !== golden) begin
      n_err++;
      `uvm_error("SB_EXACT", $sformatf("sigma1_sq=%0d sigma2_sq=%0d -> expected=%0d got=%0d",
                 t.sigma1_sq, t.sigma2_sq, golden, t.k))
    end
  endfunction
  function void check_phase(uvm_phase phase);
    super.check_phase(phase);
    if (n_checked == 0) `uvm_error("SB_EMPTY", "no requests checked")
  endfunction
  function void report_phase(uvm_phase phase);
    string rpt; int fd;
    super.report_phase(phase);
    rpt = $sformatf("\n=== %s scoreboard ===\nrequests checked=%0d errors=%0d\n",
            cfg.test_name, n_checked, n_err);
    `uvm_info("SB_REPORT", rpt, UVM_NONE)
    fd = $fopen({cfg.results_dir, "/", cfg.test_name, "_scoreboard.rpt"}, "w");
    if (fd != 0) begin $fdisplay(fd, "%s", rpt); $fclose(fd); end
  endfunction
endclass
