module tb_top;
  import uvm_pkg::*; import fusion_pkg::*;
  `include "uvm_macros.svh"
  logic clk = 1'b0;
  always #2.5 clk = ~clk;
  fusion_if #(FW, FFRAC) vif (.clk(clk));
  fusion_gain #(.W(FW), .FRAC(FFRAC)) dut (
    .clk(clk), .rst_n(vif.rst_n), .in_valid(vif.in_valid),
    .sigma1_sq(vif.sigma1_sq), .sigma2_sq(vif.sigma2_sq),
    .busy(vif.busy), .out_valid(vif.out_valid), .k(vif.k));
  initial begin
    uvm_config_db#(fusion_vif_t)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule
