// single monitor (request/response -- no pipelining, so no risk of
// ambiguity between "which input goes with which output"): remembers the
// last (sigma1_sq, sigma2_sq) seen on in_valid, and when out_valid fires,
// publishes the COMPLETE (sigma1_sq, sigma2_sq, k) item.
class fusion_monitor extends uvm_monitor;
  `uvm_component_utils(fusion_monitor)
  uvm_analysis_port #(fusion_item) ap;
  fusion_vif_t vif;
  bit [FW-1:0] last_s1, last_s2;
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase); ap = new("ap", this);
    if (!uvm_config_db#(fusion_vif_t)::get(this, "", "vif", vif)) `uvm_fatal("NOVIF", "no vif")
  endfunction
  task run_phase(uvm_phase phase);
    forever begin
      @(posedge vif.clk);
      if (vif.rst_n === 1'b1 && vif.in_valid === 1'b1) begin
        last_s1 = vif.sigma1_sq; last_s2 = vif.sigma2_sq;
      end
      if (vif.out_valid === 1'b1) begin
        fusion_item it = fusion_item::type_id::create("it");
        if ($isunknown(vif.k)) `uvm_error("OUT_X", "k has X/Z while out_valid=1")
        it.sigma1_sq = last_s1; it.sigma2_sq = last_s2; it.k = vif.k;
        ap.write(it);
      end
    end
  endtask
endclass
