`timescale 1ns/1ps
module fusion_core_tb;
    localparam N = 8, W = 16, FRAC = 15;
    logic clk = 0, rst_n = 0, in_valid = 0;
    logic [N*W-1:0] q1, q2, sigma1_sq, sigma2_sq;
    logic busy, out_valid;
    logic [N*W-1:0] k, q_hat, sigma_new_sq;

    always #2.5 clk = ~clk;

    fusion_core #(.N(N), .W(W), .FRAC(FRAC)) dut (
        .clk(clk), .rst_n(rst_n), .in_valid(in_valid),
        .q1(q1), .q2(q2), .sigma1_sq(sigma1_sq), .sigma2_sq(sigma2_sq),
        .busy(busy), .out_valid(out_valid),
        .k(k), .q_hat(q_hat), .sigma_new_sq(sigma_new_sq)
    );

    // golden model, same algorithms as fusion_model.sv (validated earlier
    // in this project against the RTL bit-exact)
    function automatic int unsigned golden_k(input int unsigned s1, input int unsigned s2);
        int den, r, i; reg [FRAC-1:0] q;
        begin
            den = s1 + s2;
            if (den == 0) golden_k = 0;
            else begin
                r = s1; q = 0;
                for (i = 0; i < FRAC; i = i + 1) begin
                    r = r << 1;
                    if (r >= den) begin r = r - den; q = {q[FRAC-2:0], 1'b1}; end
                    else q = {q[FRAC-2:0], 1'b0};
                end
                golden_k = (2*r >= den) ? q + 1 : q;
            end
        end
    endfunction

    function automatic logic [15:0] golden_qhat(input logic [15:0] a_q1, input logic [15:0] a_q2, input logic [15:0] a_k);
        logic signed [16:0] diff;
        logic signed [33:0] prod, rnd, sum;
        begin
            diff = $signed({1'b0, a_q2}) - $signed({1'b0, a_q1});
            prod = diff * $signed({1'b0, a_k});
            rnd  = (prod + (1 <<< (FRAC-1))) >>> FRAC;
            sum  = $signed({18'b0, a_q1}) + rnd;
            if (sum[33])            golden_qhat = '0;
            else if (sum > 65535)   golden_qhat = '1;
            else                    golden_qhat = sum[15:0];
        end
    endfunction

    function automatic logic [15:0] golden_sigma(input logic [15:0] s1, input logic [15:0] a_k);
        logic [31:0]        prod, rnd;
        logic signed [32:0] diff;
        begin
            prod = s1 * a_k;
            rnd  = (prod + (1 <<< (FRAC-1))) >> FRAC;
            diff = $signed({17'b0, s1}) - $signed({1'b0, rnd});
            if (diff[32])           golden_sigma = '0;
            else if (diff > 65535)  golden_sigma = '1;
            else                    golden_sigma = diff[15:0];
        end
    endfunction

    int errors = 0;
    task automatic run_one(input int trial);
        int unsigned qq1[N], qq2[N], ss1[N], ss2[N], ek[N], eq[N], es[N];
        int i;
        @(posedge clk); #1;
        for (i = 0; i < N; i = i + 1) begin
            qq1[i] = $urandom_range(0, 65535);
            qq2[i] = $urandom_range(0, 65535);
            ss1[i] = $urandom_range(1, 65535);
            ss2[i] = $urandom_range(1, 65535);
            q1[i*W +: W] = qq1[i]; q2[i*W +: W] = qq2[i];
            sigma1_sq[i*W +: W] = ss1[i]; sigma2_sq[i*W +: W] = ss2[i];
            ek[i] = golden_k(ss1[i], ss2[i]);
            eq[i] = golden_qhat(qq1[i], qq2[i], ek[i]);
            es[i] = golden_sigma(ss1[i], ek[i]);
        end
        in_valid = 1;
        @(posedge clk); #1;
        in_valid = 0;
        while (!out_valid) @(posedge clk);
        #1;
        for (i = 0; i < N; i = i + 1) begin
            if (k[i*W +: W] !== ek[i]) begin
                errors++;
                $display("FAIL trial=%0d ch=%0d K: got=%0d exp=%0d", trial, i, k[i*W +: W], ek[i]);
            end
            if (q_hat[i*W +: W] !== eq[i]) begin
                errors++;
                $display("FAIL trial=%0d ch=%0d q_hat: got=%0d exp=%0d", trial, i, q_hat[i*W +: W], eq[i]);
            end
            if (sigma_new_sq[i*W +: W] !== es[i]) begin
                errors++;
                $display("FAIL trial=%0d ch=%0d sigma_new_sq: got=%0d exp=%0d", trial, i, sigma_new_sq[i*W +: W], es[i]);
            end
        end
        if (errors == 0 || trial < 3)
            $display("trial=%0d OK (sample ch0: q1=%0d q2=%0d s1=%0d s2=%0d -> k=%0d q_hat=%0d sigma_new=%0d)",
                      trial, qq1[0], qq2[0], ss1[0], ss2[0], k[0+:W], q_hat[0+:W], sigma_new_sq[0+:W]);
    endtask

    initial begin
        q1 = 0; q2 = 0; sigma1_sq = 0; sigma2_sq = 0;
        repeat (5) @(posedge clk);
        rst_n = 1;
        repeat (3) @(posedge clk);
        for (int t = 0; t < 20; t++) run_one(t);
        if (errors == 0) $display("RESULT: PASS -- 20 trials x 8 channels, 0 mismatches");
        else $display("RESULT: FAIL -- %0d mismatches", errors);
        $finish;
    end

    initial begin
        #200000;
        $display("RESULT: FAIL -- TIMEOUT");
        $finish;
    end
endmodule
