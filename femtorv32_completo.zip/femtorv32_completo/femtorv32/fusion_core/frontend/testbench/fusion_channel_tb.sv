// ============================================================================
// fusion_channel_rtl_tb.sv
//
// Plain functional testbench (no UVM) for a SINGLE fusion_channel instance --
// the atomic unit fusion_core replicates 8x. Same two ways to check it as
// the fusion_core testbench:
//   1) Visually: open the dumped VCD and look at q1/q2/k -> out_valid/q_hat,
//      3 cycles later.
//   2) Automatically: check_output() compares every output against a
//      bit-accurate golden model; the testbench keeps one running "overall
//      pass" flag across the whole run and prints a single PASS/FAIL at
//      $finish.
//
// NOTE on renaming this file/module again later (e.g. to fusion_channel_uvm_tb):
// the module name appears in exactly ONE place below -- the `TB_TOP macro.
// Change that one line and both the `module` declaration and the
// `$dumpvars` call stay in sync automatically. (Previous versions of this
// file hardcoded the name in both places separately, which is what broke
// -- a rename to the module line without also updating $dumpvars left a
// stale reference and iverilog couldn't elaborate past it.)
// ============================================================================
`ifndef VCD_FILE
    `define VCD_FILE "target_folder/fusion_channel.vcd"
`endif

`ifndef TB_TOP
    `define TB_TOP fusion_channel_tb
`endif

`timescale 1ns / 1ps

module `TB_TOP;

    // -------------------------------------------------------------------
    // DUT parameters / clock
    // -------------------------------------------------------------------
    localparam WIDTH        = 16;
    localparam FRAC         = 15;
    localparam CLOCK_PERIOD = 5;     // ns -> 200 MHz, same as the project's synthesis constraint
    localparam LATENCY      = 3;     // pipeline depth of fusion_channel, in cycles

    logic clk = 1'b0;
    logic rst_n = 1'b0;
    logic in_valid = 1'b0;

    logic [WIDTH-1:0] q1, q2, k;
    logic [WIDTH-1:0] q_hat;
    logic              out_valid;

    always #(CLOCK_PERIOD/2) clk = ~clk;

    // -------------------------------------------------------------------
    // DUT -- single channel, instantiated directly (no fusion_core wrapper)
    // -------------------------------------------------------------------
    fusion_channel #(.W(WIDTH), .FRAC(FRAC)) dut (
        .clk      (clk),
        .rst_n    (rst_n),
        .in_valid (in_valid),
        .q1       (q1),
        .q2       (q2),
        .k        (k),
        .out_valid(out_valid),
        .q_hat    (q_hat)
    );

    // -------------------------------------------------------------------
    // Waveform dump
    // -------------------------------------------------------------------
    initial begin
        $dumpfile(`VCD_FILE);
        $dumpvars(0, `TB_TOP);
    end

    // -------------------------------------------------------------------
    // Live console monitor
    // -------------------------------------------------------------------
    initial begin
        $monitor("t=%8.1f ns | rst_n=%b in_valid=%b | q1=%0d q2=%0d k=%0d | out_valid=%b q_hat=%0d | pass=%0d fail=%0d",
                  $realtime, rst_n, in_valid, q1, q2, k, out_valid, q_hat,
                  g_pass_count, g_fail_count);
    end

    // -------------------------------------------------------------------
    // Golden model: mirrors the RTL bit-for-bit (diff, multiply by K,
    // round half-up, saturate) -- see fusion_channel.sv stage 1..3.
    // -------------------------------------------------------------------
    function automatic logic [WIDTH-1:0] golden_q_hat(
        input logic [WIDTH-1:0] a_q1,
        input logic [WIDTH-1:0] a_q2,
        input logic [WIDTH-1:0] a_k
    );
        logic signed [WIDTH:0]     diff;
        logic signed [2*WIDTH+1:0] prod, rnd, sum;
        begin
            diff = $signed({1'b0, a_q2}) - $signed({1'b0, a_q1});
            prod = diff * $signed({1'b0, a_k});
            rnd  = (prod + (1 <<< (FRAC-1))) >>> FRAC;
            sum  = $signed({{(WIDTH+2){1'b0}}, a_q1}) + rnd;
            if (sum[2*WIDTH+1])                                       golden_q_hat = '0;  // negative -> 0
            else if (sum > $signed({{(WIDTH+2){1'b0}}, {WIDTH{1'b1}}})) golden_q_hat = '1; // overflow -> max
            else                                                      golden_q_hat = sum[WIDTH-1:0];
        end
    endfunction

    // -------------------------------------------------------------------
    // Expected-value queue, pushed when in_valid is sampled, popped
    // LATENCY cycles later when out_valid fires.
    //
    // Three parallel queues of plain vectors instead of one queue of a
    // packed struct: Icarus Verilog (iverilog -g2012) does not support
    // queues of struct types ("Queue of type `...netstruct_t` is not yet
    // supported"), but queues of plain logic vectors work fine there.
    // -------------------------------------------------------------------
    logic [WIDTH-1:0] exp_q1[$];
    logic [WIDTH-1:0] exp_q2[$];
    logic [WIDTH-1:0] exp_qk[$];
    int     g_pass_count = 0;
    int     g_fail_count = 0;
    bit     g_overall_pass = 1;

    always @(posedge clk) begin
        if (rst_n && in_valid) begin
            exp_q1.push_back(q1);
            exp_q2.push_back(q2);
            exp_qk.push_back(k);
        end
    end

    // -------------------------------------------------------------------
    // check_output(): the function that checks EACH output. Returns 1 on
    // match, 0 on mismatch (and prints what went wrong). Called every
    // cycle out_valid is high; folds straight into the running totals, so
    // there is nothing extra to "combine" here -- one channel, one check.
    // -------------------------------------------------------------------
    function automatic bit check_output(input logic [WIDTH-1:0] actual);
        logic [WIDTH-1:0] f_q1, f_q2, f_k;
        logic [WIDTH-1:0] expected;
        begin
            if (exp_q1.size() == 0) begin
                $display("[%0t] FAIL: out_valid with no pending input frame", $time);
                check_output = 0;
            end else begin
                f_q1 = exp_q1.pop_front();
                f_q2 = exp_q2.pop_front();
                f_k  = exp_qk.pop_front();
                expected = golden_q_hat(f_q1, f_q2, f_k);
                if (actual !== expected) begin
                    $display("[%0t] FAIL: q1=%0d q2=%0d k=%0d -> expected=%0d got=%0d",
                              $time, f_q1, f_q2, f_k, expected, actual);
                    check_output = 0;
                end else begin
                    check_output = 1;
                end
            end
        end
    endfunction

    always @(posedge clk) begin
        if (out_valid) begin
            bit ok;
            ok = check_output(q_hat);
            if (ok) g_pass_count++;
            else     g_fail_count++;
            g_overall_pass = g_overall_pass & ok;
        end
    end

    // -------------------------------------------------------------------
    // Stimulus
    // -------------------------------------------------------------------
    task automatic drive(input logic [WIDTH-1:0] v1, input logic [WIDTH-1:0] v2,
                          input logic [WIDTH-1:0] vk, input bit valid);
        @(negedge clk);
        in_valid = valid;
        q1 = v1;
        q2 = v2;
        k  = vk;
    endtask

    task automatic idle_cycles(input int n);
        repeat (n) @(negedge clk) in_valid = 1'b0;
    endtask

    initial begin
        // ---- reset ----
        rst_n = 1'b0;
        in_valid = 1'b0;
        q1 = '0; q2 = '0; k = '0;
        repeat (4) @(negedge clk);
        rst_n = 1'b1;
        @(negedge clk);

        // ---- directed frame 1: equal inputs, mid-range K -> q_hat == q1 == q2 ----
        drive(800, 800, 16384, 1'b1);

        // ---- directed frame 2: K = 0 -> q_hat must equal q1 ----
        drive(500, 1500, 0, 1'b1);

        // ---- directed frame 3: K = 1.0 (32768) -> q_hat must equal q2 ----
        drive(500, 1500, 32768, 1'b1);

        // ---- directed frame 4: max disagreement in the normal 200..1600 mm range ----
        drive(200, 1600, 16384, 1'b1);

        // ---- bubble: one idle cycle with in_valid low (garbage on the buses) ----
        idle_cycles(1);

        // ---- directed frame 5: rounding tie (K=0.5, diff=+1) -> exercises half-up ----
        drive(1000, 1001, 16384, 1'b1);

        // ---- directed frame 6: K>1.0, out of the normal contract -> exercises saturation ----
        drive(200, 1600, 49152, 1'b1);     // K=1.5 -> raw sum overshoots 65535

        // ---- short pseudo-random burst, back-to-back ----
        for (int f = 0; f < 200; f++) begin
            logic [WIDTH-1:0] ra, rb, rk;
            ra = 200 + ($urandom % 1400);
            rb = 200 + ($urandom % 1400);
            rk = $urandom % 32769;         // 0 .. 32768 inclusive-ish, stays in contract
            drive(ra, rb, rk, 1'b1);
        end

        // ---- drain the pipeline and stop driving ----
        // (one full edge first, so the LAST frame's in_valid=1 actually
        // gets sampled by the DUT before we deassert it)
        @(negedge clk);
        in_valid = 1'b0;
        repeat (LATENCY + 4) @(negedge clk);

        // ---- final combined result ----
        if (exp_q1.size() != 0) begin
            $display("FAIL: %0d frame(s) still pending -- never produced an output", exp_q1.size());
            g_overall_pass = 0;
        end

        $display("----------------------------------------------------------------");
        $display("frames checked = %0d", g_pass_count);
        $display("frames wrong   = %0d", g_fail_count);
        $display("RESULT: %s", g_overall_pass ? "PASS" : "FAIL");
        $display("----------------------------------------------------------------");
        $finish;
    end

endmodule
