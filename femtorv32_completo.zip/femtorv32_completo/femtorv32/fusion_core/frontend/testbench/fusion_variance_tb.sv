// fusion_variance_tb.sv -- plain functional testbench (no UVM), same
// style as fusion_channel_tb.sv: VCD dump + $monitor + self-check against
// a golden model, ends with RESULT: PASS/FAIL.
`ifndef VCD_FILE
    `define VCD_FILE "target_folder/fusion_variance.vcd"
`endif
`timescale 1ns / 1ps

module fusion_variance_tb;
    localparam WIDTH = 16, FRAC = 15, CLOCK_PERIOD = 5, LATENCY = 2;

    logic clk = 1'b0, rst_n = 1'b0, in_valid = 1'b0;
    logic [WIDTH-1:0] sigma1_sq, k, sigma_new_sq;
    logic out_valid;
    always #(CLOCK_PERIOD/2) clk = ~clk;

    fusion_variance #(.W(WIDTH), .FRAC(FRAC)) dut (
        .clk(clk), .rst_n(rst_n), .in_valid(in_valid),
        .sigma1_sq(sigma1_sq), .k(k),
        .out_valid(out_valid), .sigma_new_sq(sigma_new_sq));

    initial begin $dumpfile(`VCD_FILE); $dumpvars(0, fusion_variance_tb); end
    initial $monitor("t=%8.1f ns | in_valid=%b sigma1_sq=%0d k=%0d | out_valid=%b sigma_new_sq=%0d | pass=%0d fail=%0d",
                      $realtime, in_valid, sigma1_sq, k, out_valid, sigma_new_sq, g_pass_count, g_fail_count);

    function automatic logic [WIDTH-1:0] golden_sigma_new(
        input logic [WIDTH-1:0] a_sigma1_sq, input logic [WIDTH-1:0] a_k);
        logic [2*WIDTH-1:0] prod, rnd; logic signed [2*WIDTH:0] diff;
        begin
            prod = a_sigma1_sq * a_k;
            rnd  = (prod + (1 <<< (FRAC-1))) >> FRAC;
            diff = $signed({{(WIDTH+1){1'b0}}, a_sigma1_sq}) - $signed({1'b0, rnd});
            if (diff[2*WIDTH])                                         golden_sigma_new = '0;
            else if (diff > $signed({{(WIDTH+1){1'b0}}, {WIDTH{1'b1}}})) golden_sigma_new = '1;
            else                                                       golden_sigma_new = diff[WIDTH-1:0];
        end
    endfunction

    logic [WIDTH-1:0] exp_s1[$]; logic [WIDTH-1:0] exp_k[$];
    int g_pass_count = 0, g_fail_count = 0; bit g_overall_pass = 1;

    always @(posedge clk) if (rst_n && in_valid) begin
        exp_s1.push_back(sigma1_sq); exp_k.push_back(k);
    end

    function automatic bit check_output(input logic [WIDTH-1:0] actual);
        logic [WIDTH-1:0] f_s1, f_k, expected;
        begin
            if (exp_s1.size() == 0) begin
                $display("[%0t] FAIL: out_valid with no pending input frame", $time);
                check_output = 0;
            end else begin
                f_s1 = exp_s1.pop_front(); f_k = exp_k.pop_front();
                expected = golden_sigma_new(f_s1, f_k);
                if (actual !== expected) begin
                    $display("[%0t] FAIL: sigma1_sq=%0d k=%0d -> expected=%0d got=%0d", $time, f_s1, f_k, expected, actual);
                    check_output = 0;
                end else check_output = 1;
            end
        end
    endfunction

    always @(posedge clk) if (out_valid) begin
        bit ok;
        ok = check_output(sigma_new_sq);
        if (ok) g_pass_count++; else g_fail_count++;
        g_overall_pass = g_overall_pass & ok;
    end

    task automatic drive(input logic [WIDTH-1:0] s1, input logic [WIDTH-1:0] vk, input bit valid);
        @(negedge clk); in_valid = valid; sigma1_sq = s1; k = vk;
    endtask
    task automatic idle_cycles(input int n);
        repeat (n) @(negedge clk) in_valid = 1'b0;
    endtask

    initial begin
        rst_n = 1'b0; in_valid = 1'b0; sigma1_sq = '0; k = '0;
        repeat (4) @(negedge clk); rst_n = 1'b1; @(negedge clk);

        drive(100, 0, 1'b1); drive(100, 32768, 1'b1); drive(100, 16384, 1'b1);
        drive(0, 16384, 1'b1); idle_cycles(1);
        drive(65535, 16384, 1'b1); drive(1000, 49152, 1'b1);

        for (int f = 0; f < 200; f++) begin
            logic [WIDTH-1:0] rs1, rk;
            rs1 = $urandom % 65536; rk = $urandom % 32769;
            drive(rs1, rk, 1'b1);
        end

        @(negedge clk); in_valid = 1'b0;
        repeat (LATENCY + 4) @(negedge clk);

        if (exp_s1.size() != 0) begin
            $display("FAIL: %0d frame(s) still pending", exp_s1.size());
            g_overall_pass = 0;
        end
        $display("----------------------------------------------------------------");
        $display("frames checked = %0d", g_pass_count);
        $display("frames wrong   = %0d", g_fail_count);
        $display("RESULT: %s", g_overall_pass ? "PASS" : "FAIL");
        $display("----------------------------------------------------------------");
        $finish;
    end
endmodule
