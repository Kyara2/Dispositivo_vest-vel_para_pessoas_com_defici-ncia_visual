// fusion_node_tb.sv -- plain functional testbench (no UVM), end to end
// (gain -> channel + variance). Request/response, same as fusion_gain_tb.sv
// (fusion_node is bottlenecked by the gain divider inside it). Checks all
// three outputs (k, q_hat, sigma_new_sq) together against three
// independent golden models.
`ifndef VCD_FILE
    `define VCD_FILE "target_folder/fusion_node.vcd"
`endif
`timescale 1ns / 1ps

module fusion_node_tb;
    localparam WIDTH = 16, FRAC = 15, CLOCK_PERIOD = 5, MAX_WAIT = FRAC + 20;

    logic clk = 1'b0, rst_n = 1'b0, in_valid = 1'b0;
    logic [WIDTH-1:0] q1, q2, sigma1_sq, sigma2_sq;
    logic busy, out_valid;
    logic [WIDTH-1:0] k, q_hat, sigma_new_sq;
    always #(CLOCK_PERIOD/2) clk = ~clk;

    fusion_node #(.W(WIDTH), .FRAC(FRAC)) dut (
        .clk(clk), .rst_n(rst_n), .in_valid(in_valid),
        .q1(q1), .q2(q2), .sigma1_sq(sigma1_sq), .sigma2_sq(sigma2_sq),
        .busy(busy), .out_valid(out_valid),
        .k(k), .q_hat(q_hat), .sigma_new_sq(sigma_new_sq));

    initial begin $dumpfile(`VCD_FILE); $dumpvars(0, fusion_node_tb); end
    initial $monitor("t=%8.1f ns | in_valid=%b busy=%b | q1=%0d q2=%0d s1sq=%0d s2sq=%0d | out_valid=%b k=%0d q_hat=%0d sigma_new_sq=%0d | pass=%0d fail=%0d",
                      $realtime, in_valid, busy, q1, q2, sigma1_sq, sigma2_sq,
                      out_valid, k, q_hat, sigma_new_sq, g_pass_count, g_fail_count);

    function automatic logic [WIDTH-1:0] golden_k(input logic [WIDTH-1:0] a_s1, input logic [WIDTH-1:0] a_s2);
        integer den, r, i; logic [FRAC-1:0] q;
        begin
            den = a_s1 + a_s2;
            if (den == 0) golden_k = '0;
            else begin
                r = a_s1; q = '0;
                for (i = 0; i < FRAC; i = i + 1) begin
                    r = r << 1;
                    if (r >= den) begin r = r - den; q = {q[FRAC-2:0], 1'b1}; end
                    else            q = {q[FRAC-2:0], 1'b0};
                end
                if (2*r >= den) golden_k = {1'b0, q} + 1'b1;
                else             golden_k = {1'b0, q};
            end
        end
    endfunction

    function automatic logic [WIDTH-1:0] golden_q_hat(
        input logic [WIDTH-1:0] a_q1, input logic [WIDTH-1:0] a_q2, input logic [WIDTH-1:0] a_k);
        logic signed [WIDTH:0] diff; logic signed [2*WIDTH+1:0] prod, rnd, sum;
        begin
            diff = $signed({1'b0, a_q2}) - $signed({1'b0, a_q1});
            prod = diff * $signed({1'b0, a_k});
            rnd  = (prod + (1 <<< (FRAC-1))) >>> FRAC;
            sum  = $signed({{(WIDTH+2){1'b0}}, a_q1}) + rnd;
            if (sum[2*WIDTH+1])                                      golden_q_hat = '0;
            else if (sum > $signed({{(WIDTH+2){1'b0}}, {WIDTH{1'b1}}})) golden_q_hat = '1;
            else                                                     golden_q_hat = sum[WIDTH-1:0];
        end
    endfunction

    function automatic logic [WIDTH-1:0] golden_sigma_new(input logic [WIDTH-1:0] a_s1, input logic [WIDTH-1:0] a_k);
        logic [2*WIDTH-1:0] prod, rnd; logic signed [2*WIDTH:0] diff;
        begin
            prod = a_s1 * a_k;
            rnd  = (prod + (1 <<< (FRAC-1))) >> FRAC;
            diff = $signed({{(WIDTH+1){1'b0}}, a_s1}) - $signed({1'b0, rnd});
            if (diff[2*WIDTH])                                         golden_sigma_new = '0;
            else if (diff > $signed({{(WIDTH+1){1'b0}}, {WIDTH{1'b1}}})) golden_sigma_new = '1;
            else                                                       golden_sigma_new = diff[WIDTH-1:0];
        end
    endfunction

    int g_pass_count = 0, g_fail_count = 0; bit g_overall_pass = 1;

    task automatic request(input logic [WIDTH-1:0] a_q1, input logic [WIDTH-1:0] a_q2,
                            input logic [WIDTH-1:0] a_s1, input logic [WIDTH-1:0] a_s2);
        logic [WIDTH-1:0] exp_k, exp_qhat, exp_sigma; int wait_cycles; bit ok;
        begin
            exp_k = golden_k(a_s1, a_s2);
            exp_qhat = golden_q_hat(a_q1, a_q2, exp_k);
            exp_sigma = golden_sigma_new(a_s1, exp_k);

            @(negedge clk);
            q1 = a_q1; q2 = a_q2; sigma1_sq = a_s1; sigma2_sq = a_s2; in_valid = 1'b1;
            @(negedge clk); in_valid = 1'b0;

            wait_cycles = 0;
            while (!out_valid && wait_cycles < MAX_WAIT) begin @(negedge clk); wait_cycles++; end

            ok = 1;
            if (!out_valid) begin
                $display("[%0t] FAIL: out_valid never rose for q1=%0d q2=%0d s1sq=%0d s2sq=%0d", $time, a_q1, a_q2, a_s1, a_s2);
                ok = 0;
            end else begin
                if (k !== exp_k)            begin $display("[%0t] FAIL k: expected=%0d got=%0d", $time, exp_k, k); ok = 0; end
                if (q_hat !== exp_qhat)      begin $display("[%0t] FAIL q_hat: expected=%0d got=%0d", $time, exp_qhat, q_hat); ok = 0; end
                if (sigma_new_sq !== exp_sigma) begin $display("[%0t] FAIL sigma_new_sq: expected=%0d got=%0d", $time, exp_sigma, sigma_new_sq); ok = 0; end
            end
            if (ok) g_pass_count++; else begin g_fail_count++; g_overall_pass = 0; end
            @(negedge clk);
        end
    endtask

    initial begin
        rst_n = 1'b0; in_valid = 1'b0; q1='0; q2='0; sigma1_sq='0; sigma2_sq='0;
        repeat (4) @(negedge clk); rst_n = 1'b1; @(negedge clk);

        request(800, 820, 64, 9); request(500, 1500, 100, 100);
        request(500, 1500, 100, 0); request(500, 1500, 0, 100);
        request(800, 800, 0, 0); request(0, 65535, 65535, 65535);
        for (int f = 0; f < 60; f++)
            request($urandom % 65536, $urandom % 65536, $urandom % 65536, $urandom % 65536);

        $display("----------------------------------------------------------------");
        $display("requests checked = %0d", g_pass_count);
        $display("requests wrong   = %0d", g_fail_count);
        $display("RESULT: %s", g_overall_pass ? "PASS" : "FAIL");
        $display("----------------------------------------------------------------");
        $finish;
    end
endmodule
