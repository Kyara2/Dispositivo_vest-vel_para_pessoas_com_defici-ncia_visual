// fusion_gain_tb.sv -- plain functional testbench (no UVM). fusion_gain is
// NOT pipelined, so this drives one request at a time: assert in_valid,
// wait for out_valid, check, then the next one. Same VCD/monitor/RESULT
// convention as the other testbenches.
`ifndef VCD_FILE
    `define VCD_FILE "target_folder/fusion_gain.vcd"
`endif
`timescale 1ns / 1ps

module fusion_gain_tb;
    localparam WIDTH = 16, FRAC = 15, CLOCK_PERIOD = 5, MAX_WAIT = FRAC + 8;

    logic clk = 1'b0, rst_n = 1'b0, in_valid = 1'b0;
    logic [WIDTH-1:0] sigma1_sq, sigma2_sq, k;
    logic busy, out_valid;
    always #(CLOCK_PERIOD/2) clk = ~clk;

    fusion_gain #(.W(WIDTH), .FRAC(FRAC)) dut (
        .clk(clk), .rst_n(rst_n), .in_valid(in_valid),
        .sigma1_sq(sigma1_sq), .sigma2_sq(sigma2_sq),
        .busy(busy), .out_valid(out_valid), .k(k));

    initial begin $dumpfile(`VCD_FILE); $dumpvars(0, fusion_gain_tb); end
    initial $monitor("t=%8.1f ns | in_valid=%b busy=%b | sigma1_sq=%0d sigma2_sq=%0d | out_valid=%b k=%0d | pass=%0d fail=%0d",
                      $realtime, in_valid, busy, sigma1_sq, sigma2_sq, out_valid, k, g_pass_count, g_fail_count);

    function automatic logic [WIDTH-1:0] golden_k(input logic [WIDTH-1:0] a_s1, input logic [WIDTH-1:0] a_s2);
        integer den, r, i; logic [FRAC-1:0] q;
        begin
            den = a_s1 + a_s2;
            if (den == 0) golden_k = '0;
            else begin
                r = a_s1; q = '0;
                for (i = 0; i < FRAC; i = i + 1) begin
                    r = r << 1;
                    if (r >= den) begin r = r - den; q = {q[FRAC-2:0], 1'b1}; end
                    else            q = {q[FRAC-2:0], 1'b0};
                end
                if (2*r >= den) golden_k = {1'b0, q} + 1'b1;
                else             golden_k = {1'b0, q};
            end
        end
    endfunction

    int g_pass_count = 0, g_fail_count = 0; bit g_overall_pass = 1;

    task automatic request(input logic [WIDTH-1:0] s1, input logic [WIDTH-1:0] s2);
        logic [WIDTH-1:0] expected; int wait_cycles;
        begin
            expected = golden_k(s1, s2);
            @(negedge clk); sigma1_sq = s1; sigma2_sq = s2; in_valid = 1'b1;
            @(negedge clk); in_valid = 1'b0;
            wait_cycles = 0;
            while (!out_valid && wait_cycles < MAX_WAIT) begin @(negedge clk); wait_cycles++; end
            if (!out_valid) begin
                $display("[%0t] FAIL: sigma1_sq=%0d sigma2_sq=%0d -> out_valid never rose", $time, s1, s2);
                g_fail_count++; g_overall_pass = 0;
            end else if (k !== expected) begin
                $display("[%0t] FAIL: sigma1_sq=%0d sigma2_sq=%0d -> expected=%0d got=%0d", $time, s1, s2, expected, k);
                g_fail_count++; g_overall_pass = 0;
            end else g_pass_count++;
            @(negedge clk);
        end
    endtask

    initial begin
        rst_n = 1'b0; in_valid = 1'b0; sigma1_sq = '0; sigma2_sq = '0;
        repeat (4) @(negedge clk); rst_n = 1'b1; @(negedge clk);

        request(100, 100); request(100, 0); request(0, 100); request(0, 0);
        request(65535, 65535); request(1, 65535); request(65535, 1);
        request(64, 9); request(9, 64);
        for (int f = 0; f < 150; f++) request($urandom % 65536, $urandom % 65536);

        $display("----------------------------------------------------------------");
        $display("requests checked = %0d", g_pass_count);
        $display("requests wrong   = %0d", g_fail_count);
        $display("RESULT: %s", g_overall_pass ? "PASS" : "FAIL");
        $display("----------------------------------------------------------------");
        $finish;
    end
endmodule
