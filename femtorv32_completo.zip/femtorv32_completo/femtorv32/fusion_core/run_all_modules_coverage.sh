#!/bin/bash
# run_all_modules_coverage.sh -- mesma coisa que run_all_modules.sh, so' que
# com COVERAGE=all ligado em TODA rodada: roda os testes UVM dos 5 modulos,
# um atras do outro, gerando a base de cobertura (cov_work/scope/<teste>)
# de cada um, e no final imprime um resumo PASS/FAIL. Chame a partir da
# raiz do projeto (onde esta' o exe.sh):
#
#   ./run_all_modules_coverage.sh
#
# Depois de rodar isso, pra cada modulo:
#   MODULE=<modulo> ./exe.sh uvm imc
# junta as bases geradas aqui numa so' (merged_all) e abre no IMC.

set -u
declare -A TESTS
TESTS[fusion_channel]="fusion_sanity_test fusion_random_test fusion_factory_test fusion_coverage_test"
TESTS[fusion_variance]="fusion_sanity_test fusion_random_test fusion_factory_test fusion_coverage_test"
TESTS[fusion_gain]="fusion_sanity_test fusion_random_test fusion_factory_test fusion_coverage_test"
TESTS[fusion_core]="fusion_sanity_test fusion_random_test fusion_factory_test fusion_coverage_test fusion_arbitration_test"
TESTS[fusion_node]="fusion_sanity_test fusion_random_test fusion_factory_test fusion_vseq_test fusion_coverage_test"

export COVERAGE=${COVERAGE:-all}

declare -a RESULTS_SUMMARY
TOTAL=0
FAILED=0

for MOD in fusion_channel fusion_variance fusion_gain fusion_core fusion_node; do
    for T in ${TESTS[$MOD]}; do
        TOTAL=$((TOTAL+1))
        echo "=============================================================="
        echo ">> MODULE=$MOD  TEST=$T  COVERAGE=$COVERAGE"
        echo "=============================================================="
        MODULE=$MOD COVERAGE=$COVERAGE ./exe.sh uvm "$T" > /tmp/${MOD}_${T}_cov.log 2>&1
        RPT="backend/uvm/${MOD}/reports/${T}_result.txt"
        if [ -f "$RPT" ] && grep -q "FUSION_UVM_RESULT: PASS" "$RPT"; then
            RESULTS_SUMMARY+=("PASS  $MOD / $T")
        else
            RESULTS_SUMMARY+=("FAIL  $MOD / $T   (ver /tmp/${MOD}_${T}_cov.log e $RPT)")
            FAILED=$((FAILED+1))
        fi
    done
done

echo
echo "=============================================================="
echo "RESUMO ($((TOTAL-FAILED))/${TOTAL} PASS)  -- COVERAGE=$COVERAGE"
echo "=============================================================="
for line in "${RESULTS_SUMMARY[@]}"; do
    echo "$line"
done

if [ $FAILED -eq 0 ]; then
    echo
    echo "TUDO PASSOU. Bases de cobertura geradas em backend/uvm/<modulo>/work/cov_work/scope/."
    echo "Pra ver no IMC, modulo por modulo:"
    echo "   MODULE=<modulo> ./exe.sh uvm imc"
    exit 0
else
    echo
    echo "$FAILED teste(s) falharam -- confere os logs apontados acima."
    exit 1
fi
