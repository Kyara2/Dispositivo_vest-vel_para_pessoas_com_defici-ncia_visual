# fusion_core corrigido: 8× fusion_node completo

Baseado no projeto real enviado (fusion_core_3.zip), com a estrutura
backend/frontend + UVM que já existia nos outros 4 módulos.

## O que mudou

**Antes:** fusion_core = 8× fusion_channel, K entrando pronto de fora.
**Agora:** fusion_core = 8× fusion_node completo (cada canal com seu
próprio gain+channel+variance).

- `frontend/src/fusion_core.sv` — RTL novo
- `frontend/testbench/fusion_core_tb.sv` — testbench funcional novo
- `frontend/uvm/fusion_core/src/*` — ambiente UVM inteiro adaptado

## Validado de verdade

**RTL**: simulação real com iverilog, usando fusion_gain/fusion_channel/
fusion_variance/fusion_node reais (os mesmos arquivos desse projeto,
confirmei bit a bit que são idênticos). 20 transações × 8 canais, 0
divergência.

## NÃO validado dessa vez (mesmo aviso de antes)

O ambiente UVM não passou por nenhum compilador aqui — minha ferramenta
de checagem de sintaxe UVM (Verilator + UVM) não sobreviveu a um
reinício de sessão no meio dessa conversa, e reconstruir ficaria caro
demais pra esse turno. Revisei linha por linha à mão, reaproveitando ao
máximo a estrutura do ambiente REAL de vocês (que já roda no Xcelium),
mas não é a mesma garantia de um compilador. Roda primeiro com poucos
frames:

```
MODULE=fusion_core NUM_FRAMES=5 ./exe.sh uvm fusion_sanity_test
```

e me manda qualquer erro do xrun.

## O que mudou no ambiente UVM, e por quê

1. **Driver virou fire-and-wait.** O fusion_channel antigo era um pipeline
   de 3 ciclos sempre pronto (múltiplos frames em voo). fusion_node é
   gargalado pelo próprio divisor do gain (~16 ciclos) — não aceita
   pedido novo enquanto `busy`. O driver agora dispara e espera
   `out_valid`, igual ao driver do fusion_node.

2. **K saiu dos campos de entrada do item, virou campo de saída.** Os
   casos diretos que antes setavam K direto agora setam σ1²/σ2² que
   *produzem* o K equivalente (σ1=0 → K=0; σ1=σ2 → K~0.5; σ2=0 → K~1.0).

3. **Um teste não é mais alcançável por construção.** O corner antigo de
   "K > 1.0, fora de contrato" não existe mais — K = σ1²/(σ1²+σ2²) nunca
   passa de 1.0 matematicamente, pra variâncias não-negativas. Não dá
   pra alcançar esse corner através de σ1²/σ2² reais. Isso é uma
   melhoria de robustez genuína (uma classe inteira de K inválido ficou
   inalcançável por construção), mas significa que o ramo de saturação
   do q_hat pra K>1.0 só é exercitado no nível do fusion_channel sozinho
   (onde K ainda é entrada direta), não mais aqui.

4. **Latência não é mais um número fixo.** Era 3 ciclos cravado. Agora é
   ~FRAC+5 (≈20) ciclos, EXCETO o corner σ1²=σ2²=0 de um canal específico,
   que atalha pra ~5 ciclos nesse canal (ver comentário no
   fusion_gain.sv). O scoreboard checa uma FAIXA, não mais igualdade
   exata, por causa disso.

5. **Todos os 8 canais são checados por transação**, não só o canal 0
   como antes — e tem um caso direcionado novo que manda valores
   DIFERENTES por canal na mesma transação, provando que não vaza nada
   entre eles.

6. **Mantive sem mudar:** a nota sobre `SEQ_ARB_MODE` sem prefixo `UVM_`
   (servidor usa UVM-1.1d), a checagem cruzada contra as equações reais
   do artigo (eq.7 e agora também eq.10, pra variância), e os 5 testes
   (sanity/random/factory/coverage/arbitration) — nenhum teste novo
   inventado, nenhum removido.

## Resultados antigos removidos

Limpei `backend/uvm/fusion_core/{reports,work}` e os relatórios de
síntese de `fusion_core` em `backend/synthesis/{reports,deliverables}`
— eram da arquitetura antiga (8× fusion_channel) e não servem mais pra
nada. Os outros 4 módulos (gain/channel/variance/node) não foram
mexidos, os relatórios deles continuam lá.

## Scripts

Não precisei mudar `run.sh`/`exe.sh`/`run_all.sh` — eles já fazem
`MODULE=fusion_core` apontar pros caminhos certos automaticamente. É só
rodar:

```
MODULE=fusion_core COVERAGE=all ./exe.sh uvm all
MODULE=fusion_core ./exe.sh syn
```
