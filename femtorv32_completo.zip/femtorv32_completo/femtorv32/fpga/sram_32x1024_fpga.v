//=============================================================================
// sram_32x1024_fpga.v -- substituto SINTETIZAVEL da macro sram_32x1024_freepdk45
// para FPGA (Gowin BSRAM). Mesmo nome de modulo e mesmas portas, para a
// femto_sram nao mudar; so' entra no projeto da FPGA (no Cadence entra a
// macro de verdade). A femto_sram passa INIT_FILE quando o parametro FPGA=1.
// Author: Kyara Esteves de Sousa
//
// Temporizacao vista pela femto_sram: igual a' macro -- pedido registrado
// na subida, dado valido no ciclo seguinte (aqui o dado ja' sai registrado
// na propria subida, o que so' da' mais folga). dout0 so' muda numa nova
// leitura (a macro vira X; a BSRAM segura o valor -- tambem compativel).
//=============================================================================
`timescale 1ns / 1ps

module sram_32x1024_freepdk45 #(
    parameter INIT_FILE = ""
)(
    input  wire        clk0,
    input  wire        csb0,          // chip select, ativo baixo
    input  wire        web0,          // write enable, ativo baixo
    input  wire [3:0]  wmask0,
    input  wire [9:0]  addr0,
    input  wire [31:0] din0,
    output reg  [31:0] dout0
);
    reg [31:0] mem [0:1023];

    initial begin
        if (INIT_FILE != "") $readmemh(INIT_FILE, mem);
    end

    always @(posedge clk0) begin
        if (!csb0) begin
            if (!web0) begin
                if (wmask0[0]) mem[addr0][ 7: 0] <= din0[ 7: 0];
                if (wmask0[1]) mem[addr0][15: 8] <= din0[15: 8];
                if (wmask0[2]) mem[addr0][23:16] <= din0[23:16];
                if (wmask0[3]) mem[addr0][31:24] <= din0[31:24];
            end else begin
                dout0 <= mem[addr0];
            end
        end
    end
endmodule
