#!/bin/bash
# uart_baud_scan.sh -- descobre em que velocidade o texto da UART chega legivel.
# Uso: ./uart_baud_scan.sh [/dev/ttyUSB1]
# Para cada baud, abre a porta por 3 s (aperte o botao S0 da Dock durante a
# janela, se o firmware ja' tiver passado do cabecalho) e mostra o que chegou.
PORT=${1:-/dev/ttyUSB1}
for B in 9600 19200 38400 57600 115200 230400 460800 921600 1000000 1500000; do
    echo "======== $B baud ========"
    stty -F "$PORT" "$B" raw -echo cs8 -cstopb -parenb -crtscts 2>/dev/null || { echo "(stty recusou $B)"; continue; }
    timeout 3 cat "$PORT" | head -c 300 | tr -c '[:print:]\n' '.'
    echo
done
