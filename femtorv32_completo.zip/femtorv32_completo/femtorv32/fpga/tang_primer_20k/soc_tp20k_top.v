//=============================================================================
// soc_tp20k_top.v -- femto_soc na Sipeed Tang Primer 20K + Dock (GW2A-18C)
// Author: Kyara Esteves de Sousa
//
//   clk       H11  oscilador de 27 MHz da placa (clock do SoC direto, sem PLL)
//   rst_btn_n T10  botao S0 da Dock (ativo baixo) = reset. T10 e' pino de
//                  SSPI: precisa de "Use SSPI as regular IO" (ver README).
//                  Ha' tambem um power-on reset interno, o botao e' opcional.
//   tx        M11  -> conversor USB da Dock (mesma USB do programador),
//                    aparece no PC como porta serial: 115200 8N1
//   rx        T13  (nao usado ainda)
//   trigger/echo N8/N7  HC-SR04 no PMOD0 (J5), linha de cima
//   test_led  L9   acende quando HW == SW na ultima fusao
//   i2c_scl/sda  A11/B11  VL53L0X
//   LEDs da Dock: ver tp20k.cst
//
// O firmware (soc_fw_b0..b3.hex) vai dentro da BSRAM, entao o SoC ja' sobe
// rodando depois de gravar o bitstream.
//=============================================================================
`timescale 1ns / 1ps

module soc_tp20k_top (
    input  wire       clk,
    input  wire       rst_btn_n,
    output wire       tx,
    input  wire       rx,
    output wire       trigger,         // HC-SR04
    input  wire       echo,
    inout  wire       i2c_scl,         // VL53L0X
    inout  wire       i2c_sda,
    output wire [3:0] led_n,           // LEDs da Dock, acesos em nivel baixo
    output wire       test_led         // LED externo (L9)
);
    wire scl_oe, sda_oe;
    wire [3:0] leds;

    // open-drain: so' puxa para 0; o 1 vem do pull-up (modulo do sensor + interno)
    assign i2c_scl = scl_oe ? 1'b0 : 1'bz;
    assign i2c_sda = sda_oe ? 1'b0 : 1'bz;

    // caminho dos soc_fw_b*.hex: o build.sh gera fw_init.vh com o caminho
    // ABSOLUTO, para o $readmemh da BSRAM achar os arquivos de qualquer
    // pasta de trabalho do Gowin (relativo, a BSRAM poderia ficar vazia).
    `include "fw_init.vh"

    // power-on reset: segura o SoC em reset ~2,4 ms depois de configurar a
    // FPGA (os registradores da Gowin nascem em 0), mesmo sem botao.
    reg [15:0] por_cnt = 16'd0;
    wire       por_done = &por_cnt;
    always @(posedge clk) if (!por_done) por_cnt <= por_cnt + 16'd1;
    wire       soc_rst_n = por_done & rst_btn_n;

    femto_soc #(
        .CLK_HZ      (27000000),
        .SIM         (0),
        .RAM_BANKS   (4),
        // 9600: mesma velocidade do projeto da parte 1, que funcionou nesta
        // Dock. A 115200 o texto chegou ~12x "comprimido" (115200/9600 = 12),
        // sinal de que o conversor USB (BL702) estava em 9600.
        .BAUD        (9600),
        .FPGA        (1),
        .INIT_PREFIX (FW_PREFIX)
    ) u_soc (
        .clk        (clk),
        .rst_n      (soc_rst_n),
        .uart_tx    (tx),
        .us_trig    (trigger),
        .us_echo    (echo),
        .i2c_scl_i  (i2c_scl),
        .i2c_scl_oe (scl_oe),
        .i2c_sda_i  (i2c_sda),
        .i2c_sda_oe (sda_oe),
        .leds       (leds)
    );

    // heartbeat de 1 Hz (0,5 s aceso / 0,5 s apagado) no LED 0 da Dock, contado
    // direto do clock de 27 MHz: confere a frequencia real do clock a olho.
    // Se piscar ~12x por segundo, o clock (ou o pino H11) nao e' 27 MHz.
    reg [24:0] hb_cnt = 25'd0;
    reg        hb = 1'b0;
    always @(posedge clk) begin
        if (hb_cnt == 25'd13_499_999) begin hb_cnt <= 25'd0; hb <= ~hb; end
        else                          hb_cnt <= hb_cnt + 25'd1;
    end

    assign led_n    = ~{leds[3:1], hb};
    assign test_led = leds[1];         // firmware: bit1 = HW e SW iguais
    wire unused_rx  = rx;
endmodule
