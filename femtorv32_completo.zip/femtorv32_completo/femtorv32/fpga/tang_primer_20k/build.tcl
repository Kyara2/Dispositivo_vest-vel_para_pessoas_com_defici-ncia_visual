# build.tcl -- projeto Gowin (GW2A-18C, Tang Primer 20K) do femto_soc
# Author: Kyara Esteves de Sousa
#
# Nao rode direto: use o build.sh (ele prepara fw_init.vh, os .hex e o
# LD_LIBRARY_PATH e chama "gw_sh build.tcl" dentro desta pasta, com a etapa
# na variavel de ambiente GOWIN_STEP):
#   new    cria/recria o projeto femto_soc_tp20k/femto_soc_tp20k.gprj
#   syn    recria o projeto e roda so' a sintese (GowinSynthesis)
#   pnr    abre o projeto existente e roda so' o place & route (gera o .fs)
#   build  recria o projeto e roda sintese + place & route (padrao)
# Saidas: femto_soc_tp20k/impl/gwsynthesis/  e  femto_soc_tp20k/impl/pnr/femto_soc_tp20k.fs

set PRJ  femto_soc_tp20k
set HERE [file normalize [pwd]]
set SRC  [file normalize $HERE/../../frontend/src]
set GPRJ $HERE/$PRJ/$PRJ.gprj
if {[info exists ::env(GOWIN_STEP)]} { set STEP $::env(GOWIN_STEP) } else { set STEP build }
puts ">> build.tcl: etapa '$STEP'"

if {$STEP eq "pnr"} {
    # so' place & route: precisa do projeto e da sintese ja' feitos
    open_project $GPRJ
    run pnr
} else {

create_project -name $PRJ -dir $HERE -pn GW2A-LV18PG256C8/I7 -device_version C -force

set_option -output_base_name $PRJ
set_option -top_module soc_tp20k_top
set_option -verilog_std sysv2017
set_option -include_path $HERE
set_option -rw_check_on_ram 1
set_option -use_sspi_as_gpio 1      ;# T10 (botao S0 = reset) e' pino SSPI -> PR2017 sem isto

add_file $HERE/soc_tp20k_top.v
add_file $HERE/../sram_32x1024_fpga.v
add_file $SRC/femtorv32_quark.v
add_file $SRC/femto_sram.v
add_file $SRC/fusion/fusion_gain.sv
add_file $SRC/fusion/fusion_channel.sv
add_file $SRC/fusion/fusion_variance.sv
add_file $SRC/fusion/fusion_node.sv
add_file $SRC/soc/axil2reg.v
add_file $SRC/soc/femto_axil_master.v
add_file $SRC/soc/axil_xbar.v
add_file $SRC/soc/axil_sram.v
add_file $SRC/soc/periph_sysinfo.v
add_file $SRC/soc/periph_uart.v
add_file $SRC/soc/periph_hcsr04.v
add_file $SRC/soc/periph_i2c.v
add_file $SRC/soc/periph_fusion.v
add_file $SRC/soc/femto_soc.v
add_file $HERE/tp20k.cst
add_file $HERE/tp20k.sdc

switch -- $STEP {
    new     { puts ">> projeto criado: $GPRJ" }
    syn     { run syn }
    build   { run all }
    default { puts "ERRO: etapa desconhecida '$STEP'"; exit 1 }
}

}
