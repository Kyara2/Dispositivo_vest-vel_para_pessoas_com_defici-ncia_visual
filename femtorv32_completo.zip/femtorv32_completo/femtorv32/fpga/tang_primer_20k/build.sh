#!/bin/bash
# build.sh -- femto_soc na Tang Primer 20K pelo Gowin (Linux), de qualquer pasta.
# Author: Kyara Esteves de Sousa
#
#   ./build.sh new               cria (ou recria) o projeto Gowin, sem compilar
#   ./build.sh gui               abre o projeto na IDE do Gowin (cria antes, se nao existir)
#   ./build.sh syn               so' sintese (GowinSynthesis)
#   ./build.sh pnr               so' place & route + bitstream (precisa do syn feito)
#   ./build.sh build             syn + pnr + bitstream
#   ./build.sh prog [sram|flash] grava o bitstream: sram e' o padrao (some ao
#                                desligar); flash fica permanente e sobe sozinho
#   ./build.sh all  [sram|flash] syn + pnr + bitstream + grava (sram e' o padrao)
#   ./build.sh calib [sram|flash] igual ao all, mas com o firmware de CALIBRACAO
#                                (imprime linhas "CAL ..." para o tools/calib_fit.py)
#   ./build.sh help              esta ajuda
#
# Antes de new/syn/build/all o script SEMPRE prepara o firmware:
#   1. recompila (make -B em frontend/firmware) se houver toolchain RISC-V,
#      com a calibracao atual de frontend/firmware/soc/calib.h (ou o firmware
#      de calibracao, no comando calib); senao usa os .hex que ja' existem;
#   2. copia soc_fw_b0..b3.hex para esta pasta e para a pasta do projeto;
#   3. gera fw_init.vh com o caminho ABSOLUTO dos .hex (a BSRAM le daqui).
#
# Variaveis de ambiente:
#   GOWIN_HOME   instalacao do Gowin (padrao ~/EDA/Gowin_V1.9.12.03_linux)
#   PROGRAMMER   gowin (padrao, programmer_cli do proprio Gowin) ou openfpgaloader
#   FLASH_OP     operacao do programmer_cli para flash (padrao 37 = exFlash
#                Erase,Program,Verify; 36 = sem verificacao)
#   CABLE_ARGS   argumentos extras do gravador (ex.: "--cable-index 1")

set -e
GOWIN_HOME=${GOWIN_HOME:-$HOME/EDA/Gowin_V1.9.12.03_linux}
GW_BIN="$GOWIN_HOME/IDE/bin"
export LD_LIBRARY_PATH="$GOWIN_HOME/IDE/lib:$LD_LIBRARY_PATH"   # o mesmo que o run_gowin.sh faz

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
PRJ=femto_soc_tp20k
PRJ_DIR="$HERE/$PRJ"
GPRJ="$PRJ_DIR/$PRJ.gprj"
NETLIST_DIR="$PRJ_DIR/impl/gwsynthesis"
BITSTREAM="$PRJ_DIR/impl/pnr/$PRJ.fs"

usage () { sed -n '2,27p' "$0" | sed 's/^# \{0,1\}//'; }
FW_CALIB=0     # 1 = firmware de calibracao (comando calib)

need_gowin () {
    if [ ! -x "$GW_BIN/gw_sh" ]; then
        echo "ERRO: nao achei $GW_BIN/gw_sh -- ajuste GOWIN_HOME."
        exit 1
    fi
}

# alvo de gravacao: sram (padrao) ou flash
check_target () {
    case "${1:-sram}" in
        sram|flash) ;;
        *) echo "ERRO: destino '$1' invalido -- use sram (padrao) ou flash."; exit 1 ;;
    esac
}

prepare_firmware () {
    local FWDIR="$ROOT/frontend/firmware"
    if command -v riscv64-unknown-elf-gcc >/dev/null 2>&1; then
        if [ "$FW_CALIB" == "1" ]; then
            echo ">> recompilando o firmware de CALIBRACAO"
        else
            echo ">> recompilando o firmware (calibracao: frontend/firmware/soc/calib.h)"
        fi
        make -B -C "$FWDIR" hex/soc_fw.hex CALIB=$FW_CALIB >/dev/null
    else
        echo ">> sem toolchain RISC-V: usando os .hex ja' gerados"
        [ "$FW_CALIB" == "1" ] && { echo "ERRO: o modo calib precisa recompilar o firmware (instale gcc-riscv64-unknown-elf)"; exit 1; }
    fi
    for b in 0 1 2 3; do
        [ -f "$FWDIR/hex/soc_fw_b$b.hex" ] || { echo "ERRO: falta $FWDIR/hex/soc_fw_b$b.hex"; exit 1; }
        cp "$FWDIR/hex/soc_fw_b$b.hex" "$HERE/"
    done
    mkdir -p "$PRJ_DIR"
    cp "$HERE"/soc_fw_b*.hex "$PRJ_DIR/"
    cat > "$HERE/fw_init.vh" <<VH
// fw_init.vh -- GERADO pelo build.sh em $(date '+%Y-%m-%d %H:%M'). Nao editar.
localparam FW_PREFIX = "$HERE/soc_fw";
VH
    echo ">> firmware: $HERE/soc_fw_b0..b3.hex"
}

# roda o build.tcl numa etapa (new|syn|pnr|build), com log por etapa
run_step () {
    local STEP=$1
    need_gowin
    cd "$HERE"
    echo ">> gw_sh build.tcl  [etapa: $STEP]  (log: $HERE/$STEP.log)"
    set +e
    GOWIN_STEP=$STEP "$GW_BIN/gw_sh" build.tcl 2>&1 | tee "$HERE/$STEP.log"
    set -e
    if grep -qE "^ERROR|ERROR +\(" "$HERE/$STEP.log"; then
        echo
        echo "FALHOU na etapa $STEP -- erros:"
        grep -E "ERROR" "$HERE/$STEP.log" | head -20
        exit 1
    fi
}

do_new () {
    prepare_firmware
    run_step new
    [ -f "$GPRJ" ] && echo "OK: projeto em $GPRJ" || echo "AVISO: o gw_sh nao gerou $GPRJ (veja new.log)"
}

do_gui () {
    need_gowin
    [ -f "$GPRJ" ] || do_new
    echo ">> abrindo a IDE (se abrir vazia: File -> Open Project -> $GPRJ)"
    exec "$GW_BIN/gw_ide" "$GPRJ"
}

do_syn () {
    prepare_firmware
    run_step syn
    echo "OK: sintese em $NETLIST_DIR"
}

do_pnr () {
    [ -f "$GPRJ" ] || { echo "ERRO: projeto nao existe -- rode $0 syn antes."; exit 1; }
    ls "$NETLIST_DIR"/*.vg >/dev/null 2>&1 || { echo "ERRO: sem netlist em $NETLIST_DIR -- rode $0 syn antes."; exit 1; }
    run_step pnr
    check_bitstream
}

do_build () {
    prepare_firmware
    run_step build
    check_bitstream
}

check_bitstream () {
    if [ -f "$BITSTREAM" ]; then
        echo
        echo "OK: bitstream em $BITSTREAM"
        echo "gravar: $0 prog          (SRAM, padrao)"
        echo "        $0 prog flash    (flash, permanente)"
    else
        echo "ERRO: o bitstream nao foi gerado ($BITSTREAM)"
        exit 1
    fi
}

# Gravacao. Usa o programmer_cli que vem com o Gowin (padrao) ou o
# openFPGALoader, se PROGRAMMER=openfpgaloader. Operacoes do programmer_cli:
#   2  = SRAM Program                         (sram)
#   37 = exFlash Erase,Program,Verify         (flash; mude com FLASH_OP)
do_prog () {
    local TARGET=${1:-sram}
    check_target "$TARGET"
    [ -f "$BITSTREAM" ] || { echo "ERRO: nao achei $BITSTREAM -- rode $0 build primeiro."; exit 1; }

    if [ "${PROGRAMMER:-gowin}" == "openfpgaloader" ]; then
        command -v openFPGALoader >/dev/null 2>&1 || { echo "ERRO: openFPGALoader nao instalado."; exit 1; }
        if [ "$TARGET" == "flash" ]; then
            openFPGALoader -b tangprimer20k $CABLE_ARGS -f "$BITSTREAM"
        else
            openFPGALoader -b tangprimer20k $CABLE_ARGS "$BITSTREAM"
        fi
        return
    fi

    local PCLI="$GOWIN_HOME/Programmer/bin/programmer_cli"
    if [ ! -x "$PCLI" ]; then
        echo "ERRO: nao achei $PCLI"
        echo "      (o Programmer vem junto com o Gowin, na pasta Programmer/ ao lado de IDE/)"
        echo "      Alternativa: PROGRAMMER=openfpgaloader $0 prog $TARGET"
        exit 1
    fi
    export LD_LIBRARY_PATH="$GOWIN_HOME/Programmer/lib:$GOWIN_HOME/Programmer/bin:$LD_LIBRARY_PATH"
    local OP
    if [ "$TARGET" == "flash" ]; then
        OP=${FLASH_OP:-37}
        echo ">> gravando na FLASH (permanente) -- programmer_cli operacao $OP"
    else
        OP=2
        echo ">> gravando na SRAM (some ao desligar) -- programmer_cli operacao $OP"
    fi
    set +e
    "$PCLI" --device GW2A-18C --operation_index $OP --fsFile "$BITSTREAM" $CABLE_ARGS 2>&1 | tee "$HERE/prog.log"
    set -e
    if grep -qiE "error|fail|cannot|not found" "$HERE/prog.log"; then
        echo
        echo "A gravacao parece ter falhado (veja $HERE/prog.log). Causas comuns no Linux:"
        echo "  - permissao no USB: teste com 'sudo -E $0 prog $TARGET' ou instale a regra udev (ver fpga/README.md)"
        echo "  - placa nao detectada: confira o cabo USB-C na porta da Dock e 'lsusb'"
        exit 1
    fi
}

CMD=${1:-help}
case "$CMD" in
    new)   do_new ;;
    gui)   do_gui ;;
    syn)   do_syn ;;
    pnr)   do_pnr ;;
    build) do_build ;;
    prog)  do_prog "$2" ;;
    all)   check_target "${2:-sram}"; do_build; do_prog "$2" ;;
    calib) check_target "${2:-sram}"; FW_CALIB=1; do_build; do_prog "$2"
           echo
           echo "Firmware de calibracao gravado. Para cada distancia conhecida (ex.: 100 mm):"
           echo "  tio -b 9600 /dev/ttyUSB1 -l cal_100.txt     (espere >= 4 linhas CAL, Ctrl-t q)"
           echo "Depois: python3 tools/calib_fit.py 100:cal_100.txt 300:cal_300.txt ..."
           echo "e:      ./fpga/tang_primer_20k/build.sh all" ;;
    help|-h|--help) usage ;;
    *)     echo "ERRO: comando '$CMD' desconhecido."; echo; usage; exit 1 ;;
esac
