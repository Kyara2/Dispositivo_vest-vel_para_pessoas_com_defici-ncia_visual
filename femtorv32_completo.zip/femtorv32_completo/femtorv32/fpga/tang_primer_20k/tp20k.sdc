// tp20k.sdc -- 27 MHz do oscilador da placa
create_clock -name clk -period 37.037 -waveform {0 18.518} [get_ports {clk}]
