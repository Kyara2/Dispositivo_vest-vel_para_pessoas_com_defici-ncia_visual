# femto_soc na Sipeed Tang Primer 20K + Dock (GW2A-18C)

Esta pasta leva para a placa o mesmo RTL sintetizado no Cadence. A única diferença é a RAM: em vez das macros OpenRAM entra `sram_32x1024_fpga.v`, uma BSRAM com o firmware pré-carregado.

## Gerar, abrir na IDE e gravar (Linux)

Tudo é feito pelo `tang_primer_20k/build.sh`, que pode ser rodado de qualquer pasta:

| Comando | O que faz |
|---|---|
| `build.sh new` | cria (ou recria) o projeto Gowin, sem compilar |
| `build.sh gui` | abre o projeto na IDE do Gowin (cria antes, se não existir) |
| `build.sh syn` | só a síntese |
| `build.sh pnr` | só place & route + bitstream (precisa do `syn` feito) |
| `build.sh build` | síntese + place & route + bitstream |
| `build.sh prog [sram\|flash]` | grava o bitstream; `sram` é o padrão (some ao desligar), `flash` é permanente |
| `build.sh all [sram\|flash]` | faz tudo: síntese, place & route, bitstream e gravação (`sram` por padrão) |
| `build.sh calib [sram\|flash]` | igual ao `all`, mas com o firmware de calibração dos sensores (ver README principal) |
| `build.sh help` | mostra a ajuda |

Exemplos:

```bash
./fpga/tang_primer_20k/build.sh all            # gera tudo e grava na SRAM
./fpga/tang_primer_20k/build.sh all flash      # gera tudo e grava na flash
./fpga/tang_primer_20k/build.sh syn            # só síntese, para olhar recursos/avisos
./fpga/tang_primer_20k/build.sh pnr            # depois, só place & route
./fpga/tang_primer_20k/build.sh prog flash     # regrava sem recompilar
```

Antes de `new`, `syn`, `build` e `all`, o script faz três coisas:
1. Recompila o firmware, se o `riscv64-unknown-elf-gcc` estiver instalado. Sem ele, usa os `.hex` que já existem.
2. Copia os `soc_fw_b0..b3.hex` para esta pasta e para a pasta do projeto.
3. Gera o `fw_init.vh` com o caminho absoluto desses arquivos, para a BSRAM nunca ficar vazia.

Cada etapa grava seu próprio log (`new.log`, `syn.log`, `pnr.log`, `build.log`). Se aparecer algum `ERROR`, o script para e mostra as linhas do erro.

O projeto fica em `tang_primer_20k/femto_soc_tp20k/femto_soc_tp20k.gprj`, com as mesmas opções do script, inclusive o SSPI liberado para o botão de reset. O bitstream fica em `.../femto_soc_tp20k/impl/pnr/femto_soc_tp20k.fs`.

Se o Gowin não estiver em `~/EDA/Gowin_V1.9.12.03_linux`, use `GOWIN_HOME=/caminho ./fpga/tang_primer_20k/build.sh ...`.

### Gravação

O `prog` (e o `all`) usa o `programmer_cli`, que já vem com o Gowin em `Programmer/bin/`. Não precisa instalar nada:

| Destino | Operação do `programmer_cli` |
|---|---|
| `sram` (padrão) | 2, SRAM Program |
| `flash` | 37, exFlash Erase,Program,Verify (mude com `FLASH_OP=36` para gravar sem verificar) |

Se tiver o `openFPGALoader` instalado e preferir usá-lo: `PROGRAMMER=openfpgaloader ./build.sh prog`. No Ubuntu 22.04 ele não está no apt; precisa compilar do GitHub.

Se o Linux não deixar acessar a placa (erro de permissão ou "cable not found"), teste com `sudo -E ./build.sh prog`. Para não precisar de sudo, crie a regra udev do conversor USB da Dock:

```bash
echo 'SUBSYSTEM=="usb", ATTRS{idVendor}=="0403", ATTRS{idProduct}=="6010", MODE="0666"' | \
    sudo tee /etc/udev/rules.d/99-tangprimer20k.rules
sudo udevadm control --reload-rules && sudo udevadm trigger     # depois desconecte e reconecte a placa
```

#### Pelo Programmer da IDE

Ele não acha o bitstream sozinho quando o projeto foi gerado pelo script: o caminho do arquivo fica vazio ou aponta para outro lugar. Para gravar por ele:
1. Abra o Programmer e clique em **Scan Device**; deve aparecer o GW2A-18C.
2. Clique duas vezes na linha do dispositivo (coluna Operation).
3. Em **Access Mode**, escolha **SRAM Mode** (SRAM Program) ou **External Flash Mode** (exFlash Erase,Program).
4. No campo **File name**, clique em `...` e selecione `fpga/tang_primer_20k/femto_soc_tp20k/impl/pnr/femto_soc_tp20k.fs`.
5. Clique em **Program/Configure**.

### Terminal perdendo linhas

O conversor USB da Dock (BL702) às vezes descarta blocos inteiros de texto: o número da linha pula e algumas linhas chegam cortadas. O firmware já imprime pouco (uma linha por segundo). Se ainda acontecer:
1. Diminua a latência do driver da porta (vale até desconectar a placa):
   ```bash
   echo 1 | sudo tee /sys/bus/usb-serial/devices/ttyUSB1/latency_timer
   ```
2. Imprima ainda menos: compile com um intervalo maior, por exemplo trocando `REPORT_MS` em `frontend/firmware/soc/main.c` para 2000.
3. A solução definitiva é um adaptador USB-serial comum (CH340, CP2102) ligado num pino livre.

### Erros comuns de place & route

`PR2017: 'rst_btn_n' cannot be placed ... dedicated pin (SSPI)`
: o botão S0 (T10) usa um pino de configuração SSPI. O `build.tcl` já libera isso (`set_option -use_sspi_as_gpio 1`), e o projeto criado com `./build.sh new` (ou aberto com `gui`) herda a opção. Se preferir não usar o botão, comente as linhas do `rst_btn_n` no `.cst` e ligue `.rst_btn_n` em `1'b1` no top: o SoC tem power-on reset interno.

`PR2028: The constrained location is useless in current package`
: algum `IO_LOC` aponta para um pino que não é I/O utilizável nesse encapsulamento. O log do Gowin mostra o nome da porta na linha anterior ou seguinte. Troque esse pino no `tp20k.cst`.

## Ver a saída

O TX da UART (pino M11) sai pela mesma USB do programador, como porta serial. Abra o terminal a **9600** 8N1 (ex.: `tio -b 9600 /dev/ttyUSB1`). Em outros programas (PuTTY, CuteCom, screen) use a mesma velocidade.

O botão S0 (T10) reinicia o SoC. Os LEDs da Dock acendem assim:

| LED | Significa |
|---|---|
| bit 1 | hardware igual ao software na última fusão |
| bit 2 | faltou uma das medidas |
| bit 3 | hardware diferente do software |

## Ligações (CONFIRA antes)

| Sinal | Pino FPGA | Observação |
|---|---|---|
| `clk` | H11 | oscilador da placa |
| `rst_btn_n` | T10 | botão S0 |
| `tx` / `rx` | M11 / T13 | USB da Dock |
| `trigger` | N8 | HC-SR04 TRIG, PMOD0 (J5), linha de cima |
| `echo` | N7 | HC-SR04 ECHO; use divisor (1k + 2k) ou level shifter (5 V → 3,3 V), ou um HC-SR04P |
| `test_led` | L9 | LED externo, acende quando HW == SW |
| `i2c_scl` | A11 | VL53L0X SCL; precisa de pull-up (o módulo GY-530 já tem) |
| `i2c_sda` | B11 | VL53L0X SDA |

Os pinos do HC-SR04, do LED de teste e do I2C são os que você definiu para a sua montagem. Confira no esquemático e, se preferir, troque no `tp20k.cst`. O VL53L0X precisa do XSHUT em nível alto; na maioria dos módulos ele já vem com pull-up.

## Recursos

A síntese de teste com Yosys para Gowin deu 8 BSRAM e cerca de 5.700 LUTs. Os multiplicadores do núcleo de fusão ficaram em LUT nessa estimativa; o Gowin nativo deve usar os DSPs.
